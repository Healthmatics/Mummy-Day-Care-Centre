'use client';

import { useState } from 'react';
import Button from '@/components/ui/Button';

export default function GalleryPage() {
  const [activeCategory, setActiveCategory] = useState('all');
  const [selectedImage, setSelectedImage] = useState(null);
  const [likedImages, setLikedImages] = useState(new Set());

  const categories = [
    { id: 'all', name: 'All Cakes' },
    { id: 'wedding', name: 'Wedding' },
    { id: 'birthday', name: 'Birthday' },
    { id: 'party', name: 'Party' },
    { id: 'kids', name: 'Kids' },
    { id: 'custom', name: 'Custom' }
  ];

  const galleryImages = [
    {
      id: 1,
      category: 'wedding',
      title: 'Elegant Rose Wedding Cake',
      image: 'https://readdy.ai/api/search-image?query=stunning%20white%20wedding%20cake%20with%20cascading%20pink%20roses%2C%20three%20tiers%2C%20elegant%20pearl%20details%2C%20professional%20photography%20in%20luxury%20bridal%20suite&width=800&height=1000&seq=gallery-1&orientation=portrait',
      likes: 124
    },
    {
      id: 2,
      category: 'birthday',
      title: 'Rainbow Birthday Celebration',
      image: 'https://readdy.ai/api/search-image?query=colorful%20rainbow%20birthday%20cake%20with%20multiple%20bright%20layers%2C%20white%20frosting%2C%20birthday%20candles%2C%20festive%20party%20setting%20with%20balloons&width=800&height=1000&seq=gallery-2&orientation=portrait',
      likes: 89
    },
    {
      id: 3,
      category: 'party',
      title: 'Gold Luxury Party Cake',
      image: 'https://readdy.ai/api/search-image?query=sophisticated%20gold%20party%20cake%20with%20metallic%20accents%2C%20elegant%20design%2C%20luxury%20event%20setting%20with%20crystal%20decorations&width=800&height=1000&seq=gallery-3&orientation=portrait',
      likes: 156
    },
    {
      id: 4,
      category: 'kids',
      title: 'Magical Unicorn Adventure',
      image: 'https://readdy.ai/api/search-image?query=whimsical%20unicorn%20birthday%20cake%20with%20rainbow%20mane%2C%20sparkles%2C%20magical%20decorations%2C%20colorful%20party%20background%20with%20fairy%20lights&width=800&height=1000&seq=gallery-4&orientation=portrait',
      likes: 203
    },
    {
      id: 5,
      category: 'wedding',
      title: 'Modern Minimalist Wedding',
      image: 'https://readdy.ai/api/search-image?query=modern%20minimalist%20wedding%20cake%20with%20clean%20geometric%20design%2C%20white%20fondant%2C%20gold%20accents%2C%20contemporary%20venue%20setting&width=800&height=1000&seq=gallery-5&orientation=portrait',
      likes: 97
    },
    {
      id: 6,
      category: 'custom',
      title: 'Corporate Anniversary Cake',
      image: 'https://readdy.ai/api/search-image?query=professional%20corporate%20anniversary%20cake%20with%20company%20logo%2C%20elegant%20business%20design%2C%20office%20celebration%20setting&width=800&height=1000&seq=gallery-6&orientation=portrait',
      likes: 67
    },
    {
      id: 7,
      category: 'birthday',
      title: 'Chocolate Drip Masterpiece',
      image: 'https://readdy.ai/api/search-image?query=decadent%20chocolate%20birthday%20cake%20with%20dark%20ganache%20drip%2C%20gold%20decorations%2C%20macarons%2C%20elegant%20presentation%20on%20marble%20table&width=800&height=1000&seq=gallery-7&orientation=portrait',
      likes: 145
    },
    {
      id: 8,
      category: 'party',
      title: 'Tropical Paradise Theme',
      image: 'https://readdy.ai/api/search-image?query=tropical%20themed%20party%20cake%20with%20coconut%20frosting%2C%20pineapple%20decorations%2C%20palm%20leaves%2C%20bright%20summer%20colors%2C%20beach%20party%20setting&width=800&height=1000&seq=gallery-8&orientation=portrait',
      likes: 112
    },
    {
      id: 9,
      category: 'kids',
      title: 'Superhero Adventure Cake',
      image: 'https://readdy.ai/api/search-image?query=exciting%20superhero%20birthday%20cake%20with%20comic%20book%20design%2C%20bright%20primary%20colors%2C%20action%20figures%2C%20cape%20decorations%2C%20fun%20party%20atmosphere&width=800&height=1000&seq=gallery-9&orientation=portrait',
      likes: 178
    },
    {
      id: 10,
      category: 'wedding',
      title: 'Rustic Garden Wedding',
      image: 'https://readdy.ai/api/search-image?query=rustic%20wedding%20cake%20with%20textured%20buttercream%2C%20fresh%20flowers%2C%20natural%20organic%20look%2C%20outdoor%20garden%20wedding%20setting&width=800&height=1000&seq=gallery-10&orientation=portrait',
      likes: 134
    },
    {
      id: 11,
      category: 'custom',
      title: 'Artistic Sculpture Cake',
      image: 'https://readdy.ai/api/search-image?query=artistic%20sculpture%20cake%20with%203D%20design%2C%20intricate%20details%2C%20modern%20art%20style%2C%20gallery-like%20setting%20with%20dramatic%20lighting&width=800&height=1000&seq=gallery-11&orientation=portrait',
      likes: 89
    },
    {
      id: 12,
      category: 'birthday',
      title: 'Floral Buttercream Beauty',
      image: 'https://readdy.ai/api/search-image?query=beautiful%20birthday%20cake%20with%20buttercream%20flower%20decorations%2C%20pink%20and%20white%20roses%2C%20smooth%20frosting%2C%20vintage%20cake%20stand&width=800&height=1000&seq=gallery-12&orientation=portrait',
      likes: 156
    }
  ];

  const filteredImages = activeCategory === 'all' 
    ? galleryImages 
    : galleryImages.filter(img => img.category === activeCategory);

  const handleLike = (imageId) => {
    setLikedImages(prev => {
      const newLiked = new Set(prev);
      if (newLiked.has(imageId)) {
        newLiked.delete(imageId);
      } else {
        newLiked.add(imageId);
      }
      return newLiked;
    });
  };

  const shareImage = (image) => {
    if (navigator.share) {
      navigator.share({
        title: image.title,
        text: `Check out this amazing cake from Verrloy's Bake Shop!`,
        url: window.location.href
      });
    } else {
      // Fallback for browsers that don't support Web Share API
      navigator.clipboard.writeText(window.location.href);
      alert('Link copied to clipboard!');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50 to-pink-50">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-r from-amber-600 to-pink-600">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">Our Gallery</h1>
          <p className="text-xl text-white/90 max-w-2xl mx-auto">
            Explore our collection of beautiful cakes and sweet creations
          </p>
        </div>
      </section>

      {/* Category Filter */}
      <section className="py-12 bg-white shadow-sm">
        <div className="container mx-auto px-4">
          <div className="flex flex-wrap justify-center gap-4">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setActiveCategory(category.id)}
                className={`px-6 py-3 rounded-full font-semibold transition-all cursor-pointer whitespace-nowrap ${
                  activeCategory === category.id
                    ? 'bg-amber-600 text-white shadow-md'
                    : 'bg-gray-100 text-gray-700 hover:bg-amber-100'
                }`}
              >
                {category.name}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Gallery Grid */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredImages.map((image) => (
              <div key={image.id} className="group relative bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow">
                <div className="relative overflow-hidden">
                  <img
                    src={image.image}
                    alt={image.title}
                    className="w-full h-64 object-cover object-top group-hover:scale-105 transition-transform duration-300 cursor-pointer"
                    onClick={() => setSelectedImage(image)}
                  />
                  
                  {/* Overlay with actions */}
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                    <div className="flex space-x-4">
                      <button
                        onClick={() => setSelectedImage(image)}
                        className="bg-white/20 backdrop-blur-sm text-white p-3 rounded-full hover:bg-white/30 transition-colors cursor-pointer"
                      >
                        <div className="w-6 h-6 flex items-center justify-center">
                          <i className="ri-eye-line text-lg"></i>
                        </div>
                      </button>
                      <button
                        onClick={() => handleLike(image.id)}
                        className={`backdrop-blur-sm p-3 rounded-full transition-colors cursor-pointer ${
                          likedImages.has(image.id) 
                            ? 'bg-pink-500 text-white' 
                            : 'bg-white/20 text-white hover:bg-white/30'
                        }`}
                      >
                        <div className="w-6 h-6 flex items-center justify-center">
                          <i className={`ri-heart-${likedImages.has(image.id) ? 'fill' : 'line'} text-lg`}></i>
                        </div>
                      </button>
                      <button
                        onClick={() => shareImage(image)}
                        className="bg-white/20 backdrop-blur-sm text-white p-3 rounded-full hover:bg-white/30 transition-colors cursor-pointer"
                      >
                        <div className="w-6 h-6 flex items-center justify-center">
                          <i className="ri-share-line text-lg"></i>
                        </div>
                      </button>
                    </div>
                  </div>
                </div>
                
                <div className="p-4">
                  <h3 className="font-semibold text-gray-800 mb-2">{image.title}</h3>
                  <div className="flex items-center space-x-2 text-sm text-gray-600">
                    <div className="flex items-center space-x-1">
                      <div className="w-4 h-4 flex items-center justify-center">
                        <i className="ri-heart-line"></i>
                      </div>
                      <span>{image.likes + (likedImages.has(image.id) ? 1 : 0)}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Lightbox Modal */}
      {selectedImage && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
          <div className="relative max-w-4xl max-h-full">
            <button
              onClick={() => setSelectedImage(null)}
              className="absolute top-4 right-4 bg-white/20 backdrop-blur-sm text-white p-2 rounded-full hover:bg-white/30 transition-colors cursor-pointer z-10"
            >
              <div className="w-6 h-6 flex items-center justify-center">
                <i className="ri-close-line text-lg"></i>
              </div>
            </button>
            
            <img
              src={selectedImage.image}
              alt={selectedImage.title}
              className="max-w-full max-h-full object-contain rounded-lg"
            />
            
            <div className="absolute bottom-4 left-4 right-4 bg-white/90 backdrop-blur-sm rounded-lg p-4">
              <h3 className="font-semibold text-gray-800 mb-2">{selectedImage.title}</h3>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <button
                    onClick={() => handleLike(selectedImage.id)}
                    className={`flex items-center space-x-2 px-3 py-1 rounded-full transition-colors cursor-pointer ${
                      likedImages.has(selectedImage.id) 
                        ? 'bg-pink-500 text-white' 
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    <div className="w-4 h-4 flex items-center justify-center">
                      <i className={`ri-heart-${likedImages.has(selectedImage.id) ? 'fill' : 'line'}`}></i>
                    </div>
                    <span className="text-sm">{selectedImage.likes + (likedImages.has(selectedImage.id) ? 1 : 0)}</span>
                  </button>
                  <button
                    onClick={() => shareImage(selectedImage)}
                    className="flex items-center space-x-2 px-3 py-1 rounded-full bg-gray-100 text-gray-700 hover:bg-gray-200 transition-colors cursor-pointer"
                  >
                    <div className="w-4 h-4 flex items-center justify-center">
                      <i className="ri-share-line"></i>
                    </div>
                    <span className="text-sm">Share</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}