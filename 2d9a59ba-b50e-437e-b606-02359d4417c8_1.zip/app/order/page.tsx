'use client';

import { useState } from 'react';
import Button from '@/components/ui/Button';

export default function OrderPage() {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    cakeType: '',
    flavor: '',
    size: '',
    theme: '',
    eventDate: '',
    deliveryTime: '',
    message: '',
    budget: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      // Simulate form submission
      await new Promise(resolve => setTimeout(resolve, 1000));
      setSubmitStatus('success');
      setFormData({
        name: '',
        phone: '',
        email: '',
        cakeType: '',
        flavor: '',
        size: '',
        theme: '',
        eventDate: '',
        deliveryTime: '',
        message: '',
        budget: ''
      });
    } catch (error) {
      setSubmitStatus('error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const cakeTypes = [
    'Wedding Cake',
    'Birthday Cake',
    'Party Cake',
    'Kids Cake',
    'Custom Design',
    'Other'
  ];

  const flavors = [
    'Vanilla',
    'Chocolate',
    'Red Velvet',
    'Lemon',
    'Strawberry',
    'Funfetti',
    'Carrot',
    'Coconut',
    'Salted Caramel',
    'Mocha',
    'Other'
  ];

  const sizes = [
    'Small (6-8 people)',
    'Medium (10-15 people)',
    'Large (20-25 people)',
    'Extra Large (30+ people)',
    'Multi-tier',
    'Custom Size'
  ];

  const deliveryTimes = [
    'Morning (9am-12pm)',
    'Afternoon (12pm-5pm)',
    'Evening (5pm-8pm)',
    'Flexible'
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50 to-pink-50">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-r from-amber-600 to-pink-600">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">Order Your Perfect Cake</h1>
          <p className="text-xl text-white/90 max-w-2xl mx-auto">
            Let's create something amazing together. Fill out the form below and we'll get back to you within 24 hours.
          </p>
        </div>
      </section>

      {/* Order Form */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <form id="cake-order-form" onSubmit={handleSubmit} className="bg-white rounded-2xl shadow-lg p-8">
              {/* Personal Information */}
              <div className="mb-8">
                <h2 className="text-2xl font-bold text-amber-900 mb-6">Personal Information</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-gray-700 font-medium mb-2">Full Name *</label>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 text-sm"
                      placeholder="Your full name"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-700 font-medium mb-2">Phone Number *</label>
                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 text-sm"
                      placeholder="Your phone number"
                    />
                  </div>
                </div>
                <div className="mt-6">
                  <label className="block text-gray-700 font-medium mb-2">Email Address</label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 text-sm"
                    placeholder="your.email@example.com"
                  />
                </div>
              </div>

              {/* Cake Details */}
              <div className="mb-8">
                <h2 className="text-2xl font-bold text-amber-900 mb-6">Cake Details</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-gray-700 font-medium mb-2">Cake Type *</label>
                    <select
                      name="cakeType"
                      value={formData.cakeType}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 text-sm pr-8"
                    >
                      <option value="">Select cake type</option>
                      {cakeTypes.map((type) => (
                        <option key={type} value={type}>{type}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-gray-700 font-medium mb-2">Flavor *</label>
                    <select
                      name="flavor"
                      value={formData.flavor}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 text-sm pr-8"
                    >
                      <option value="">Select flavor</option>
                      {flavors.map((flavor) => (
                        <option key={flavor} value={flavor}>{flavor}</option>
                      ))}
                    </select>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                  <div>
                    <label className="block text-gray-700 font-medium mb-2">Size *</label>
                    <select
                      name="size"
                      value={formData.size}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 text-sm pr-8"
                    >
                      <option value="">Select size</option>
                      {sizes.map((size) => (
                        <option key={size} value={size}>{size}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-gray-700 font-medium mb-2">Budget Range</label>
                    <input
                      type="text"
                      name="budget"
                      value={formData.budget}
                      onChange={handleChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 text-sm"
                      placeholder="e.g., $100-200"
                    />
                  </div>
                </div>
                <div className="mt-6">
                  <label className="block text-gray-700 font-medium mb-2">Theme/Design Ideas</label>
                  <input
                    type="text"
                    name="theme"
                    value={formData.theme}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 text-sm"
                    placeholder="Describe your theme, colors, or design preferences"
                  />
                </div>
              </div>

              {/* Event Information */}
              <div className="mb-8">
                <h2 className="text-2xl font-bold text-amber-900 mb-6">Event Information</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-gray-700 font-medium mb-2">Event Date *</label>
                    <input
                      type="date"
                      name="eventDate"
                      value={formData.eventDate}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-700 font-medium mb-2">Delivery Time *</label>
                    <select
                      name="deliveryTime"
                      value={formData.deliveryTime}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 text-sm pr-8"
                    >
                      <option value="">Select delivery time</option>
                      {deliveryTimes.map((time) => (
                        <option key={time} value={time}>{time}</option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              {/* Additional Information */}
              <div className="mb-8">
                <h2 className="text-2xl font-bold text-amber-900 mb-6">Additional Information</h2>
                <div>
                  <label className="block text-gray-700 font-medium mb-2">Special Instructions or Requests</label>
                  <textarea
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    rows={4}
                    maxLength={500}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 text-sm resize-none"
                    placeholder="Any special requests, dietary restrictions, or additional details..."
                  />
                  <div className="text-right text-sm text-gray-500 mt-1">
                    {formData.message.length}/500 characters
                  </div>
                </div>
              </div>

              {/* Upload Section */}
              <div className="mb-8">
                <h2 className="text-2xl font-bold text-amber-900 mb-6">Inspiration Photos</h2>
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                  <div className="w-12 h-12 mx-auto mb-4 flex items-center justify-center">
                    <i className="ri-upload-cloud-2-line text-3xl text-gray-400"></i>
                  </div>
                  <p className="text-gray-600 mb-2">Upload inspiration photos or design references</p>
                  <p className="text-sm text-gray-500">Drag and drop files here or click to browse</p>
                  <p className="text-xs text-gray-400 mt-2">Note: File uploads will be marked as "Uncollectable" in our system</p>
                </div>
              </div>

              {/* Submit Button */}
              <div className="text-center">
                <Button 
                  type="submit" 
                  size="lg"
                  disabled={isSubmitting}
                  className="px-12"
                >
                  {isSubmitting ? 'Submitting...' : 'Submit Order Request'}
                </Button>
              </div>

              {/* Status Messages */}
              {submitStatus === 'success' && (
                <div className="mt-6 p-4 bg-green-100 border border-green-400 text-green-700 rounded-lg">
                  <div className="flex items-center">
                    <div className="w-5 h-5 mr-2 flex items-center justify-center">
                      <i className="ri-check-circle-fill"></i>
                    </div>
                    <span>Thank you! Your order request has been submitted successfully. We'll contact you within 24 hours.</span>
                  </div>
                </div>
              )}

              {submitStatus === 'error' && (
                <div className="mt-6 p-4 bg-red-100 border border-red-400 text-red-700 rounded-lg">
                  <div className="flex items-center">
                    <div className="w-5 h-5 mr-2 flex items-center justify-center">
                      <i className="ri-error-warning-fill"></i>
                    </div>
                    <span>There was an error submitting your request. Please try again or contact us directly.</span>
                  </div>
                </div>
              )}
            </form>
          </div>
        </div>
      </section>

      {/* Contact Information */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-amber-900 mb-8">Need Help? Contact Us Directly</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="flex flex-col items-center">
              <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center mb-4">
                <i className="ri-phone-fill text-amber-600 text-xl"></i>
              </div>
              <h3 className="font-semibold text-gray-800 mb-2">Call Us</h3>
              <p className="text-gray-600">020 3881414</p>
              <p className="text-gray-600">0249357450</p>
              <p className="text-gray-600">0502169658</p>
            </div>
            <div className="flex flex-col items-center">
              <div className="w-12 h-12 bg-pink-100 rounded-full flex items-center justify-center mb-4">
                <i className="ri-mail-fill text-pink-600 text-xl"></i>
              </div>
              <h3 className="font-semibold text-gray-800 mb-2">Email Us</h3>
              <p className="text-gray-600">orders@verrloybakeshop.com</p>
            </div>
            <div className="flex flex-col items-center">
              <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center mb-4">
                <i className="ri-time-fill text-amber-600 text-xl"></i>
              </div>
              <h3 className="font-semibold text-gray-800 mb-2">Response Time</h3>
              <p className="text-gray-600">Within 24 hours</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}