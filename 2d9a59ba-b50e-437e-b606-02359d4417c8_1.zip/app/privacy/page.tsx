'use client';

export default function PrivacyPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50 to-pink-50">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-r from-amber-600 to-pink-600">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">Privacy Policy</h1>
          <p className="text-xl text-white/90 max-w-2xl mx-auto">
            Your privacy is important to us. Learn how we protect and use your information.
          </p>
        </div>
      </section>

      {/* Privacy Content */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto bg-white rounded-2xl shadow-lg p-8">
            <div className="prose prose-lg max-w-none">
              <div className="mb-8">
                <p className="text-gray-600 text-sm">Last updated: January 1, 2024</p>
              </div>

              <h2 className="text-2xl font-bold text-amber-900 mb-4">1. Information We Collect</h2>
              <p className="text-gray-700 mb-4">
                We collect information you provide directly to us when you:
              </p>
              <ul className="list-disc list-inside text-gray-700 mb-6 space-y-2">
                <li>Place an order through our website or phone</li>
                <li>Contact us for consultations or support</li>
                <li>Subscribe to our newsletter</li>
                <li>Leave reviews or testimonials</li>
                <li>Interact with our social media accounts</li>
              </ul>

              <h2 className="text-2xl font-bold text-amber-900 mb-4">2. Types of Information</h2>
              <p className="text-gray-700 mb-4">
                The information we collect may include:
              </p>
              <ul className="list-disc list-inside text-gray-700 mb-6 space-y-2">
                <li>Personal identifiers (name, email, phone number)</li>
                <li>Order details and preferences</li>
                <li>Payment information (processed securely)</li>
                <li>Delivery addresses</li>
                <li>Event dates and special requirements</li>
                <li>Photos and design preferences</li>
              </ul>

              <h2 className="text-2xl font-bold text-amber-900 mb-4">3. How We Use Your Information</h2>
              <p className="text-gray-700 mb-4">
                We use the information we collect to:
              </p>
              <ul className="list-disc list-inside text-gray-700 mb-6 space-y-2">
                <li>Process and fulfill your orders</li>
                <li>Communicate with you about your orders</li>
                <li>Provide customer support</li>
                <li>Send you updates about our services</li>
                <li>Improve our products and services</li>
                <li>Comply with legal obligations</li>
              </ul>

              <h2 className="text-2xl font-bold text-amber-900 mb-4">4. Information Sharing</h2>
              <p className="text-gray-700 mb-4">
                We do not sell, trade, or rent your personal information to third parties. We may share your information only in the following circumstances:
              </p>
              <ul className="list-disc list-inside text-gray-700 mb-6 space-y-2">
                <li>With your explicit consent</li>
                <li>To fulfill your orders (delivery services)</li>
                <li>To comply with legal requirements</li>
                <li>To protect our rights and property</li>
              </ul>

              <h2 className="text-2xl font-bold text-amber-900 mb-4">5. Data Security</h2>
              <p className="text-gray-700 mb-6">
                We implement appropriate security measures to protect your personal information against unauthorized access, alteration, disclosure, or destruction. However, no method of transmission over the internet is 100% secure.
              </p>

              <h2 className="text-2xl font-bold text-amber-900 mb-4">6. Data Retention</h2>
              <p className="text-gray-700 mb-6">
                We retain your personal information only for as long as necessary to fulfill the purposes outlined in this privacy policy, unless a longer retention period is required or permitted by law.
              </p>

              <h2 className="text-2xl font-bold text-amber-900 mb-4">7. Your Rights</h2>
              <p className="text-gray-700 mb-4">
                You have the right to:
              </p>
              <ul className="list-disc list-inside text-gray-700 mb-6 space-y-2">
                <li>Access your personal information</li>
                <li>Correct inaccurate information</li>
                <li>Request deletion of your information</li>
                <li>Opt out of marketing communications</li>
                <li>File a complaint with regulatory authorities</li>
              </ul>

              <h2 className="text-2xl font-bold text-amber-900 mb-4">8. Cookies and Tracking</h2>
              <p className="text-gray-700 mb-6">
                Our website uses cookies to enhance your browsing experience. You can control cookie settings through your browser preferences. Some features may not function properly if cookies are disabled.
              </p>

              <h2 className="text-2xl font-bold text-amber-900 mb-4">9. Third-Party Services</h2>
              <p className="text-gray-700 mb-6">
                Our website may contain links to third-party services. We are not responsible for the privacy practices of these external sites. We encourage you to review their privacy policies.
              </p>

              <h2 className="text-2xl font-bold text-amber-900 mb-4">10. Changes to This Policy</h2>
              <p className="text-gray-700 mb-6">
                We may update this privacy policy from time to time. We will notify you of any significant changes by posting the new policy on our website with an updated effective date.
              </p>

              <h2 className="text-2xl font-bold text-amber-900 mb-4">11. Contact Us</h2>
              <p className="text-gray-700 mb-4">
                If you have any questions about this privacy policy, please contact us:
              </p>
              <div className="bg-amber-50 p-4 rounded-lg">
                <p className="text-gray-700"><strong>Phone:</strong> 020 3881414, 0249357450, 0502169658</p>
                <p className="text-gray-700"><strong>Email:</strong> privacy@verrloybakeshop.com</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}