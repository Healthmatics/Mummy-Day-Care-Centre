'use client';

import { useState } from 'react';
import Button from '@/components/ui/Button';

export default function TestimonialsPage() {
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [newReview, setNewReview] = useState({
    name: '',
    email: '',
    rating: 5,
    cakeType: '',
    review: ''
  });

  const testimonials = [
    {
      id: 1,
      name: 'Sarah Johnson',
      rating: 5,
      cakeType: 'Wedding Cake',
      review: 'Absolutely stunning! Our wedding cake exceeded all expectations. The three-tier design with cascading roses was breathtaking, and the taste was divine. Every guest complimented the cake. Verrloy\'s team made our special day even more memorable.',
      image: 'https://readdy.ai/api/search-image?query=elegant%20white%20wedding%20cake%20with%20pink%20roses%2C%20three%20tiers%2C%20beautiful%20presentation%20at%20wedding%20reception%20with%20happy%20couple%20in%20background&width=400&height=300&seq=testimonial-1&orientation=landscape',
      date: '2024-02-15'
    },
    {
      id: 2,
      name: 'Michael Chen',
      rating: 5,
      cakeType: 'Birthday Cake',
      review: 'My daughter\'s unicorn birthday cake was absolutely magical! The attention to detail was incredible - from the rainbow mane to the sparkly horn. She hasn\'t stopped talking about it. Thank you for making her 6th birthday so special!',
      image: 'https://readdy.ai/api/search-image?query=magical%20unicorn%20birthday%20cake%20with%20rainbow%20mane%2C%20sparkles%2C%20happy%20little%20girl%20celebrating%20birthday%20party%20with%20friends&width=400&height=300&seq=testimonial-2&orientation=landscape',
      date: '2024-01-28'
    },
    {
      id: 3,
      name: 'Emily Rodriguez',
      rating: 5,
      cakeType: 'Party Cake',
      review: 'The gold celebration cake for our anniversary party was sophisticated and elegant. The design perfectly matched our event theme, and the champagne flavor was a hit with all our guests. Professional service from start to finish.',
      image: 'https://readdy.ai/api/search-image?query=elegant%20gold%20celebration%20cake%20at%20anniversary%20party%2C%20sophisticated%20design%20with%20happy%20couple%20celebrating%20with%20guests&width=400&height=300&seq=testimonial-3&orientation=landscape',
      date: '2024-01-12'
    },
    {
      id: 4,
      name: 'David Williams',
      rating: 5,
      cakeType: 'Custom Design',
      review: 'Verrloy\'s created a custom corporate cake for our company\'s 10th anniversary. The design incorporated our logo beautifully, and the presentation was flawless. Our clients and employees were impressed. Highly recommended for corporate events.',
      image: 'https://readdy.ai/api/search-image?query=professional%20corporate%20anniversary%20cake%20with%20company%20logo%2C%20business%20celebration%20setting%20with%20employees%20celebrating&width=400&height=300&seq=testimonial-4&orientation=landscape',
      date: '2024-01-05'
    },
    {
      id: 5,
      name: 'Lisa Thompson',
      rating: 5,
      cakeType: 'Wedding Cake',
      review: 'From the initial consultation to the final delivery, everything was perfect. The rustic buttercream wedding cake with fresh flowers was exactly what we envisioned. The team was professional, creative, and delivered on time. Worth every penny!',
      image: 'https://readdy.ai/api/search-image?query=rustic%20buttercream%20wedding%20cake%20with%20fresh%20flowers%20at%20outdoor%20garden%20wedding%2C%20bride%20and%20groom%20cutting%20cake&width=400&height=300&seq=testimonial-5&orientation=landscape',
      date: '2023-12-20'
    },
    {
      id: 6,
      name: 'James Park',
      rating: 5,
      cakeType: 'Kids Cake',
      review: 'The superhero cake for my son\'s 8th birthday was incredible! The detail in the comic book design and the vibrant colors made it the centerpiece of the party. All the kids were amazed. Thank you for bringing his superhero dreams to life!',
      image: 'https://readdy.ai/api/search-image?query=superhero%20themed%20birthday%20cake%20with%20comic%20book%20design%2C%20excited%20kids%20at%20birthday%20party%20celebrating%20with%20balloons&width=400&height=300&seq=testimonial-6&orientation=landscape',
      date: '2023-12-08'
    }
  ];

  const handleReviewSubmit = (e) => {
    e.preventDefault();
    // Handle review submission logic here
    alert('Thank you for your review! We appreciate your feedback.');
    setNewReview({
      name: '',
      email: '',
      rating: 5,
      cakeType: '',
      review: ''
    });
    setShowReviewForm(false);
  };

  const renderStars = (rating) => {
    return Array.from({ length: 5 }, (_, i) => (
      <i
        key={i}
        className={`ri-star-${i < rating ? 'fill' : 'line'} text-yellow-400`}
      ></i>
    ));
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50 to-pink-50">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-r from-amber-600 to-pink-600">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">Customer Testimonials</h1>
          <p className="text-xl text-white/90 max-w-2xl mx-auto">
            See what our happy customers have to say about their sweet experiences with us
          </p>
        </div>
      </section>

      {/* Statistics */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-amber-600 mb-2">500+</div>
              <div className="text-gray-600">Happy Customers</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-pink-600 mb-2">4.9</div>
              <div className="text-gray-600">Average Rating</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-amber-600 mb-2">1000+</div>
              <div className="text-gray-600">Cakes Created</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-pink-600 mb-2">98%</div>
              <div className="text-gray-600">Satisfaction Rate</div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Grid */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-amber-900 mb-4">What Our Customers Say</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Real reviews from real customers who trusted us with their special moments
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {testimonials.map((testimonial) => (
              <div key={testimonial.id} className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
                <div className="relative">
                  <img
                    src={testimonial.image}
                    alt={`${testimonial.cakeType} for ${testimonial.name}`}
                    className="w-full h-48 object-cover object-top"
                  />
                  <div className="absolute top-4 right-4 bg-white rounded-full px-3 py-1 shadow-md">
                    <div className="flex items-center space-x-1">
                      {renderStars(testimonial.rating)}
                    </div>
                  </div>
                </div>
                
                <div className="p-6">
                  <div className="flex items-center mb-4">
                    <div className="w-10 h-10 bg-gradient-to-r from-amber-400 to-pink-400 rounded-full flex items-center justify-center text-white font-bold">
                      {testimonial.name.charAt(0)}
                    </div>
                    <div className="ml-3">
                      <div className="font-semibold text-gray-800">{testimonial.name}</div>
                      <div className="text-sm text-gray-600">{testimonial.cakeType}</div>
                    </div>
                  </div>
                  
                  <p className="text-gray-700 leading-relaxed mb-4">{testimonial.review}</p>
                  
                  <div className="text-sm text-gray-500">
                    {new Date(testimonial.date).toLocaleDateString('en-US', {
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric'
                    })}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Review Form */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-amber-900 mb-4">Share Your Experience</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto mb-8">
              We'd love to hear about your experience with Verrloy's Bake Shop
            </p>
            
            {!showReviewForm ? (
              <Button onClick={() => setShowReviewForm(true)} size="lg">
                Write a Review
              </Button>
            ) : (
              <div className="max-w-2xl mx-auto">
                <form onSubmit={handleReviewSubmit} className="bg-amber-50 rounded-2xl p-8">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <div>
                      <label className="block text-gray-700 font-medium mb-2">Name *</label>
                      <input
                        type="text"
                        required
                        value={newReview.name}
                        onChange={(e) => setNewReview({...newReview, name: e.target.value})}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 text-sm"
                        placeholder="Your name"
                      />
                    </div>
                    <div>
                      <label className="block text-gray-700 font-medium mb-2">Email</label>
                      <input
                        type="email"
                        value={newReview.email}
                        onChange={(e) => setNewReview({...newReview, email: e.target.value})}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 text-sm"
                        placeholder="your.email@example.com"
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <div>
                      <label className="block text-gray-700 font-medium mb-2">Rating *</label>
                      <div className="flex space-x-2">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <button
                            key={star}
                            type="button"
                            onClick={() => setNewReview({...newReview, rating: star})}
                            className="text-2xl cursor-pointer hover:scale-110 transition-transform"
                          >
                            <i className={`ri-star-${star <= newReview.rating ? 'fill' : 'line'} text-yellow-400`}></i>
                          </button>
                        ))}
                      </div>
                    </div>
                    <div>
                      <label className="block text-gray-700 font-medium mb-2">Cake Type</label>
                      <input
                        type="text"
                        value={newReview.cakeType}
                        onChange={(e) => setNewReview({...newReview, cakeType: e.target.value})}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 text-sm"
                        placeholder="e.g., Wedding Cake, Birthday Cake"
                      />
                    </div>
                  </div>
                  
                  <div className="mb-6">
                    <label className="block text-gray-700 font-medium mb-2">Your Review *</label>
                    <textarea
                      required
                      value={newReview.review}
                      onChange={(e) => setNewReview({...newReview, review: e.target.value})}
                      rows={4}
                      maxLength={500}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 text-sm resize-none"
                      placeholder="Tell us about your experience..."
                    />
                    <div className="text-right text-sm text-gray-500 mt-1">
                      {newReview.review.length}/500 characters
                    </div>
                  </div>
                  
                  <div className="flex space-x-4">
                    <Button type="submit" className="flex-1">
                      Submit Review
                    </Button>
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => setShowReviewForm(false)}
                      className="flex-1"
                    >
                      Cancel
                    </Button>
                  </div>
                </form>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 bg-gradient-to-r from-amber-600 to-pink-600">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-white mb-6">Ready to Create Your Own Sweet Memory?</h2>
          <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
            Join our happy customers and let us create something amazing for your special occasion
          </p>
          <Button size="lg" className="bg-white text-amber-600 hover:bg-gray-100">
            Order Your Cake Today
          </Button>
        </div>
      </section>
    </div>
  );
}