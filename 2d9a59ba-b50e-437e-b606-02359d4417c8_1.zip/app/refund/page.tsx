'use client';

export default function RefundPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50 to-pink-50">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-r from-amber-600 to-pink-600">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">Refund Policy</h1>
          <p className="text-xl text-white/90 max-w-2xl mx-auto">
            Understanding our refund and cancellation policies
          </p>
        </div>
      </section>

      {/* Refund Content */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto bg-white rounded-2xl shadow-lg p-8">
            <div className="prose prose-lg max-w-none">
              <div className="mb-8">
                <p className="text-gray-600 text-sm">Last updated: January 1, 2024</p>
              </div>

              <h2 className="text-2xl font-bold text-amber-900 mb-4">1. General Refund Policy</h2>
              <p className="text-gray-700 mb-6">
                At Verrloy's Bake Shop, we strive to provide exceptional service and high-quality products. Due to the custom nature of our cakes and the perishable nature of our products, refunds are handled on a case-by-case basis according to the policies outlined below.
              </p>

              <h2 className="text-2xl font-bold text-amber-900 mb-4">2. Order Cancellations</h2>
              
              <h3 className="text-xl font-semibold text-amber-800 mb-3">2.1 Standard Orders</h3>
              <ul className="list-disc list-inside text-gray-700 mb-4 space-y-2">
                <li><strong>48+ hours before delivery:</strong> Full refund of deposit and any payments made</li>
                <li><strong>24-48 hours before delivery:</strong> 50% refund of deposit</li>
                <li><strong>Less than 24 hours:</strong> No refund of deposit</li>
              </ul>

              <h3 className="text-xl font-semibold text-amber-800 mb-3">2.2 Wedding Cakes</h3>
              <ul className="list-disc list-inside text-gray-700 mb-6 space-y-2">
                <li><strong>7+ days before event:</strong> Full refund minus 25% processing fee</li>
                <li><strong>3-7 days before event:</strong> 50% refund</li>
                <li><strong>Less than 3 days:</strong> No refund</li>
              </ul>

              <h2 className="text-2xl font-bold text-amber-900 mb-4">3. Quality Guarantee</h2>
              <p className="text-gray-700 mb-4">
                We guarantee the quality of our products. If you are not satisfied with your order due to:
              </p>
              <ul className="list-disc list-inside text-gray-700 mb-6 space-y-2">
                <li>Significant deviation from agreed design</li>
                <li>Quality issues with taste or texture</li>
                <li>Damage during delivery (our fault)</li>
                <li>Late delivery (our fault)</li>
              </ul>
              <p className="text-gray-700 mb-6">
                Please contact us within 24 hours of delivery for a full refund or replacement.
              </p>

              <h2 className="text-2xl font-bold text-amber-900 mb-4">4. Non-Refundable Situations</h2>
              <p className="text-gray-700 mb-4">
                Refunds will not be provided in the following circumstances:
              </p>
              <ul className="list-disc list-inside text-gray-700 mb-6 space-y-2">
                <li>Change of mind after order confirmation</li>
                <li>Customer unavailable for scheduled delivery</li>
                <li>Damage after successful delivery</li>
                <li>Allergic reactions (unless we were notified in advance)</li>
                <li>Weather-related delivery delays beyond our control</li>
                <li>Incorrect delivery address provided by customer</li>
              </ul>

              <h2 className="text-2xl font-bold text-amber-900 mb-4">5. Refund Process</h2>
              <p className="text-gray-700 mb-4">
                To request a refund:
              </p>
              <ol className="list-decimal list-inside text-gray-700 mb-6 space-y-2">
                <li>Contact us immediately at 020 3881414 or refunds@verrloybakeshop.com</li>
                <li>Provide your order number and reason for refund</li>
                <li>Include photos if applicable (quality issues)</li>
                <li>We will review your request within 24 hours</li>
                <li>Approved refunds will be processed within 5-7 business days</li>
              </ol>

              <h2 className="text-2xl font-bold text-amber-900 mb-4">6. Refund Methods</h2>
              <p className="text-gray-700 mb-4">
                Refunds will be issued using the same payment method used for the original purchase:
              </p>
              <ul className="list-disc list-inside text-gray-700 mb-6 space-y-2">
                <li>Credit card refunds: 3-5 business days</li>
                <li>Bank transfer refunds: 5-7 business days</li>
                <li>Cash payments: Immediate upon approval</li>
              </ul>

              <h2 className="text-2xl font-bold text-amber-900 mb-4">7. Partial Refunds</h2>
              <p className="text-gray-700 mb-6">
                In some cases, we may offer partial refunds for orders that are partially completed or where minor issues are present. The refund amount will be determined based on the specific circumstances of each case.
              </p>

              <h2 className="text-2xl font-bold text-amber-900 mb-4">8. Dispute Resolution</h2>
              <p className="text-gray-700 mb-6">
                If you are not satisfied with our refund decision, you may escalate the matter to our management team. We are committed to finding a fair resolution for all parties involved.
              </p>

              <h2 className="text-2xl font-bold text-amber-900 mb-4">9. Force Majeure</h2>
              <p className="text-gray-700 mb-6">
                In cases of extreme weather, natural disasters, or other circumstances beyond our control that prevent delivery, we will work with customers to reschedule or provide alternative solutions. Full refunds may be available in these exceptional circumstances.
              </p>

              <h2 className="text-2xl font-bold text-amber-900 mb-4">10. Policy Updates</h2>
              <p className="text-gray-700 mb-6">
                This refund policy may be updated from time to time. Any changes will be posted on our website with an updated effective date. Continued use of our services constitutes acceptance of any policy changes.
              </p>

              <h2 className="text-2xl font-bold text-amber-900 mb-4">11. Contact Information</h2>
              <p className="text-gray-700 mb-4">
                For refund requests or questions about this policy, please contact us:
              </p>
              <div className="bg-amber-50 p-4 rounded-lg">
                <p className="text-gray-700"><strong>Phone:</strong> 020 3881414, 0249357450, 0502169658</p>
                <p className="text-gray-700"><strong>Email:</strong> refunds@verrloybakeshop.com</p>
                <p className="text-gray-700"><strong>Business Hours:</strong> Monday-Friday 8AM-7PM, Saturday 9AM-6PM, Sunday 10AM-4PM</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}