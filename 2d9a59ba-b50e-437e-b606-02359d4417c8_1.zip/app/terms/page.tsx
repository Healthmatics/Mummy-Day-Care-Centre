'use client';

export default function TermsPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50 to-pink-50">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-r from-amber-600 to-pink-600">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">Terms of Service</h1>
          <p className="text-xl text-white/90 max-w-2xl mx-auto">
            Please read these terms carefully before using our services
          </p>
        </div>
      </section>

      {/* Terms Content */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto bg-white rounded-2xl shadow-lg p-8">
            <div className="prose prose-lg max-w-none">
              <div className="mb-8">
                <p className="text-gray-600 text-sm">Last updated: January 1, 2024</p>
              </div>

              <h2 className="text-2xl font-bold text-amber-900 mb-4">1. Acceptance of Terms</h2>
              <p className="text-gray-700 mb-6">
                By accessing and using Verrloy's Bake Shop services, you accept and agree to be bound by the terms and provision of this agreement. These terms apply to all visitors, users, and customers of our bakery services.
              </p>

              <h2 className="text-2xl font-bold text-amber-900 mb-4">2. Services</h2>
              <p className="text-gray-700 mb-4">
                Verrloy's Bake Shop provides custom cake design, baking, and delivery services. Our services include but are not limited to:
              </p>
              <ul className="list-disc list-inside text-gray-700 mb-6 space-y-2">
                <li>Wedding cakes</li>
                <li>Birthday cakes</li>
                <li>Party cakes</li>
                <li>Kids cakes</li>
                <li>Custom cake designs</li>
                <li>Consultation services</li>
              </ul>

              <h2 className="text-2xl font-bold text-amber-900 mb-4">3. Ordering and Payment</h2>
              <p className="text-gray-700 mb-4">
                Orders must be placed in advance. Payment terms are as follows:
              </p>
              <ul className="list-disc list-inside text-gray-700 mb-6 space-y-2">
                <li>A 50% deposit is required to confirm your order</li>
                <li>Final payment is due upon delivery or pickup</li>
                <li>We accept cash, credit cards, and bank transfers</li>
                <li>Prices are subject to change without notice</li>
              </ul>

              <h2 className="text-2xl font-bold text-amber-900 mb-4">4. Delivery and Pickup</h2>
              <p className="text-gray-700 mb-4">
                Delivery and pickup policies include:
              </p>
              <ul className="list-disc list-inside text-gray-700 mb-6 space-y-2">
                <li>Delivery is available within a 15-mile radius</li>
                <li>Delivery fees apply based on distance and cake size</li>
                <li>We are not responsible for damage after delivery</li>
                <li>Pickup times must be scheduled in advance</li>
              </ul>

              <h2 className="text-2xl font-bold text-amber-900 mb-4">5. Cancellations and Refunds</h2>
              <p className="text-gray-700 mb-4">
                Our cancellation policy is as follows:
              </p>
              <ul className="list-disc list-inside text-gray-700 mb-6 space-y-2">
                <li>Orders can be cancelled up to 48 hours before scheduled delivery/pickup</li>
                <li>Cancellations made less than 48 hours in advance may result in forfeiture of deposit</li>
                <li>Wedding cake cancellations require 7 days notice</li>
                <li>Custom design orders may have different cancellation terms</li>
              </ul>

              <h2 className="text-2xl font-bold text-amber-900 mb-4">6. Liability</h2>
              <p className="text-gray-700 mb-6">
                Verrloy's Bake Shop shall not be liable for any damages arising from the use of our services beyond the cost of the product. We are not responsible for allergic reactions unless specifically notified of allergies in advance.
              </p>

              <h2 className="text-2xl font-bold text-amber-900 mb-4">7. Intellectual Property</h2>
              <p className="text-gray-700 mb-6">
                All custom designs created by Verrloy's Bake Shop remain our intellectual property. Customers may not reproduce or distribute our designs without written permission.
              </p>

              <h2 className="text-2xl font-bold text-amber-900 mb-4">8. Privacy</h2>
              <p className="text-gray-700 mb-6">
                We respect your privacy and are committed to protecting your personal information. Please refer to our Privacy Policy for details on how we collect, use, and protect your data.
              </p>

              <h2 className="text-2xl font-bold text-amber-900 mb-4">9. Modifications</h2>
              <p className="text-gray-700 mb-6">
                We reserve the right to modify these terms at any time. Changes will be effective immediately upon posting on our website. Continued use of our services constitutes acceptance of modified terms.
              </p>

              <h2 className="text-2xl font-bold text-amber-900 mb-4">10. Contact Information</h2>
              <p className="text-gray-700 mb-4">
                For questions about these terms, please contact us:
              </p>
              <div className="bg-amber-50 p-4 rounded-lg">
                <p className="text-gray-700"><strong>Phone:</strong> 020 3881414, 0249357450, 0502169658</p>
                <p className="text-gray-700"><strong>Email:</strong> info@verrloybakeshop.com</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}