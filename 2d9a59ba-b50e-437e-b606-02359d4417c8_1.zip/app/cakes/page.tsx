'use client';

import { useState } from 'react';
import Link from 'next/link';
import Button from '@/components/ui/Button';

export default function CakesPage() {
  const [activeCategory, setActiveCategory] = useState('wedding');

  const categories = [
    { id: 'wedding', name: 'Wedding Cakes', icon: 'ri-heart-fill' },
    { id: 'birthday', name: 'Birthday Cakes', icon: 'ri-gift-fill' },
    { id: 'party', name: 'Party Cakes', icon: 'ri-star-fill' },
    { id: 'kids', name: 'Kids Cakes', icon: 'ri-cake-fill' },
    { id: 'custom', name: 'Custom Designs', icon: 'ri-palette-fill' }
  ];

  const cakes = {
    wedding: [
      {
        id: 1,
        name: 'Elegant Rose Wedding Cake',
        image: 'https://readdy.ai/api/search-image?query=elegant%20three-tier%20white%20wedding%20cake%20with%20pink%20fondant%20roses%2C%20delicate%20pearl%20details%2C%20smooth%20buttercream%20frosting%2C%20displayed%20on%20crystal%20stand%20in%20luxury%20bridal%20setting&width=600&height=800&seq=wedding-1&orientation=portrait',
        description: 'Classic three-tier cake with handcrafted sugar roses and pearl accents',
        price: 'Starting from $450',
        flavors: ['Vanilla', 'Chocolate', 'Red Velvet', 'Lemon']
      },
      {
        id: 2,
        name: 'Modern Minimalist Wedding Cake',
        image: 'https://readdy.ai/api/search-image?query=modern%20minimalist%20white%20wedding%20cake%20with%20geometric%20design%2C%20gold%20accents%2C%20clean%20lines%2C%20displayed%20on%20marble%20pedestal%20in%20contemporary%20setting&width=600&height=800&seq=wedding-2&orientation=portrait',
        description: 'Contemporary design with clean lines and gold geometric details',
        price: 'Starting from $380',
        flavors: ['Vanilla Bean', 'Strawberry', 'Chocolate', 'Carrot']
      },
      {
        id: 3,
        name: 'Rustic Buttercream Wedding Cake',
        image: 'https://readdy.ai/api/search-image?query=rustic%20buttercream%20wedding%20cake%20with%20textured%20frosting%2C%20fresh%20flowers%2C%20natural%20organic%20look%2C%20displayed%20on%20wooden%20stand%20in%20garden%20setting&width=600&height=800&seq=wedding-3&orientation=portrait',
        description: 'Textured buttercream finish with fresh seasonal flowers',
        price: 'Starting from $420',
        flavors: ['Vanilla', 'Funfetti', 'Chocolate', 'Coconut']
      }
    ],
    birthday: [
      {
        id: 4,
        name: 'Rainbow Layer Birthday Cake',
        image: 'https://readdy.ai/api/search-image?query=colorful%20rainbow%20layer%20birthday%20cake%20with%20vibrant%20colored%20sponge%20layers%2C%20white%20buttercream%20frosting%2C%20sprinkles%2C%20displayed%20on%20festive%20party%20table&width=600&height=800&seq=birthday-1&orientation=portrait',
        description: 'Multi-colored layers with vanilla buttercream and rainbow sprinkles',
        price: 'Starting from $85',
        flavors: ['Vanilla Rainbow', 'Chocolate', 'Strawberry', 'Funfetti']
      },
      {
        id: 5,
        name: 'Chocolate Drip Birthday Cake',
        image: 'https://readdy.ai/api/search-image?query=chocolate%20birthday%20cake%20with%20dark%20chocolate%20ganache%20dripping%20down%20sides%2C%20gold%20decorations%2C%20macarons%20on%20top%2C%20elegant%20presentation%20on%20cake%20stand&width=600&height=800&seq=birthday-2&orientation=portrait',
        description: 'Rich chocolate cake with decadent ganache drip and gold accents',
        price: 'Starting from $95',
        flavors: ['Double Chocolate', 'Salted Caramel', 'Mocha', 'Dark Chocolate']
      },
      {
        id: 6,
        name: 'Floral Birthday Cake',
        image: 'https://readdy.ai/api/search-image?query=elegant%20birthday%20cake%20with%20buttercream%20flower%20decorations%2C%20pink%20and%20white%20roses%2C%20smooth%20frosting%2C%20displayed%20on%20vintage%20cake%20stand&width=600&height=800&seq=birthday-3&orientation=portrait',
        description: 'Beautifully piped buttercream flowers in soft pastel colors',
        price: 'Starting from $78',
        flavors: ['Vanilla', 'Lemon', 'Strawberry', 'Red Velvet']
      }
    ],
    party: [
      {
        id: 7,
        name: 'Gold Celebration Cake',
        image: 'https://readdy.ai/api/search-image?query=sophisticated%20party%20cake%20with%20gold%20leaf%20accents%2C%20white%20fondant%2C%20elegant%20decorations%2C%20displayed%20on%20luxury%20event%20table%20setting&width=600&height=800&seq=party-1&orientation=portrait',
        description: 'Elegant cake with edible gold leaf and sophisticated design',
        price: 'Starting from $125',
        flavors: ['Champagne', 'Vanilla', 'Chocolate', 'Lemon']
      },
      {
        id: 8,
        name: 'Tropical Paradise Cake',
        image: 'https://readdy.ai/api/search-image?query=tropical%20themed%20party%20cake%20with%20coconut%20frosting%2C%20pineapple%20decorations%2C%20palm%20leaves%2C%20bright%20colors%2C%20island%20paradise%20theme&width=600&height=800&seq=party-2&orientation=portrait',
        description: 'Tropical-themed cake perfect for summer celebrations',
        price: 'Starting from $98',
        flavors: ['Coconut', 'Pineapple', 'Mango', 'Vanilla']
      },
      {
        id: 9,
        name: 'Vintage Elegance Cake',
        image: 'https://readdy.ai/api/search-image?query=vintage%20style%20party%20cake%20with%20intricate%20piping%2C%20lace%20patterns%2C%20pearl%20details%2C%20antique%20color%20scheme%2C%20displayed%20on%20ornate%20cake%20stand&width=600&height=800&seq=party-3&orientation=portrait',
        description: 'Vintage-inspired design with intricate piping and lace details',
        price: 'Starting from $115',
        flavors: ['Earl Grey', 'Vanilla', 'Lavender', 'Lemon']
      }
    ],
    kids: [
      {
        id: 10,
        name: 'Unicorn Dream Cake',
        image: 'https://readdy.ai/api/search-image?query=magical%20unicorn%20birthday%20cake%20with%20rainbow%20mane%2C%20horn%2C%20pastel%20colors%2C%20sparkles%2C%20whimsical%20design%20on%20colorful%20party%20background&width=600&height=800&seq=kids-1&orientation=portrait',
        description: 'Magical unicorn cake with rainbow mane and edible glitter',
        price: 'Starting from $88',
        flavors: ['Vanilla', 'Strawberry', 'Funfetti', 'Cotton Candy']
      },
      {
        id: 11,
        name: 'Superhero Adventure Cake',
        image: 'https://readdy.ai/api/search-image?query=superhero%20themed%20birthday%20cake%20with%20comic%20book%20design%2C%20bright%20primary%20colors%2C%20action%20figures%2C%20cape%20decorations%2C%20fun%20party%20setting&width=600&height=800&seq=kids-2&orientation=portrait',
        description: 'Action-packed superhero design with vibrant colors',
        price: 'Starting from $92',
        flavors: ['Chocolate', 'Vanilla', 'Red Velvet', 'Cookies & Cream']
      },
      {
        id: 12,
        name: 'Princess Castle Cake',
        image: 'https://readdy.ai/api/search-image?query=princess%20castle%20birthday%20cake%20with%20pink%20towers%2C%20fondant%20decorations%2C%20sparkles%2C%20fairy%20tale%20theme%2C%20displayed%20on%20magical%20party%20table&width=600&height=800&seq=kids-3&orientation=portrait',
        description: 'Fairy tale castle design with pink towers and princess themes',
        price: 'Starting from $95',
        flavors: ['Pink Vanilla', 'Strawberry', 'Funfetti', 'Lemon']
      }
    ],
    custom: [
      {
        id: 13,
        name: 'Corporate Logo Cake',
        image: 'https://readdy.ai/api/search-image?query=professional%20corporate%20cake%20with%20company%20logo%2C%20clean%20modern%20design%2C%20business%20colors%2C%20displayed%20in%20office%20conference%20room%20setting&width=600&height=800&seq=custom-1&orientation=portrait',
        description: 'Professional designs for corporate events and celebrations',
        price: 'Quote on request',
        flavors: ['Any flavor available']
      },
      {
        id: 14,
        name: 'Themed Event Cake',
        image: 'https://readdy.ai/api/search-image?query=custom%20themed%20event%20cake%20with%20unique%20design%20elements%2C%20artistic%20details%2C%20specialized%20decorations%2C%20displayed%20at%20special%20event%20venue&width=600&height=800&seq=custom-2&orientation=portrait',
        description: 'Completely customized cakes for special themes and events',
        price: 'Quote on request',
        flavors: ['Any flavor available']
      },
      {
        id: 15,
        name: 'Artistic Sculpture Cake',
        image: 'https://readdy.ai/api/search-image?query=artistic%20sculpture%20cake%20with%203D%20design%2C%20intricate%20details%2C%20modern%20art%20style%2C%20displayed%20in%20gallery-like%20setting%20with%20dramatic%20lighting&width=600&height=800&seq=custom-3&orientation=portrait',
        description: 'Edible art pieces that are as beautiful as they are delicious',
        price: 'Quote on request',
        flavors: ['Any flavor available']
      }
    ]
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50 to-pink-50">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-r from-amber-600 to-pink-600">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">Our Delicious Cakes</h1>
          <p className="text-xl text-white/90 max-w-2xl mx-auto">
            From elegant wedding cakes to fun birthday creations, we have something special for every occasion
          </p>
        </div>
      </section>

      {/* Category Navigation */}
      <section className="py-12 bg-white shadow-sm">
        <div className="container mx-auto px-4">
          <div className="flex flex-wrap justify-center gap-4">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setActiveCategory(category.id)}
                className={`px-6 py-3 rounded-full font-semibold transition-all cursor-pointer whitespace-nowrap ${
                  activeCategory === category.id
                    ? 'bg-amber-600 text-white shadow-md'
                    : 'bg-gray-100 text-gray-700 hover:bg-amber-100'
                }`}
              >
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 flex items-center justify-center">
                    <i className={category.icon}></i>
                  </div>
                  <span>{category.name}</span>
                </div>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Cakes Grid */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {cakes[activeCategory].map((cake) => (
              <div key={cake.id} className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
                <div className="relative overflow-hidden">
                  <img
                    src={cake.image}
                    alt={cake.name}
                    className="w-full h-64 object-cover object-top hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-4 right-4 bg-amber-600 text-white px-3 py-1 rounded-full text-sm font-semibold">
                    {cake.price}
                  </div>
                </div>
                
                <div className="p-6">
                  <h3 className="text-xl font-semibold text-amber-900 mb-3">{cake.name}</h3>
                  <p className="text-gray-600 mb-4">{cake.description}</p>
                  
                  <div className="mb-4">
                    <h4 className="font-medium text-gray-800 mb-2">Available Flavors:</h4>
                    <div className="flex flex-wrap gap-2">
                      {cake.flavors.map((flavor, index) => (
                        <span key={index} className="px-2 py-1 bg-pink-100 text-pink-700 rounded-full text-sm">
                          {flavor}
                        </span>
                      ))}
                    </div>
                  </div>
                  
                  <Link href="/order">
                    <Button className="w-full">
                      Order This Cake
                    </Button>
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-amber-900 mb-4">Can't Find What You're Looking For?</h2>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            We love creating custom designs! Let us know your vision and we'll bring it to life.
          </p>
          <Link href="/contact">
            <Button size="lg" variant="secondary">
              Request Custom Design
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}