'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import Button from '@/components/ui/Button';

export default function Home() {
  const [currentSlide, setCurrentSlide] = useState(0);

  const heroImages = [
    {
      src: 'https://readdy.ai/api/search-image?query=elegant%20three-tier%20white%20wedding%20cake%20with%20delicate%20pink%20rose%20decorations%2C%20smooth%20buttercream%20frosting%2C%20displayed%20on%20marble%20pedestal%20in%20bright%20modern%20bakery%20setting%20with%20soft%20natural%20lighting%20and%20clean%20minimalist%20background&width=1920&height=1080&seq=wedding-cake-hero&orientation=landscape',
      alt: 'Wedding Cake',
      title: 'Wedding Cakes'
    },
    {
      src: 'https://readdy.ai/api/search-image?query=colorful%20birthday%20cake%20with%20rainbow%20layers%2C%20vanilla%20buttercream%20frosting%2C%20decorated%20with%20sprinkles%20and%20birthday%20candles%2C%20displayed%20on%20rustic%20wooden%20table%20with%20party%20decorations%20in%20warm%20bakery%20interior&width=1920&height=1080&seq=birthday-cake-hero&orientation=landscape',
      alt: 'Birthday Cake',
      title: 'Birthday Cakes'
    },
    {
      src: 'https://readdy.ai/api/search-image?query=festive%20party%20cake%20with%20gold%20accents%2C%20chocolate%20ganache%20dripping%2C%20fresh%20berries%20on%20top%2C%20elegant%20presentation%20on%20glass%20stand%20in%20sophisticated%20bakery%20setting%20with%20warm%20golden%20lighting&width=1920&height=1080&seq=party-cake-hero&orientation=landscape',
      alt: 'Party Cake',
      title: 'Party Cakes'
    }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % heroImages.length);
    }, 5000);

    return () => clearInterval(timer);
  }, []);

  const services = [
    {
      icon: 'ri-heart-fill',
      title: 'Wedding Cakes',
      description: 'Elegant multi-tier cakes for your special day',
      color: 'text-pink-500'
    },
    {
      icon: 'ri-gift-fill',
      title: 'Birthday Cakes',
      description: 'Custom designs for memorable celebrations',
      color: 'text-amber-500'
    },
    {
      icon: 'ri-star-fill',
      title: 'Party Cakes',
      description: 'Perfect centerpieces for any occasion',
      color: 'text-pink-500'
    },
    {
      icon: 'ri-palette-fill',
      title: 'Custom Designs',
      description: 'Unique creations tailored to your vision',
      color: 'text-amber-500'
    }
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="relative h-screen overflow-hidden">
        <div className="absolute inset-0">
          {heroImages.map((image, index) => (
            <div
              key={index}
              className={`absolute inset-0 transition-opacity duration-1000 ${
                index === currentSlide ? 'opacity-100' : 'opacity-0'
              }`}
            >
              <img
                src={image.src}
                alt={image.alt}
                className="w-full h-full object-cover object-top"
              />
              <div className="absolute inset-0 bg-black/40"></div>
            </div>
          ))}
        </div>

        <div className="relative z-10 container mx-auto px-4 h-full flex items-center">
          <div className="w-full max-w-2xl text-white">
            <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
              Bringing Sweet Dreams to Life
            </h1>
            <p className="text-xl md:text-2xl mb-8 font-light">
              One Slice at a Time
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/order">
                <Button size="lg" className="w-full sm:w-auto">
                  Order Now
                </Button>
              </Link>
              <Link href="/contact">
                <Button variant="outline" size="lg" className="w-full sm:w-auto bg-white/10 backdrop-blur-sm border-white text-white hover:bg-white hover:text-amber-600">
                  Book a Consultation
                </Button>
              </Link>
            </div>
          </div>
        </div>

        {/* Slide Indicators */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex space-x-2">
          {heroImages.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentSlide(index)}
              className={`w-3 h-3 rounded-full transition-all cursor-pointer ${
                index === currentSlide ? 'bg-white' : 'bg-white/50'
              }`}
            />
          ))}
        </div>
      </section>

      {/* Services Preview */}
      <section className="py-20 bg-gradient-to-b from-amber-50 to-pink-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-amber-900 mb-4">Our Specialties</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              From elegant wedding cakes to fun birthday creations, we craft every cake with love and attention to detail
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {services.map((service, index) => (
              <div key={index} className="bg-white rounded-2xl p-8 text-center shadow-lg hover:shadow-xl transition-shadow">
                <div className={`w-16 h-16 mx-auto mb-6 flex items-center justify-center bg-gradient-to-br from-amber-100 to-pink-100 rounded-full`}>
                  <i className={`${service.icon} text-2xl ${service.color}`}></i>
                </div>
                <h3 className="text-xl font-semibold mb-4 text-amber-900">{service.title}</h3>
                <p className="text-gray-600 mb-6">{service.description}</p>
                <Link href="/cakes">
                  <Button variant="outline" size="sm" className="w-full">
                    View Options
                  </Button>
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Gallery */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-amber-900 mb-4">Sweet Creations</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Take a look at some of our recent masterpieces
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                src: 'https://readdy.ai/api/search-image?query=elegant%20pink%20and%20white%20wedding%20cake%20with%20fondant%20roses%2C%20three%20tiers%20with%20intricate%20piping%20details%2C%20displayed%20on%20crystal%20cake%20stand%20in%20luxury%20bakery%20setting%20with%20soft%20romantic%20lighting&width=600&height=800&seq=featured-1&orientation=portrait',
                alt: 'Featured Wedding Cake'
              },
              {
                src: 'https://readdy.ai/api/search-image?query=colorful%20kids%20birthday%20cake%20shaped%20like%20cartoon%20character%2C%20bright%20colors%20with%20fondant%20decorations%2C%20fun%20and%20playful%20design%20on%20wooden%20table%20with%20party%20background&width=600&height=800&seq=featured-2&orientation=portrait',
                alt: 'Featured Birthday Cake'
              },
              {
                src: 'https://readdy.ai/api/search-image?query=sophisticated%20chocolate%20layer%20cake%20with%20gold%20leaf%20accents%2C%20rich%20ganache%20frosting%2C%20fresh%20berries%2C%20elegant%20presentation%20on%20marble%20surface%20in%20upscale%20bakery%20interior&width=600&height=800&seq=featured-3&orientation=portrait',
                alt: 'Featured Custom Cake'
              }
            ].map((image, index) => (
              <div key={index} className="group relative overflow-hidden rounded-2xl shadow-lg hover:shadow-xl transition-shadow">
                <img
                  src={image.src}
                  alt={image.alt}
                  className="w-full h-80 object-cover object-top group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="absolute bottom-4 left-4 right-4">
                    <Link href="/gallery">
                      <Button size="sm" className="w-full">
                        View Gallery
                      </Button>
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 bg-gradient-to-r from-amber-600 to-pink-600">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">Ready to Create Something Sweet?</h2>
          <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
            Let's bring your cake dreams to life. Contact us today to discuss your custom order.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/order">
              <Button size="lg" className="bg-white text-amber-600 hover:bg-gray-100">
                Start Your Order
              </Button>
            </Link>
            <Link href="/contact">
              <Button variant="outline" size="lg" className="border-white text-white hover:bg-white hover:text-amber-600">
                Get in Touch
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}