'use client';

import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="bg-amber-900 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand Section */}
          <div className="col-span-1 md:col-span-2">
            <div className="text-3xl font-bold mb-4 text-amber-100" style={{ fontFamily: 'Pacifico, serif' }}>
              Verrloy's Bake Shop
            </div>
            <p className="text-amber-200 mb-6 max-w-md">
              Bringing Sweet Dreams to Life – One Slice at a Time. Creating memorable moments with our premium cakes and desserts.
            </p>
            <div className="flex space-x-4">
              <a href="https://facebook.com/BakesOn_Verrloy" target="_blank" rel="noopener noreferrer" className="text-amber-200 hover:text-white transition-colors cursor-pointer">
                <div className="w-8 h-8 flex items-center justify-center">
                  <i className="ri-facebook-fill text-xl"></i>
                </div>
              </a>
              <a href="https://instagram.com/verrloy" target="_blank" rel="noopener noreferrer" className="text-amber-200 hover:text-white transition-colors cursor-pointer">
                <div className="w-8 h-8 flex items-center justify-center">
                  <i className="ri-instagram-fill text-xl"></i>
                </div>
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold mb-4 text-amber-100">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <Link href="/cakes" className="text-amber-200 hover:text-white transition-colors cursor-pointer">
                  Our Cakes
                </Link>
              </li>
              <li>
                <Link href="/gallery" className="text-amber-200 hover:text-white transition-colors cursor-pointer">
                  Gallery
                </Link>
              </li>
              <li>
                <Link href="/order" className="text-amber-200 hover:text-white transition-colors cursor-pointer">
                  Order Now
                </Link>
              </li>
              <li>
                <Link href="/testimonials" className="text-amber-200 hover:text-white transition-colors cursor-pointer">
                  Testimonials
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-amber-200 hover:text-white transition-colors cursor-pointer">
                  Contact Us
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="font-semibold mb-4 text-amber-100">Contact Info</h4>
            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <div className="w-5 h-5 flex items-center justify-center">
                  <i className="ri-phone-fill text-amber-200"></i>
                </div>
                <span className="text-amber-200">020 3881414</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-5 h-5 flex items-center justify-center">
                  <i className="ri-phone-fill text-amber-200"></i>
                </div>
                <span className="text-amber-200">0249357450</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-5 h-5 flex items-center justify-center">
                  <i className="ri-phone-fill text-amber-200"></i>
                </div>
                <span className="text-amber-200">0502169658</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-amber-800 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-amber-200 text-sm">
            © 2024 Verrloy's Bake Shop. All rights reserved.
          </p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <Link href="/terms" className="text-amber-200 hover:text-white transition-colors text-sm cursor-pointer">
              Terms of Service
            </Link>
            <Link href="/privacy" className="text-amber-200 hover:text-white transition-colors text-sm cursor-pointer">
              Privacy Policy
            </Link>
            <Link href="/refund" className="text-amber-200 hover:text-white transition-colors text-sm cursor-pointer">
              Refund Policy
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}