'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-white shadow-lg sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link href="/" className="flex items-center space-x-3">
            <div className="text-2xl font-bold text-amber-600" style={{ fontFamily: 'Pacifico, serif' }}>
              Verrloy's Bake Shop
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link href="/" className="text-gray-700 hover:text-amber-600 transition-colors whitespace-nowrap cursor-pointer">
              Home
            </Link>
            <Link href="/cakes" className="text-gray-700 hover:text-amber-600 transition-colors whitespace-nowrap cursor-pointer">
              Our Cakes
            </Link>
            <Link href="/gallery" className="text-gray-700 hover:text-amber-600 transition-colors whitespace-nowrap cursor-pointer">
              Gallery
            </Link>
            <Link href="/order" className="text-gray-700 hover:text-amber-600 transition-colors whitespace-nowrap cursor-pointer">
              Order
            </Link>
            <Link href="/testimonials" className="text-gray-700 hover:text-amber-600 transition-colors whitespace-nowrap cursor-pointer">
              Testimonials
            </Link>
            <Link href="/contact" className="text-gray-700 hover:text-amber-600 transition-colors whitespace-nowrap cursor-pointer">
              Contact
            </Link>
          </nav>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2 cursor-pointer"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            <div className="w-6 h-6 flex items-center justify-center">
              <i className={`ri-menu-line text-xl ${isMenuOpen ? 'hidden' : 'block'}`}></i>
              <i className={`ri-close-line text-xl ${isMenuOpen ? 'block' : 'hidden'}`}></i>
            </div>
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t">
            <nav className="flex flex-col space-y-4">
              <Link href="/" className="text-gray-700 hover:text-amber-600 transition-colors cursor-pointer">
                Home
              </Link>
              <Link href="/cakes" className="text-gray-700 hover:text-amber-600 transition-colors cursor-pointer">
                Our Cakes
              </Link>
              <Link href="/gallery" className="text-gray-700 hover:text-amber-600 transition-colors cursor-pointer">
                Gallery
              </Link>
              <Link href="/order" className="text-gray-700 hover:text-amber-600 transition-colors cursor-pointer">
                Order
              </Link>
              <Link href="/testimonials" className="text-gray-700 hover:text-amber-600 transition-colors cursor-pointer">
                Testimonials
              </Link>
              <Link href="/contact" className="text-gray-700 hover:text-amber-600 transition-colors cursor-pointer">
                Contact
              </Link>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}