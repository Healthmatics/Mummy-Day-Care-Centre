'use client';

import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="bg-black text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="col-span-2">
            <h3 className="text-2xl font-bold mb-4 font-pacifico">The Vibe Gardens</h3>
            <p className="text-gray-300 mb-4 leading-relaxed">
              Experience luxury and elegance at Ghana's premier outdoor event center. 
              Located in the heart of Adenta Commandos, we offer exceptional spaces 
              for your most memorable occasions.
            </p>
            <div className="flex space-x-4">
              <i className="ri-facebook-fill text-xl cursor-pointer hover:text-red-500 transition-colors w-6 h-6 flex items-center justify-center"></i>
              <i className="ri-instagram-fill text-xl cursor-pointer hover:text-red-500 transition-colors w-6 h-6 flex items-center justify-center"></i>
              <i className="ri-whatsapp-fill text-xl cursor-pointer hover:text-red-500 transition-colors w-6 h-6 flex items-center justify-center"></i>
              <i className="ri-twitter-fill text-xl cursor-pointer hover:text-red-500 transition-colors w-6 h-6 flex items-center justify-center"></i>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-4 text-red-500">Quick Links</h4>
            <ul className="space-y-2">
              <li><Link href="/event-space" className="text-gray-300 hover:text-white transition-colors">Event Space</Link></li>
              <li><Link href="/accommodation" className="text-gray-300 hover:text-white transition-colors">Accommodation</Link></li>
              <li><Link href="/gallery" className="text-gray-300 hover:text-white transition-colors">Gallery</Link></li>
              <li><Link href="/pricing" className="text-gray-300 hover:text-white transition-colors">Pricing</Link></li>
              <li><Link href="/testimonials" className="text-gray-300 hover:text-white transition-colors">Testimonials</Link></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-semibold mb-4 text-red-500">Contact Info</h4>
            <div className="space-y-3">
              <p className="flex items-center text-gray-300">
                <i className="ri-map-pin-line mr-3 text-red-500 w-5 h-5 flex items-center justify-center"></i>
                Adenta Commandos, Ghana
              </p>
              <p className="flex items-center text-gray-300">
                <i className="ri-phone-line mr-3 text-red-500 w-5 h-5 flex items-center justify-center"></i>
                +233 24 123 4567
              </p>
              <p className="flex items-center text-gray-300">
                <i className="ri-mail-line mr-3 text-red-500 w-5 h-5 flex items-center justify-center"></i>
                info@thevibegardens.com
              </p>
              <p className="flex items-center text-gray-300">
                <i className="ri-time-line mr-3 text-red-500 w-5 h-5 flex items-center justify-center"></i>
                Open 24/7
              </p>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-8 text-center">
          <p className="text-gray-400">
            © 2024 The Vibe Gardens. All rights reserved. | 
            <Link href="/privacy" className="hover:text-red-500 transition-colors ml-1">Privacy Policy</Link> | 
            <Link href="/terms" className="hover:text-red-500 transition-colors ml-1">Terms of Service</Link>
          </p>
        </div>
      </div>

      {/* WhatsApp Chat Button */}
      <div className="fixed bottom-6 right-6 z-50">
        <a
          href="https://wa.me/233241234567"
          target="_blank"
          rel="noopener noreferrer"
          className="bg-green-500 text-white p-4 rounded-full shadow-lg hover:bg-green-600 transition-colors duration-200 flex items-center justify-center"
        >
          <i className="ri-whatsapp-fill text-2xl w-8 h-8 flex items-center justify-center"></i>
        </a>
      </div>
    </footer>
  );
}