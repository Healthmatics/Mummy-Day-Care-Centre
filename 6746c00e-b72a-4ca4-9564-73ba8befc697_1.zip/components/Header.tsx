'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const navItems = [
    { name: 'Home', href: '/' },
    { name: 'About', href: '/about' },
    { name: 'Event Space', href: '/event-space' },
    { name: 'Accommodation', href: '/accommodation' },
    { name: 'Gallery', href: '/gallery' },
    { name: 'Pricing', href: '/pricing' },
    { name: 'Testimonials', href: '/testimonials' },
    { name: 'Contact', href: '/contact' },
  ];

  return (
    <>
      {/* Quick Contact Bar */}
      <div className="bg-red-600 text-white py-2 px-4 text-sm">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center space-x-4">
            <span className="flex items-center">
              <i className="ri-phone-line mr-2"></i>
              +233 24 123 4567
            </span>
            <span className="flex items-center">
              <i className="ri-mail-line mr-2"></i>
              info@thevibegardens.com
            </span>
          </div>
          <div className="flex items-center space-x-3">
            <span>Follow us:</span>
            <div className="flex items-center space-x-2">
              <i className="ri-facebook-fill cursor-pointer hover:text-gray-300 transition-colors w-4 h-4 flex items-center justify-center"></i>
              <i className="ri-instagram-fill cursor-pointer hover:text-gray-300 transition-colors w-4 h-4 flex items-center justify-center"></i>
              <i className="ri-whatsapp-fill cursor-pointer hover:text-gray-300 transition-colors w-4 h-4 flex items-center justify-center"></i>
            </div>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <header className="bg-black text-white sticky top-0 z-50 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <Link href="/" className="text-2xl font-bold">
              <span className="font-pacifico text-white">The Vibe Gardens</span>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex space-x-8">
              {navItems.map((item) => (
                <Link
                  key={item.name}
                  href={item.href}
                  className="text-white hover:text-red-500 transition-colors duration-200 font-medium whitespace-nowrap"
                >
                  {item.name}
                </Link>
              ))}
            </nav>

            {/* Mobile Menu Button */}
            <button
              className="md:hidden flex items-center justify-center w-8 h-8 cursor-pointer"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              <i className={`${isMenuOpen ? 'ri-close-line' : 'ri-menu-line'} text-xl`}></i>
            </button>
          </div>

          {/* Mobile Navigation */}
          {isMenuOpen && (
            <nav className="md:hidden py-4 border-t border-gray-700">
              {navItems.map((item) => (
                <Link
                  key={item.name}
                  href={item.href}
                  className="block py-2 text-white hover:text-red-500 transition-colors duration-200"
                  onClick={() => setIsMenuOpen(false)}
                >
                  {item.name}
                </Link>
              ))}
            </nav>
          )}
        </div>
      </header>
    </>
  );
}