import type { Metadata } from "next";
import { Geist, Geist_Mono, Pacifico } from "next/font/google";
import "./globals.css";

const pacifico = Pacifico({
  weight: '400',
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-pacifico',
})

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "The Vibe Gardens - Premier Luxury Event Center in Ghana",
  description: "Experience luxury at Ghana's most prestigious outdoor event center. Premium garden venues, luxury accommodation, and exceptional service in Adenta Commandos.",
  keywords: "luxury event center Ghana, outdoor wedding venue, premium accommodation Ghana, event space Adenta, luxury gardens Ghana",
  openGraph: {
    title: "The Vibe Gardens - Premier Luxury Event Center",
    description: "Ghana's most prestigious outdoor event center offering premium venues and luxury accommodation",
    type: "website",
  }
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning={true}>
      <head>
        <link
          href="https://cdn.jsdelivr.net/npm/remixicon@4.0.0/fonts/remixicon.css"
          rel="stylesheet"
        />
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} ${pacifico.variable} antialiased`}
      >
        {children}
      </body>
    </html>
  );
}