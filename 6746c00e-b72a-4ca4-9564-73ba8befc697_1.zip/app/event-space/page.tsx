'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Button from '@/components/ui/Button';
import Link from 'next/link';
import { useState } from 'react';

export default function EventSpace() {
  const [selectedSpace, setSelectedSpace] = useState('garden');

  const spaces = {
    garden: {
      name: 'Main Garden Pavilion',
      capacity: '200-300 guests',
      features: ['Covered pavilion area', 'Natural garden backdrop', 'Professional lighting', 'Sound system included', 'Bridal suite access', 'Parking for 100+ vehicles'],
      image: 'https://readdy.ai/api/search-image?query=luxury%20outdoor%20wedding%20pavilion%20with%20elegant%20white%20draping%2C%20sophisticated%20lighting%2C%20beautiful%20garden%20landscaping%2C%20premium%20outdoor%20furniture%2C%20Ghana%20outdoor%20venue%2C%20high-end%20event%20decoration%2C%20tropical%20plants%2C%20evening%20ambiance&width=800&height=500&seq=garden-pavilion&orientation=landscape'
    },
    terrace: {
      name: 'Elevated Terrace',
      capacity: '100-150 guests',
      features: ['Elevated platform view', 'Intimate setting', 'Premium bar area', 'Lounge seating', 'Garden views', 'Climate-controlled comfort'],
      image: 'https://readdy.ai/api/search-image?query=elegant%20elevated%20outdoor%20terrace%20with%20luxury%20seating%2C%20sophisticated%20bar%20area%2C%20beautiful%20garden%20views%2C%20premium%20outdoor%20furniture%2C%20Ghana%20venue%2C%20high-end%20terrace%20design%2C%20tropical%20landscaping%2C%20evening%20lighting&width=800&height=500&seq=terrace-space&orientation=landscape'
    },
    intimate: {
      name: 'Intimate Garden Nook',
      capacity: '50-80 guests',
      features: ['Private garden section', 'Romantic ambiance', 'Fairy light canopy', 'Cozy seating arrangements', 'Perfect for ceremonies', 'Photographer-friendly'],
      image: 'https://readdy.ai/api/search-image?query=intimate%20garden%20wedding%20ceremony%20setup%20with%20fairy%20lights%2C%20elegant%20seating%20arrangement%2C%20romantic%20ambiance%2C%20beautiful%20tropical%20plants%2C%20Ghana%20outdoor%20venue%2C%20luxury%20intimate%20event%20space%2C%20sophisticated%20decoration&width=800&height=500&seq=intimate-nook&orientation=landscape'
    }
  };

  return (
    <>
      <Header />
      
      {/* Hero Section */}
      <section 
        className="relative h-96 bg-cover bg-center"
        style={{
          backgroundImage: `linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url('https://readdy.ai/api/search-image?query=stunning%20outdoor%20event%20space%20with%20elegant%20pavilion%2C%20beautiful%20garden%20landscaping%2C%20premium%20lighting%2C%20sophisticated%20outdoor%20dining%20setup%2C%20Ghana%20luxury%20venue%2C%20high-end%20event%20decoration%2C%20tropical%20plants%2C%20evening%20atmosphere&width=1920&height=600&seq=event-hero&orientation=landscape')`
        }}
      >
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center text-white">
            <h1 className="text-5xl font-bold mb-4">Event Spaces</h1>
            <p className="text-xl max-w-3xl">Discover our premium outdoor venues designed for unforgettable celebrations</p>
          </div>
        </div>
      </section>

      {/* Space Selection */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Choose Your Perfect Space</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Each of our event spaces offers a unique atmosphere and can be customized to match your vision perfectly.
            </p>
          </div>

          {/* Space Tabs */}
          <div className="flex justify-center mb-12">
            <div className="bg-gray-100 p-1 rounded-full">
              {Object.keys(spaces).map((spaceKey) => (
                <button
                  key={spaceKey}
                  onClick={() => setSelectedSpace(spaceKey)}
                  className={`px-6 py-2 rounded-full transition-all duration-200 cursor-pointer whitespace-nowrap ${
                    selectedSpace === spaceKey
                      ? 'bg-red-500 text-white'
                      : 'text-gray-600 hover:text-red-500'
                  }`}
                >
                  {spaces[spaceKey].name}
                </button>
              ))}
            </div>
          </div>

          {/* Selected Space Details */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <img
                src={spaces[selectedSpace].image}
                alt={spaces[selectedSpace].name}
                className="rounded-lg shadow-xl object-cover object-top w-full h-96"
              />
            </div>
            <div>
              <h3 className="text-3xl font-bold text-gray-900 mb-4">{spaces[selectedSpace].name}</h3>
              <p className="text-xl text-red-500 font-semibold mb-6">Capacity: {spaces[selectedSpace].capacity}</p>
              
              <h4 className="text-xl font-bold text-gray-900 mb-4">Features & Amenities:</h4>
              <ul className="space-y-3 mb-8">
                {spaces[selectedSpace].features.map((feature, index) => (
                  <li key={index} className="flex items-start">
                    <i className="ri-check-line text-red-500 text-xl mt-1 mr-3 w-5 h-5 flex items-center justify-center"></i>
                    <span className="text-gray-600">{feature}</span>
                  </li>
                ))}
              </ul>

              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="transform hover:scale-105">
                  <i className="ri-calendar-check-line mr-2 w-5 h-5 flex items-center justify-center"></i>
                  Enquire About Availability
                </Button>
                <Link href="/pricing">
                  <Button variant="outline" size="lg" className="transform hover:scale-105">
                    <i className="ri-price-tag-line mr-2 w-5 h-5 flex items-center justify-center"></i>
                    View Pricing
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Additional Services */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Complete Event Services</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              We provide everything you need to make your event exceptional, from planning to execution.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center p-6 bg-white rounded-lg shadow-lg hover:shadow-xl transition-shadow">
              <div className="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-restaurant-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Catering Services</h3>
              <p className="text-gray-600 text-sm">Premium catering with local and international cuisine options</p>
            </div>

            <div className="text-center p-6 bg-white rounded-lg shadow-lg hover:shadow-xl transition-shadow">
              <div className="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-camera-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Photography</h3>
              <p className="text-gray-600 text-sm">Professional photography and videography services</p>
            </div>

            <div className="text-center p-6 bg-white rounded-lg shadow-lg hover:shadow-xl transition-shadow">
              <div className="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-flower-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Decoration</h3>
              <p className="text-gray-600 text-sm">Custom floral arrangements and elegant decorations</p>
            </div>

            <div className="text-center p-6 bg-white rounded-lg shadow-lg hover:shadow-xl transition-shadow">
              <div className="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-music-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Entertainment</h3>
              <p className="text-gray-600 text-sm">Sound systems, lighting, and entertainment coordination</p>
            </div>
          </div>
        </div>
      </section>

      {/* Booking Process */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Simple Booking Process</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Getting started with your dream event is easy. Follow our simple process and we'll handle the rest.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-red-500 text-white rounded-full flex items-center justify-center mx-auto mb-4 text-2xl font-bold">1</div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Contact Us</h3>
              <p className="text-gray-600">Reach out via phone, email, or WhatsApp to discuss your event requirements</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-red-500 text-white rounded-full flex items-center justify-center mx-auto mb-4 text-2xl font-bold">2</div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Site Visit</h3>
              <p className="text-gray-600">Schedule a private tour to see our spaces and discuss your vision</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-red-500 text-white rounded-full flex items-center justify-center mx-auto mb-4 text-2xl font-bold">3</div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Custom Proposal</h3>
              <p className="text-gray-600">Receive a detailed proposal tailored to your specific needs and budget</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-red-500 text-white rounded-full flex items-center justify-center mx-auto mb-4 text-2xl font-bold">4</div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Confirm & Plan</h3>
              <p className="text-gray-600">Secure your date and work with our team to plan every detail</p>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 bg-black text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-6">Ready to Book Your Event?</h2>
          <p className="text-xl mb-8 max-w-3xl mx-auto">
            Don't wait - our premium spaces book up quickly. Contact us today to secure your preferred date and start planning your perfect event.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="transform hover:scale-105">
              <i className="ri-whatsapp-line mr-2 w-5 h-5 flex items-center justify-center"></i>
              WhatsApp Us Now
            </Button>
            <Link href="/contact">
              <Button variant="outline" size="lg" className="transform hover:scale-105">
                <i className="ri-phone-line mr-2 w-5 h-5 flex items-center justify-center"></i>
                Call for Consultation
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </>
  );
}