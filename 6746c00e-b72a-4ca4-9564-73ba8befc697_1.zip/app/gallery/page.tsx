'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { useState } from 'react';

export default function Gallery() {
  const [activeCategory, setActiveCategory] = useState('events');

  const galleryImages = {
    events: [
      {
        src: 'https://readdy.ai/api/search-image?query=elegant%20outdoor%20wedding%20ceremony%20with%20beautiful%20garden%20backdrop%2C%20luxury%20event%20setup%2C%20sophisticated%20decoration%2C%20Ghana%20outdoor%20venue%2C%20premium%20wedding%20decor%2C%20tropical%20landscaping%2C%20romantic%20atmosphere&width=400&height=300&seq=event-1&orientation=landscape',
        title: 'Garden Wedding Ceremony',
        description: 'Elegant outdoor wedding with stunning garden backdrop'
      },
      {
        src: 'https://readdy.ai/api/search-image?query=luxury%20outdoor%20corporate%20event%20with%20premium%20seating%20arrangement%2C%20professional%20setup%2C%20sophisticated%20lighting%2C%20Ghana%20business%20venue%2C%20high-end%20corporate%20function%2C%20elegant%20outdoor%20meeting&width=400&height=300&seq=event-2&orientation=landscape',
        title: 'Corporate Gala Dinner',
        description: 'Premium corporate event with professional setup'
      },
      {
        src: 'https://readdy.ai/api/search-image?query=elegant%20birthday%20party%20celebration%20in%20garden%20setting%2C%20luxury%20party%20decoration%2C%20premium%20outdoor%20dining%2C%20Ghana%20party%20venue%2C%20sophisticated%20birthday%20setup%2C%20beautiful%20lighting&width=400&height=300&seq=event-3&orientation=landscape',
        title: 'Birthday Celebration',
        description: 'Luxury birthday party in our garden pavilion'
      },
      {
        src: 'https://readdy.ai/api/search-image?query=traditional%20Ghanaian%20wedding%20reception%20with%20modern%20luxury%20touches%2C%20outdoor%20celebration%2C%20elegant%20decoration%2C%20cultural%20event%2C%20premium%20outdoor%20venue%2C%20sophisticated%20setup&width=400&height=300&seq=event-4&orientation=landscape',
        title: 'Cultural Wedding Reception',
        description: 'Traditional celebration with modern luxury touches'
      },
      {
        src: 'https://readdy.ai/api/search-image?query=luxury%20anniversary%20dinner%20setup%20in%20garden%2C%20romantic%20outdoor%20dining%2C%20elegant%20table%20decoration%2C%20intimate%20celebration%2C%20Ghana%20romantic%20venue%2C%20premium%20anniversary%20celebration&width=400&height=300&seq=event-5&orientation=landscape',
        title: 'Anniversary Dinner',
        description: 'Romantic anniversary celebration setup'
      },
      {
        src: 'https://readdy.ai/api/search-image?query=graduation%20party%20outdoor%20celebration%20with%20elegant%20decoration%2C%20luxury%20graduation%20setup%2C%20sophisticated%20outdoor%20venue%2C%20Ghana%20celebration%20venue%2C%20premium%20graduation%20party&width=400&height=300&seq=event-6&orientation=landscape',
        title: 'Graduation Party',
        description: 'Elegant graduation celebration in our gardens'
      }
    ],
    gardens: [
      {
        src: 'https://readdy.ai/api/search-image?query=beautiful%20tropical%20garden%20landscaping%20with%20luxury%20outdoor%20furniture%2C%20sophisticated%20garden%20design%2C%20premium%20outdoor%20seating%2C%20Ghana%20luxury%20garden%2C%20elegant%20landscaping%2C%20tropical%20plants&width=400&height=300&seq=garden-1&orientation=landscape',
        title: 'Main Garden Area',
        description: 'Beautifully landscaped gardens with premium seating'
      },
      {
        src: 'https://readdy.ai/api/search-image?query=elegant%20garden%20pavilion%20with%20luxury%20outdoor%20dining%20setup%2C%20sophisticated%20covered%20area%2C%20premium%20outdoor%20restaurant%2C%20Ghana%20garden%20pavilion%2C%20high-end%20outdoor%20dining&width=400&height=300&seq=garden-2&orientation=landscape',
        title: 'Garden Pavilion',
        description: 'Covered pavilion area for all-weather events'
      },
      {
        src: 'https://readdy.ai/api/search-image?query=luxury%20garden%20pathway%20with%20beautiful%20tropical%20landscaping%2C%20elegant%20walkways%2C%20premium%20garden%20lighting%2C%20sophisticated%20outdoor%20design%2C%20Ghana%20luxury%20garden%20paths&width=400&height=300&seq=garden-3&orientation=landscape',
        title: 'Garden Pathways',
        description: 'Elegant pathways throughout our grounds'
      },
      {
        src: 'https://readdy.ai/api/search-image?query=intimate%20garden%20nook%20with%20romantic%20seating%2C%20luxury%20outdoor%20lounge%20area%2C%20sophisticated%20garden%20corner%2C%20premium%20romantic%20setting%2C%20Ghana%20intimate%20garden%20space&width=400&height=300&seq=garden-4&orientation=landscape',
        title: 'Intimate Garden Nook',
        description: 'Perfect spot for intimate celebrations'
      },
      {
        src: 'https://readdy.ai/api/search-image?query=luxury%20garden%20water%20feature%20with%20tropical%20landscaping%2C%20elegant%20fountain%20or%20pond%2C%20sophisticated%20garden%20design%2C%20premium%20outdoor%20water%20element%2C%20Ghana%20garden%20water%20feature&width=400&height=300&seq=garden-5&orientation=landscape',
        title: 'Garden Water Feature',
        description: 'Tranquil water features enhance the ambiance'
      },
      {
        src: 'https://readdy.ai/api/search-image?query=elevated%20garden%20terrace%20with%20luxury%20seating%2C%20sophisticated%20outdoor%20lounge%2C%20premium%20terrace%20design%2C%20Ghana%20luxury%20outdoor%20terrace%2C%20elegant%20elevated%20seating%20area&width=400&height=300&seq=garden-6&orientation=landscape',
        title: 'Elevated Terrace',
        description: 'Raised terrace with panoramic garden views'
      }
    ]
  };

  const [selectedImage, setSelectedImage] = useState(null);

  const openLightbox = (image) => {
    setSelectedImage(image);
  };

  const closeLightbox = () => {
    setSelectedImage(null);
  };

  return (
    <>
      <Header />
      
      {/* Hero Section */}
      <section 
        className="relative h-96 bg-cover bg-center"
        style={{
          backgroundImage: `linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url('https://readdy.ai/api/search-image?query=stunning%20gallery%20of%20luxury%20outdoor%20events%20and%20garden%20spaces%2C%20elegant%20event%20photography%2C%20Ghana%20premium%20venue%2C%20sophisticated%20outdoor%20celebrations%2C%20beautiful%20garden%20landscapes&width=1920&height=600&seq=gallery-hero&orientation=landscape')`
        }}
      >
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center text-white">
            <h1 className="text-5xl font-bold mb-4">Our Gallery</h1>
            <p className="text-xl max-w-3xl">Explore our beautiful spaces and memorable events through these stunning images</p>
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Visual Stories</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Every image tells a story of elegance, beauty, and unforgettable moments created at The Vibe Gardens.
            </p>
          </div>

          {/* Category Tabs */}
          <div className="flex justify-center mb-12">
            <div className="bg-gray-100 p-1 rounded-full">
              <button
                onClick={() => setActiveCategory('events')}
                className={`px-6 py-2 rounded-full transition-all duration-200 cursor-pointer whitespace-nowrap ${
                  activeCategory === 'events'
                    ? 'bg-red-500 text-white'
                    : 'text-gray-600 hover:text-red-500'
                }`}
              >
                Event Highlights
              </button>
              <button
                onClick={() => setActiveCategory('gardens')}
                className={`px-6 py-2 rounded-full transition-all duration-200 cursor-pointer whitespace-nowrap ${
                  activeCategory === 'gardens'
                    ? 'bg-red-500 text-white'
                    : 'text-gray-600 hover:text-red-500'
                }`}
              >
                Garden Spaces
              </button>
            </div>
          </div>

          {/* Image Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {galleryImages[activeCategory].map((image, index) => (
              <div
                key={index}
                className="group cursor-pointer overflow-hidden rounded-lg shadow-lg hover:shadow-xl transition-all duration-300"
                onClick={() => openLightbox(image)}
              >
                <div className="relative">
                  <img
                    src={image.src}
                    alt={image.title}
                    className="w-full h-64 object-cover object-top group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-40 transition-all duration-300 flex items-center justify-center">
                    <i className="ri-eye-line text-white text-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 w-8 h-8 flex items-center justify-center"></i>
                  </div>
                </div>
                <div className="p-6 bg-white">
                  <h3 className="text-xl font-bold text-gray-900 mb-2">{image.title}</h3>
                  <p className="text-gray-600">{image.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Lightbox Modal */}
      {selectedImage && (
        <div className="fixed inset-0 bg-black bg-opacity-90 z-50 flex items-center justify-center p-4">
          <div className="relative max-w-4xl max-h-full">
            <button
              onClick={closeLightbox}
              className="absolute top-4 right-4 text-white text-3xl cursor-pointer hover:text-red-500 transition-colors z-10 w-8 h-8 flex items-center justify-center"
            >
              <i className="ri-close-line"></i>
            </button>
            <img
              src={selectedImage.src}
              alt={selectedImage.title}
              className="max-w-full max-h-full object-contain rounded-lg"
            />
            <div className="absolute bottom-0 left-0 right-0 bg-black bg-opacity-70 text-white p-6 rounded-b-lg">
              <h3 className="text-2xl font-bold mb-2">{selectedImage.title}</h3>
              <p className="text-gray-300">{selectedImage.description}</p>
            </div>
          </div>
        </div>
      )}

      {/* Call to Action */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-gray-900 mb-6">Ready to Create Your Own Story?</h2>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Let us help you create beautiful memories that will be treasured for a lifetime. 
            Contact us today to start planning your perfect event.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="/contact"
              className="bg-red-600 text-white px-8 py-4 text-lg rounded-xl font-medium transition-all duration-200 cursor-pointer hover:bg-red-700 shadow-lg hover:shadow-xl transform hover:scale-105 whitespace-nowrap"
            >
              <i className="ri-phone-line mr-2 w-5 h-5 flex items-center justify-center"></i>
              Book Your Event
            </a>
            <a
              href="/event-space"
              className="border-2 border-red-600 text-red-600 hover:bg-red-600 hover:text-white px-8 py-4 text-lg rounded-xl font-medium transition-all duration-200 cursor-pointer whitespace-nowrap"
            >
              <i className="ri-eye-line mr-2 w-5 h-5 flex items-center justify-center"></i>
              View Our Spaces
            </a>
          </div>
        </div>
      </section>

      <Footer />
    </>
  );
}