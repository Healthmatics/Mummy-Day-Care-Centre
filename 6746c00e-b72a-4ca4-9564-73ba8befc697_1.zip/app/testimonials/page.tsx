'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Button from '@/components/ui/Button';
import Link from 'next/link';

export default function Testimonials() {
  const testimonials = [
    {
      name: 'Akosua & Kwame Asante',
      event: 'Wedding Reception',
      date: 'September 2024',
      rating: 5,
      text: 'The Vibe Gardens exceeded all our expectations for our wedding reception. The garden setting was absolutely magical, and the staff went above and beyond to ensure every detail was perfect. Our guests are still talking about how beautiful and elegant everything was. We couldn\'t have asked for a better venue for our special day.',
      image: 'https://readdy.ai/api/search-image?query=happy%20African%20couple%20at%20elegant%20wedding%20reception%2C%20bride%20and%20groom%20smiling%2C%20luxury%20outdoor%20wedding%2C%20Ghana%20couple%2C%20beautiful%20wedding%20attire%2C%20joyful%20celebration%2C%20sophisticated%20wedding%20photography&width=150&height=150&seq=couple-1&orientation=squarish'
    },
    {
      name: 'Sarah Mensah',
      event: 'Corporate Anniversary Gala',
      date: 'August 2024',
      rating: 5,
      text: 'We hosted our company\'s 10th anniversary gala at The Vibe Gardens and it was absolutely phenomenal. The professional team handled every aspect flawlessly, from the elegant setup to the exceptional service throughout the evening. Our clients and employees were thoroughly impressed with the venue\'s sophistication and attention to detail.',
      image: 'https://readdy.ai/api/search-image?query=professional%20African%20businesswoman%20in%20elegant%20attire%2C%20confident%20smile%2C%20corporate%20event%20setting%2C%20Ghana%20professional%2C%20sophisticated%20business%20portrait%2C%20luxury%20event%20background&width=150&height=150&seq=business-1&orientation=squarish'
    },
    {
      name: 'Michael & Grace Osei',
      event: '25th Wedding Anniversary',
      date: 'July 2024',
      rating: 5,
      text: 'For our silver anniversary celebration, we wanted something special and intimate. The Vibe Gardens provided the perfect romantic atmosphere with their beautiful garden nook. The lighting, the setup, and the personalized service made our evening truly unforgettable. Our family and friends loved every moment.',
      image: 'https://readdy.ai/api/search-image?query=mature%20African%20couple%20celebrating%20anniversary%2C%20elegant%20formal%20attire%2C%20luxury%20celebration%20setting%2C%20Ghana%20couple%2C%20sophisticated%20anniversary%20celebration%2C%20joyful%20mature%20couple&width=150&height=150&seq=couple-2&orientation=squarish'
    },
    {
      name: 'Jennifer Adjei',
      event: 'Birthday Celebration',
      date: 'June 2024',
      rating: 5,
      text: 'My 40th birthday party at The Vibe Gardens was everything I dreamed of and more. The garden pavilion was beautifully decorated, and the team\'s creativity in bringing my vision to life was outstanding. The accommodation for my out-of-town guests was luxurious, and everyone felt pampered throughout their stay.',
      image: 'https://readdy.ai/api/search-image?query=elegant%20African%20woman%20at%20birthday%20celebration%2C%20sophisticated%20party%20attire%2C%20luxury%20celebration%20setting%2C%20Ghana%20woman%2C%20joyful%20birthday%20celebration%2C%20elegant%20party%20photography&width=150&height=150&seq=birthday-1&orientation=squarish'
    },
    {
      name: 'Dr. Emmanuel Boateng',
      event: 'Medical Conference Dinner',
      date: 'May 2024',
      rating: 5,
      text: 'As the organizer of our annual medical conference, I needed a venue that could accommodate 200+ professionals while maintaining an elegant atmosphere. The Vibe Gardens delivered exceptionally. The facilities were top-notch, the catering was exquisite, and the professional coordination made the event seamless.',
      image: 'https://readdy.ai/api/search-image?query=professional%20African%20doctor%20in%20formal%20attire%2C%20confident%20professional%20portrait%2C%20medical%20conference%20setting%2C%20Ghana%20medical%20professional%2C%20sophisticated%20business%20environment&width=150&height=150&seq=doctor-1&orientation=squarish'
    },
    {
      name: 'Ama & Kofi Darko',
      event: 'Traditional Wedding',
      date: 'April 2024',
      rating: 5,
      text: 'We wanted to blend traditional Ghanaian wedding customs with modern luxury, and The Vibe Gardens was the perfect choice. They beautifully accommodated our cultural requirements while providing a sophisticated setting. The gardens provided a stunning backdrop for our ceremonies and photos.',
      image: 'https://readdy.ai/api/search-image?query=Ghanaian%20couple%20in%20traditional%20wedding%20attire%2C%20beautiful%20kente%20clothing%2C%20cultural%20wedding%20celebration%2C%20Ghana%20traditional%20wedding%2C%20elegant%20African%20wedding%20couple%2C%20joyful%20traditional%20ceremony&width=150&height=150&seq=traditional-1&orientation=squarish'
    },
    {
      name: 'Rebecca Owusu',
      event: 'Graduation Party',
      date: 'March 2024',
      rating: 5,
      text: 'My daughter\'s medical school graduation party was hosted beautifully at The Vibe Gardens. The intimate garden nook was perfect for our family celebration, and the personalized service made everyone feel special. The team\'s attention to detail and warm hospitality created memories we\'ll treasure forever.',
      image: 'https://readdy.ai/api/search-image?query=proud%20African%20mother%20at%20graduation%20celebration%2C%20elegant%20celebration%20attire%2C%20luxury%20graduation%20party%20setting%2C%20Ghana%20family%20celebration%2C%20sophisticated%20graduation%20photography&width=150&height=150&seq=graduation-1&orientation=squarish'
    },
    {
      name: 'James Appiah',
      event: 'Business Launch Event',
      date: 'February 2024',
      rating: 5,
      text: 'For launching my tech startup, I needed a venue that represented innovation and sophistication. The Vibe Gardens provided exactly that. The modern amenities combined with the natural beauty created the perfect atmosphere for networking and presentations. Many potential investors commented on the impressive venue choice.',
      image: 'https://readdy.ai/api/search-image?query=young%20African%20entrepreneur%20in%20modern%20business%20attire%2C%20confident%20startup%20founder%2C%20tech%20business%20launch%20event%2C%20Ghana%20business%20professional%2C%20sophisticated%20business%20environment&width=150&height=150&seq=entrepreneur-1&orientation=squarish'
    }
  ];

  const stats = [
    { number: '500+', label: 'Successful Events' },
    { number: '98%', label: 'Client Satisfaction' },
    { number: '4.9/5', label: 'Average Rating' },
    { number: '250+', label: 'Five-Star Reviews' }
  ];

  return (
    <>
      <Header />
      
      {/* Hero Section */}
      <section 
        className="relative h-96 bg-cover bg-center"
        style={{
          backgroundImage: `linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url('https://readdy.ai/api/search-image?query=happy%20celebration%20with%20satisfied%20customers%20at%20luxury%20outdoor%20venue%2C%20elegant%20testimonial%20setting%2C%20Ghana%20premium%20venue%2C%20sophisticated%20outdoor%20celebration%2C%20joyful%20event%20guests&width=1920&height=600&seq=testimonials-hero&orientation=landscape')`
        }}
      >
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center text-white">
            <h1 className="text-5xl font-bold mb-4">Client Testimonials</h1>
            <p className="text-xl max-w-3xl">Hear from our satisfied clients about their unforgettable experiences at The Vibe Gardens</p>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Our Track Record</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Numbers that speak to our commitment to excellence and client satisfaction.
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-4xl md:text-5xl font-bold text-red-500 mb-2">{stat.number}</div>
                <div className="text-gray-600 font-medium">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Grid */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">What Our Clients Say</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Real stories from real clients who chose The Vibe Gardens for their special occasions.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-white p-8 rounded-lg shadow-lg hover:shadow-xl transition-shadow">
                <div className="flex items-center mb-6">
                  <img
                    src={testimonial.image}
                    alt={testimonial.name}
                    className="w-16 h-16 rounded-full object-cover object-top mr-4"
                  />
                  <div>
                    <h3 className="text-lg font-bold text-gray-900">{testimonial.name}</h3>
                    <p className="text-red-500 font-medium">{testimonial.event}</p>
                    <p className="text-gray-500 text-sm">{testimonial.date}</p>
                  </div>
                </div>

                <div className="flex mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <i key={i} className="ri-star-fill text-yellow-400 text-lg w-5 h-5 flex items-center justify-center"></i>
                  ))}
                </div>

                <p className="text-gray-600 leading-relaxed italic">
                  "{testimonial.text}"
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Review Platforms */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Find Us on Review Platforms</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              See more reviews and ratings from our clients across various platforms.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="text-center p-6 bg-gray-50 rounded-lg hover:shadow-lg transition-shadow">
              <div className="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-google-fill text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Google Reviews</h3>
              <div className="text-2xl font-bold text-blue-500 mb-1">4.9/5</div>
              <p className="text-gray-600 text-sm">Based on 127 reviews</p>
            </div>

            <div className="text-center p-6 bg-gray-50 rounded-lg hover:shadow-lg transition-shadow">
              <div className="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-heart-fill text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">WeddingWire</h3>
              <div className="text-2xl font-bold text-red-500 mb-1">4.8/5</div>
              <p className="text-gray-600 text-sm">Based on 89 reviews</p>
            </div>

            <div className="text-center p-6 bg-gray-50 rounded-lg hover:shadow-lg transition-shadow">
              <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-star-fill text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">TripAdvisor</h3>
              <div className="text-2xl font-bold text-green-500 mb-1">4.9/5</div>
              <p className="text-gray-600 text-sm">Based on 156 reviews</p>
            </div>

            <div className="text-center p-6 bg-gray-50 rounded-lg hover:shadow-lg transition-shadow">
              <div className="w-16 h-16 bg-purple-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-facebook-fill text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Facebook</h3>
              <div className="text-2xl font-bold text-purple-500 mb-1">4.8/5</div>
              <p className="text-gray-600 text-sm">Based on 203 reviews</p>
            </div>
          </div>
        </div>
      </section>

      {/* Leave a Review */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-gray-900 mb-6">Share Your Experience</h2>
          <p className="text-xl text-gray-600 mb-8">
            Had an amazing event with us? We'd love to hear about your experience and share it with future clients.
          </p>
          
          <div className="bg-white p-8 rounded-lg shadow-lg">
            <form id="testimonial-form" className="text-left">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                  <label className="block text-gray-700 font-semibold mb-2">Your Name *</label>
                  <input
                    type="text"
                    name="clientName"
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                    placeholder="Your full name"
                  />
                </div>
                <div>
                  <label className="block text-gray-700 font-semibold mb-2">Event Type *</label>
                  <input
                    type="text"
                    name="eventType"
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                    placeholder="e.g., Wedding, Corporate Event"
                  />
                </div>
              </div>

              <div className="mb-6">
                <label className="block text-gray-700 font-semibold mb-2">Email Address *</label>
                <input
                  type="email"
                  name="email"
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                  placeholder="your.email@example.com"
                />
              </div>

              <div className="mb-6">
                <label className="block text-gray-700 font-semibold mb-2">Rating *</label>
                <div className="flex space-x-2">
                  {[1, 2, 3, 4, 5].map((rating) => (
                    <label key={rating} className="flex items-center cursor-pointer">
                      <input
                        type="radio"
                        name="rating"
                        value={rating}
                        className="sr-only"
                      />
                      <i className="ri-star-line text-gray-400 hover:text-yellow-400 text-2xl w-6 h-6 flex items-center justify-center"></i>
                    </label>
                  ))}
                </div>
              </div>

              <div className="mb-6">
                <label className="block text-gray-700 font-semibold mb-2">Your Review *</label>
                <textarea
                  name="review"
                  rows={6}
                  maxLength={500}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent resize-none"
                  placeholder="Share your experience with us... (max 500 characters)"
                ></textarea>
              </div>

              <div className="text-center">
                <Button type="submit" size="lg" className="transform hover:scale-105">
                  <i className="ri-send-plane-line mr-2 w-5 h-5 flex items-center justify-center"></i>
                  Submit Review
                </Button>
              </div>
            </form>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 bg-black text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-6">Ready to Create Your Own Success Story?</h2>
          <p className="text-xl mb-8 max-w-3xl mx-auto">
            Join hundreds of satisfied clients who chose The Vibe Gardens for their special occasions. 
            Let us help you create memories that will last a lifetime.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/contact">
              <Button size="lg" className="transform hover:scale-105">
                <i className="ri-phone-line mr-2 w-5 h-5 flex items-center justify-center"></i>
                Start Planning Your Event
              </Button>
            </Link>
            <Link href="/event-space">
              <Button variant="outline" size="lg" className="transform hover:scale-105">
                <i className="ri-eye-line mr-2 w-5 h-5 flex items-center justify-center"></i>
                View Our Venues
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </>
  );
}