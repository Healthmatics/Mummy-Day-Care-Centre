'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Button from '@/components/ui/Button';
import Link from 'next/link';

export default function Pricing() {
  const eventPackages = [
    {
      name: 'Intimate Celebration',
      price: 'GHS 3,500',
      guests: 'Up to 50 guests',
      features: [
        'Intimate Garden Nook venue',
        '6-hour venue rental',
        'Basic sound system',
        'Standard lighting',
        'Tables and chairs setup',
        'Bridal suite access',
        'Complimentary parking',
        'Basic coordination'
      ],
      popular: false
    },
    {
      name: 'Premium Garden Event',
      price: 'GHS 7,500',
      guests: 'Up to 150 guests',
      features: [
        'Elevated Terrace or Garden Pavilion',
        '8-hour venue rental',
        'Premium sound system',
        'Professional lighting package',
        'Elegant furniture setup',
        'Bridal suite with amenities',
        'Dedicated parking area',
        'Event coordinator',
        'Welcome cocktail setup',
        'Photography assistance'
      ],
      popular: true
    },
    {
      name: 'Luxury Garden Experience',
      price: 'GHS 12,500',
      guests: 'Up to 300 guests',
      features: [
        'Main Garden Pavilion (full access)',
        '10-hour venue rental',
        'Premium AV equipment',
        'Designer lighting & decor',
        'Luxury furniture collection',
        'VIP bridal suite package',
        'Valet parking service',
        'Dedicated event manager',
        'Welcome reception area',
        'Professional photography coordination',
        'Floral arrangement consultation',
        'Custom menu planning'
      ],
      popular: false
    }
  ];

  const accommodationRates = [
    {
      room: 'Deluxe Garden Suite',
      weekday: 'GHS 450',
      weekend: 'GHS 550',
      weekly: 'GHS 2,800',
      monthly: 'GHS 10,500'
    },
    {
      room: 'Executive Villa',
      weekday: 'GHS 750',
      weekend: 'GHS 900',
      weekly: 'GHS 4,800',
      monthly: 'GHS 18,000'
    },
    {
      room: 'Presidential Garden Villa',
      weekday: 'GHS 1,200',
      weekend: 'GHS 1,450',
      weekly: 'GHS 7,500',
      monthly: 'GHS 28,000'
    }
  ];

  const additionalServices = [
    { service: 'Premium Catering (per person)', price: 'GHS 85 - 150' },
    { service: 'Professional Photography (8 hours)', price: 'GHS 2,500' },
    { service: 'Videography Package', price: 'GHS 3,500' },
    { service: 'Live Band Setup', price: 'GHS 1,500' },
    { service: 'DJ & Sound Equipment', price: 'GHS 800' },
    { service: 'Floral Arrangements', price: 'GHS 500 - 2,000' },
    { service: 'Wedding Cake (3-tier)', price: 'GHS 1,200' },
    { service: 'Transportation Service', price: 'GHS 300 - 800' },
    { service: 'Event Decoration Package', price: 'GHS 1,000 - 5,000' },
    { service: 'Security Services', price: 'GHS 400 per day' }
  ];

  return (
    <>
      <Header />
      
      {/* Hero Section */}
      <section 
        className="relative h-96 bg-cover bg-center"
        style={{
          backgroundImage: `linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url('https://readdy.ai/api/search-image?query=elegant%20pricing%20presentation%20for%20luxury%20event%20center%2C%20sophisticated%20business%20graphics%2C%20premium%20venue%20pricing%20display%2C%20Ghana%20luxury%20venue%2C%20high-end%20event%20pricing%2C%20professional%20pricing%20layout&width=1920&height=600&seq=pricing-hero&orientation=landscape')`
        }}
      >
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center text-white">
            <h1 className="text-5xl font-bold mb-4">Transparent Pricing</h1>
            <p className="text-xl max-w-3xl">Choose from our carefully crafted packages designed to fit every celebration and budget</p>
          </div>
        </div>
      </section>

      {/* Event Packages */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Event Packages</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Our comprehensive event packages include everything you need for a memorable celebration.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {eventPackages.map((pkg, index) => (
              <div
                key={index}
                className={`relative bg-white rounded-2xl shadow-xl p-8 ${
                  pkg.popular ? 'ring-4 ring-red-500 transform scale-105' : ''
                }`}
              >
                {pkg.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <span className="bg-red-500 text-white px-6 py-2 rounded-full text-sm font-bold">
                      Most Popular
                    </span>
                  </div>
                )}
                
                <div className="text-center mb-8">
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">{pkg.name}</h3>
                  <div className="text-4xl font-bold text-red-500 mb-2">{pkg.price}</div>
                  <p className="text-gray-600">{pkg.guests}</p>
                </div>

                <ul className="space-y-4 mb-8">
                  {pkg.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-start">
                      <i className="ri-check-line text-red-500 text-lg mt-1 mr-3 w-4 h-4 flex items-center justify-center"></i>
                      <span className="text-gray-600">{feature}</span>
                    </li>
                  ))}
                </ul>

                <div className="text-center">
                  <Button
                    size="lg"
                    variant={pkg.popular ? 'primary' : 'outline'}
                    className="w-full transform hover:scale-105"
                  >
                    <i className="ri-phone-line mr-2 w-5 h-5 flex items-center justify-center"></i>
                    Get Quote
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Accommodation Rates */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Accommodation Rates</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Flexible pricing options for short stays and extended accommodations.
            </p>
          </div>

          <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-900 text-white">
                  <tr>
                    <th className="px-6 py-4 text-left font-semibold">Room Type</th>
                    <th className="px-6 py-4 text-center font-semibold">Weekday</th>
                    <th className="px-6 py-4 text-center font-semibold">Weekend</th>
                    <th className="px-6 py-4 text-center font-semibold">Weekly</th>
                    <th className="px-6 py-4 text-center font-semibold">Monthly</th>
                  </tr>
                </thead>
                <tbody>
                  {accommodationRates.map((rate, index) => (
                    <tr key={index} className={index % 2 === 0 ? 'bg-gray-50' : 'bg-white'}>
                      <td className="px-6 py-4 font-semibold text-gray-900">{rate.room}</td>
                      <td className="px-6 py-4 text-center text-gray-600">{rate.weekday}</td>
                      <td className="px-6 py-4 text-center text-gray-600">{rate.weekend}</td>
                      <td className="px-6 py-4 text-center text-red-500 font-semibold">{rate.weekly}</td>
                      <td className="px-6 py-4 text-center text-red-500 font-semibold">{rate.monthly}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="mt-8 text-center">
            <p className="text-gray-600 mb-4">
              * Weekend rates apply to Friday-Sunday. Weekly and monthly rates offer significant savings.
            </p>
            <Link href="/accommodation">
              <Button size="lg" className="transform hover:scale-105">
                <i className="ri-calendar-check-line mr-2 w-5 h-5 flex items-center justify-center"></i>
                Check Availability
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Additional Services */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Additional Services</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Enhance your event with our premium add-on services and amenities.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {additionalServices.map((service, index) => (
              <div key={index} className="flex justify-between items-center p-6 bg-gray-50 rounded-lg hover:shadow-md transition-shadow">
                <span className="font-medium text-gray-900">{service.service}</span>
                <span className="font-bold text-red-500">{service.price}</span>
              </div>
            ))}
          </div>

          <div className="mt-12 bg-gray-900 text-white p-8 rounded-2xl text-center">
            <h3 className="text-2xl font-bold mb-4">Need a Custom Package?</h3>
            <p className="text-xl mb-6">
              We create personalized packages tailored to your specific needs and budget. 
              Let us design the perfect solution for your event.
            </p>
            <Button size="lg" className="transform hover:scale-105">
              <i className="ri-customer-service-line mr-2 w-5 h-5 flex items-center justify-center"></i>
              Contact Us for Custom Quote
            </Button>
          </div>
        </div>
      </section>

      {/* Payment & Policies */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Payment & Policies</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Transparent terms and flexible payment options for your convenience.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-lg shadow-lg text-center">
              <div className="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="ri-secure-payment-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Payment Terms</h3>
              <ul className="text-gray-600 space-y-2 text-left">
                <li>• 50% deposit to secure booking</li>
                <li>• Balance due 7 days before event</li>
                <li>• Multiple payment options available</li>
                <li>• Bank transfer, cash, or card</li>
              </ul>
            </div>

            <div className="bg-white p-8 rounded-lg shadow-lg text-center">
              <div className="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="ri-calendar-check-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Booking Policy</h3>
              <ul className="text-gray-600 space-y-2 text-left">
                <li>• Free cancellation 14+ days prior</li>
                <li>• 50% refund 7-14 days prior</li>
                <li>• No refund within 7 days</li>
                <li>• Weather contingency options</li>
              </ul>
            </div>

            <div className="bg-white p-8 rounded-lg shadow-lg text-center">
              <div className="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="ri-shield-check-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Guarantees</h3>
              <ul className="text-gray-600 space-y-2 text-left">
                <li>• Venue availability guarantee</li>
                <li>• Quality service assurance</li>
                <li>• Event coordination support</li>
                <li>• 24/7 emergency assistance</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 bg-black text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-6">Ready to Plan Your Perfect Event?</h2>
          <p className="text-xl mb-8 max-w-3xl mx-auto">
            Contact us today for a personalized quote and let us help you create an unforgettable experience 
            within your budget at The Vibe Gardens.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/contact">
              <Button size="lg" className="transform hover:scale-105">
                <i className="ri-phone-line mr-2 w-5 h-5 flex items-center justify-center"></i>
                Get Your Custom Quote
              </Button>
            </Link>
            <a
              href="https://wa.me/233241234567"
              target="_blank"
              rel="noopener noreferrer"
              className="border-2 border-red-600 text-red-600 hover:bg-red-600 hover:text-white px-8 py-4 text-lg rounded-xl font-medium transition-all duration-200 cursor-pointer whitespace-nowrap"
            >
              <i className="ri-whatsapp-line mr-2 w-5 h-5 flex items-center justify-center"></i>
              WhatsApp Quote Request
            </a>
          </div>
        </div>
      </section>

      <Footer />
    </>
  );
}