'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Button from '@/components/ui/Button';
import Link from 'next/link';

export default function About() {
  return (
    <>
      <Header />
      
      {/* Hero Section */}
      <section 
        className="relative h-96 bg-cover bg-center"
        style={{
          backgroundImage: `linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url('https://readdy.ai/api/search-image?query=elegant%20outdoor%20garden%20venue%20entrance%20with%20lush%20tropical%20landscaping%2C%20premium%20outdoor%20furniture%2C%20sophisticated%20lighting%2C%20Ghana%20setting%2C%20luxury%20event%20center%20exterior%2C%20beautiful%20garden%20pathways%2C%20high-end%20landscape%20design&width=1920&height=600&seq=about-hero&orientation=landscape')`
        }}
      >
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center text-white">
            <h1 className="text-5xl font-bold mb-4">About The Vibe Gardens</h1>
            <p className="text-xl max-w-3xl">Discover the story behind Ghana's premier luxury outdoor event center</p>
          </div>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">Our Story</h2>
              <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                The Vibe Gardens was born from a vision to create Ghana's most sophisticated outdoor event destination. 
                Located in the serene area of Adenta Commandos, we have transformed this beautiful space into a 
                luxury haven where memorable moments are crafted with precision and elegance.
              </p>
              <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                Since our establishment, we have been committed to providing exceptional experiences that blend 
                natural beauty with modern luxury. Our meticulously maintained gardens, state-of-the-art facilities, 
                and premium accommodations make us the preferred choice for discerning clients.
              </p>
              <p className="text-lg text-gray-600 leading-relaxed">
                Whether you're planning an intimate gathering or a grand celebration, The Vibe Gardens offers 
                the perfect setting where your vision comes to life surrounded by the beauty of nature.
              </p>
            </div>
            <div>
              <img
                src="https://readdy.ai/api/search-image?query=luxury%20outdoor%20event%20center%20with%20beautiful%20garden%20landscaping%2C%20elegant%20outdoor%20dining%20setup%2C%20premium%20lighting%2C%20sophisticated%20ambiance%2C%20Ghana%20outdoor%20venue%2C%20high-end%20landscape%20design%2C%20tropical%20plants%2C%20evening%20atmosphere&width=600&height=400&seq=story-img&orientation=landscape"
                alt="The Vibe Gardens Story"
                className="rounded-lg shadow-xl object-cover object-top w-full h-96"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Our Mission & Values */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Our Mission & Values</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              We are dedicated to creating extraordinary experiences through luxury, elegance, and exceptional service.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-8 bg-white rounded-lg shadow-lg">
              <div className="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="ri-heart-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Excellence</h3>
              <p className="text-gray-600 leading-relaxed">
                We strive for perfection in every detail, ensuring that every event exceeds expectations 
                and creates lasting memories.
              </p>
            </div>

            <div className="text-center p-8 bg-white rounded-lg shadow-lg">
              <div className="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="ri-leaf-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Sustainability</h3>
              <p className="text-gray-600 leading-relaxed">
                We maintain our beautiful gardens with eco-friendly practices while preserving the natural 
                beauty that makes our venue special.
              </p>
            </div>

            <div className="text-center p-8 bg-white rounded-lg shadow-lg">
              <div className="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="ri-user-heart-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Service</h3>
              <p className="text-gray-600 leading-relaxed">
                Our dedicated team provides personalized service to ensure every guest feels valued and 
                every event is executed flawlessly.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Our Leadership Team</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Meet the passionate professionals who make The Vibe Gardens exceptional.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <img
                src="https://readdy.ai/api/search-image?query=professional%20African%20business%20woman%20in%20elegant%20attire%2C%20confident%20smile%2C%20sophisticated%20business%20portrait%2C%20Ghana%20professional%2C%20luxury%20hospitality%20executive%2C%20elegant%20office%20setting%2C%20premium%20business%20environment&width=300&height=300&seq=team-1&orientation=squarish"
                alt="Sarah Mensah"
                className="w-48 h-48 rounded-full mx-auto mb-6 object-cover object-top shadow-lg"
              />
              <h3 className="text-xl font-bold text-gray-900 mb-2">Sarah Mensah</h3>
              <p className="text-red-500 font-medium mb-3">Managing Director</p>
              <p className="text-gray-600 leading-relaxed">
                With over 15 years in luxury hospitality, Sarah brings exceptional leadership and vision to The Vibe Gardens.
              </p>
            </div>

            <div className="text-center">
              <img
                src="https://readdy.ai/api/search-image?query=professional%20African%20business%20man%20in%20elegant%20suit%2C%20confident%20demeanor%2C%20sophisticated%20business%20portrait%2C%20Ghana%20professional%2C%20luxury%20event%20management%20executive%2C%20elegant%20office%20setting%2C%20premium%20business%20environment&width=300&height=300&seq=team-2&orientation=squarish"
                alt="Michael Asante"
                className="w-48 h-48 rounded-full mx-auto mb-6 object-cover object-top shadow-lg"
              />
              <h3 className="text-xl font-bold text-gray-900 mb-2">Michael Asante</h3>
              <p className="text-red-500 font-medium mb-3">Events Director</p>
              <p className="text-gray-600 leading-relaxed">
                Michael's creative expertise and attention to detail ensure every event is executed to perfection.
              </p>
            </div>

            <div className="text-center">
              <img
                src="https://readdy.ai/api/search-image?query=professional%20African%20business%20woman%20in%20elegant%20business%20attire%2C%20warm%20smile%2C%20sophisticated%20business%20portrait%2C%20Ghana%20professional%2C%20luxury%20hospitality%20manager%2C%20elegant%20office%20setting%2C%20premium%20business%20environment&width=300&height=300&seq=team-3&orientation=squarish"
                alt="Grace Owusu"
                className="w-48 h-48 rounded-full mx-auto mb-6 object-cover object-top shadow-lg"
              />
              <h3 className="text-xl font-bold text-gray-900 mb-2">Grace Owusu</h3>
              <p className="text-red-500 font-medium mb-3">Guest Relations Manager</p>
              <p className="text-gray-600 leading-relaxed">
                Grace ensures every guest receives personalized service and exceptional hospitality throughout their stay.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 bg-black text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-6">Experience The Vibe Gardens Difference</h2>
          <p className="text-xl mb-8 max-w-3xl mx-auto">
            Ready to create your perfect event? Contact us today and let our experienced team bring your vision to life.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/contact">
              <Button size="lg" className="transform hover:scale-105">
                <i className="ri-phone-line mr-2 w-5 h-5 flex items-center justify-center"></i>
                Contact Us Today
              </Button>
            </Link>
            <Link href="/event-space">
              <Button variant="outline" size="lg" className="transform hover:scale-105">
                <i className="ri-calendar-event-line mr-2 w-5 h-5 flex items-center justify-center"></i>
                View Event Spaces
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </>
  );
}