'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Button from '@/components/ui/Button';
import { useState } from 'react';

export default function Accommodation() {
  const [selectedRoom, setSelectedRoom] = useState('deluxe');

  const rooms = {
    deluxe: {
      name: 'Deluxe Garden Suite',
      price: 'GHS 450/night',
      guests: '2-3 guests',
      features: ['King-size bed', 'Garden view balcony', 'Premium bathroom', 'Mini kitchenette', 'Work desk', 'Complimentary WiFi', '24/7 room service', 'Air conditioning'],
      image: 'https://readdy.ai/api/search-image?query=luxury%20hotel%20suite%20bedroom%20with%20elegant%20modern%20furniture%2C%20king%20size%20bed%2C%20garden%20view%20balcony%2C%20premium%20interior%20design%2C%20sophisticated%20decor%2C%20Ghana%20luxury%20accommodation%2C%20high-end%20hotel%20room%2C%20elegant%20lighting&width=800&height=500&seq=deluxe-suite&orientation=landscape'
    },
    executive: {
      name: 'Executive Villa',
      price: 'GHS 750/night',
      guests: '4-6 guests',
      features: ['2 bedrooms', 'Living room', 'Full kitchen', 'Private garden access', 'Dining area', 'Premium amenities', 'Concierge service', 'Laundry service'],
      image: 'https://readdy.ai/api/search-image?query=luxury%20villa%20interior%20with%20elegant%20living%20room%2C%20modern%20kitchen%2C%20sophisticated%20furniture%2C%20premium%20amenities%2C%20Ghana%20luxury%20accommodation%2C%20high-end%20villa%20design%2C%20elegant%20decor%2C%20spacious%20layout&width=800&height=500&seq=executive-villa&orientation=landscape'
    },
    presidential: {
      name: 'Presidential Garden Villa',
      price: 'GHS 1200/night',
      guests: '6-8 guests',
      features: ['3 bedrooms', 'Master suite', 'Full kitchen & dining', 'Private pool access', 'Butler service', 'Premium spa bathroom', 'Entertainment room', 'Private chef available'],
      image: 'https://readdy.ai/api/search-image?query=presidential%20luxury%20villa%20with%20master%20bedroom%2C%20private%20pool%2C%20elegant%20interior%20design%2C%20sophisticated%20furniture%2C%20premium%20amenities%2C%20Ghana%20luxury%20accommodation%2C%20high-end%20villa%2C%20executive%20suite&width=800&height=500&seq=presidential-villa&orientation=landscape'
    }
  };

  return (
    <>
      <Header />
      
      {/* Hero Section */}
      <section 
        className="relative h-96 bg-cover bg-center"
        style={{
          backgroundImage: `linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url('https://readdy.ai/api/search-image?query=luxury%20hotel%20accommodation%20exterior%20with%20beautiful%20garden%20landscaping%2C%20elegant%20building%20design%2C%20premium%20outdoor%20lighting%2C%20Ghana%20luxury%20hotel%2C%20sophisticated%20architecture%2C%20tropical%20setting&width=1920&height=600&seq=accommodation-hero&orientation=landscape')`
        }}
      >
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center text-white">
            <h1 className="text-5xl font-bold mb-4">Luxury Accommodation</h1>
            <p className="text-xl max-w-3xl">Experience premium comfort in our elegantly appointed suites and villas</p>
          </div>
        </div>
      </section>

      {/* Room Selection */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Choose Your Perfect Stay</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              From intimate suites to spacious villas, each accommodation offers luxury amenities and stunning garden views.
            </p>
          </div>

          {/* Room Tabs */}
          <div className="flex justify-center mb-12">
            <div className="bg-gray-100 p-1 rounded-full">
              {Object.keys(rooms).map((roomKey) => (
                <button
                  key={roomKey}
                  onClick={() => setSelectedRoom(roomKey)}
                  className={`px-6 py-2 rounded-full transition-all duration-200 cursor-pointer whitespace-nowrap ${
                    selectedRoom === roomKey
                      ? 'bg-red-500 text-white'
                      : 'text-gray-600 hover:text-red-500'
                  }`}
                >
                  {rooms[roomKey].name}
                </button>
              ))}
            </div>
          </div>

          {/* Selected Room Details */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <img
                src={rooms[selectedRoom].image}
                alt={rooms[selectedRoom].name}
                className="rounded-lg shadow-xl object-cover object-top w-full h-96"
              />
            </div>
            <div>
              <h3 className="text-3xl font-bold text-gray-900 mb-4">{rooms[selectedRoom].name}</h3>
              <div className="flex flex-col sm:flex-row gap-4 mb-6">
                <p className="text-2xl text-red-500 font-bold">{rooms[selectedRoom].price}</p>
                <p className="text-xl text-gray-600">• {rooms[selectedRoom].guests}</p>
              </div>
              
              <h4 className="text-xl font-bold text-gray-900 mb-4">Amenities & Features:</h4>
              <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 mb-8">
                {rooms[selectedRoom].features.map((feature, index) => (
                  <li key={index} className="flex items-start">
                    <i className="ri-check-line text-red-500 text-lg mt-1 mr-2 w-4 h-4 flex items-center justify-center"></i>
                    <span className="text-gray-600 text-sm">{feature}</span>
                  </li>
                ))}
              </ul>

              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="transform hover:scale-105">
                  <i className="ri-calendar-check-line mr-2 w-5 h-5 flex items-center justify-center"></i>
                  Check Availability
                </Button>
                <Button variant="outline" size="lg" className="transform hover:scale-105">
                  <i className="ri-phone-line mr-2 w-5 h-5 flex items-center justify-center"></i>
                  Call for Booking
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Booking Information */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Booking Information</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Everything you need to know about booking your stay at The Vibe Gardens.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-lg shadow-lg">
              <div className="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="ri-calendar-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4 text-center">Check-in/Check-out</h3>
              <ul className="space-y-2 text-gray-600">
                <li>Check-in: 2:00 PM</li>
                <li>Check-out: 12:00 PM</li>
                <li>Early check-in available (fee applies)</li>
                <li>Late check-out upon request</li>
              </ul>
            </div>

            <div className="bg-white p-8 rounded-lg shadow-lg">
              <div className="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="ri-shield-check-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4 text-center">Policies</h3>
              <ul className="space-y-2 text-gray-600">
                <li>Free cancellation up to 48 hours</li>
                <li>50% deposit required for booking</li>
                <li>Valid ID required at check-in</li>
                <li>No smoking policy indoors</li>
              </ul>
            </div>

            <div className="bg-white p-8 rounded-lg shadow-lg">
              <div className="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="ri-gift-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4 text-center">Inclusions</h3>
              <ul className="space-y-2 text-gray-600">
                <li>Complimentary breakfast</li>
                <li>Free WiFi throughout</li>
                <li>Access to garden areas</li>
                <li>24/7 concierge service</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Services & Amenities */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Premium Services</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Enjoy a comprehensive range of services designed to make your stay exceptional.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-restaurant-2-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Dining Services</h3>
              <p className="text-gray-600 text-sm">In-room dining, breakfast service, and restaurant access</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-car-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Transportation</h3>
              <p className="text-gray-600 text-sm">Airport transfers, car rental, and local transportation</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-shirt-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Laundry</h3>
              <p className="text-gray-600 text-sm">Same-day laundry and dry cleaning services</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-customer-service-2-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Concierge</h3>
              <p className="text-gray-600 text-sm">24/7 assistance with bookings and local recommendations</p>
            </div>
          </div>
        </div>
      </section>

      {/* Booking Form */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Quick Booking Inquiry</h2>
            <p className="text-xl text-gray-600">
              Fill out this form and we'll get back to you with availability and pricing within 24 hours.
            </p>
          </div>

          <form id="accommodation-booking" className="bg-white p-8 rounded-lg shadow-lg">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div>
                <label className="block text-gray-700 font-semibold mb-2">Full Name *</label>
                <input
                  type="text"
                  name="fullName"
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                  placeholder="Your full name"
                />
              </div>
              <div>
                <label className="block text-gray-700 font-semibold mb-2">Phone Number *</label>
                <input
                  type="tel"
                  name="phone"
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                  placeholder="Your phone number"
                />
              </div>
            </div>

            <div className="mb-6">
              <label className="block text-gray-700 font-semibold mb-2">Email Address *</label>
              <input
                type="email"
                name="email"
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                placeholder="your.email@example.com"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              <div>
                <label className="block text-gray-700 font-semibold mb-2">Check-in Date *</label>
                <input
                  type="date"
                  name="checkinDate"
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-gray-700 font-semibold mb-2">Check-out Date *</label>
                <input
                  type="date"
                  name="checkoutDate"
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-gray-700 font-semibold mb-2">Number of Guests</label>
                <select
                  name="guests"
                  className="w-full px-4 py-3 pr-8 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                >
                  <option value="1">1 Guest</option>
                  <option value="2">2 Guests</option>
                  <option value="3">3 Guests</option>
                  <option value="4">4 Guests</option>
                  <option value="5">5 Guests</option>
                  <option value="6">6+ Guests</option>
                </select>
              </div>
            </div>

            <div className="mb-6">
              <label className="block text-gray-700 font-semibold mb-2">Preferred Room Type</label>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <label className="flex items-center">
                  <input type="radio" name="roomType" value="deluxe" className="mr-2" />
                  Deluxe Garden Suite
                </label>
                <label className="flex items-center">
                  <input type="radio" name="roomType" value="executive" className="mr-2" />
                  Executive Villa
                </label>
                <label className="flex items-center">
                  <input type="radio" name="roomType" value="presidential" className="mr-2" />
                  Presidential Villa
                </label>
              </div>
            </div>

            <div className="mb-6">
              <label className="block text-gray-700 font-semibold mb-2">Special Requests</label>
              <textarea
                name="specialRequests"
                rows={4}
                maxLength={500}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent resize-none"
                placeholder="Any special requests or requirements (max 500 characters)"
              ></textarea>
            </div>

            <div className="text-center">
              <Button type="submit" size="lg" className="transform hover:scale-105">
                <i className="ri-send-plane-line mr-2 w-5 h-5 flex items-center justify-center"></i>
                Submit Booking Inquiry
              </Button>
            </div>
          </form>
        </div>
      </section>

      <Footer />
    </>
  );
}