'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Button from '@/components/ui/Button';
import { useState } from 'react';

export default function Contact() {
  const [formStatus, setFormStatus] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    setFormStatus('Thank you for your inquiry! We will get back to you within 24 hours.');
    e.target.reset();
  };

  const contactInfo = [
    {
      icon: 'ri-phone-line',
      title: 'Call Us',
      details: ['+233 24 123 4567', '+233 20 987 6543'],
      action: 'tel:+233241234567'
    },
    {
      icon: 'ri-mail-line',
      title: 'Email Us',
      details: ['info@thevibegardens.com', 'events@thevibegardens.com'],
      action: 'mailto:info@thevibegardens.com'
    },
    {
      icon: 'ri-map-pin-line',
      title: 'Visit Us',
      details: ['The Vibe Gardens', 'Adenta Commandos, Ghana'],
      action: '#location'
    },
    {
      icon: 'ri-whatsapp-line',
      title: 'WhatsApp',
      details: ['+233 24 123 4567', 'Quick response guaranteed'],
      action: 'https://wa.me/233241234567'
    }
  ];

  const operatingHours = [
    { day: 'Monday - Friday', hours: '8:00 AM - 6:00 PM' },
    { day: 'Saturday', hours: '9:00 AM - 8:00 PM' },
    { day: 'Sunday', hours: '10:00 AM - 6:00 PM' },
    { day: 'Public Holidays', hours: 'By Appointment' }
  ];

  const faqs = [
    {
      question: 'How far in advance should I book?',
      answer: 'We recommend booking at least 3-6 months in advance for weddings and major events, and 1-2 months for smaller celebrations to ensure availability.'
    },
    {
      question: 'Do you provide catering services?',
      answer: 'Yes, we offer premium catering services with both local and international cuisine options. We can also accommodate dietary restrictions and special requests.'
    },
    {
      question: 'What is included in the venue rental?',
      answer: 'Our venue rental includes tables, chairs, basic sound system, lighting, parking, and access to bridal suite. Additional services can be added as needed.'
    },
    {
      question: 'Can I bring my own decorators?',
      answer: 'Absolutely! You can bring your own decorators, or we can recommend trusted partners from our network of professional vendors.'
    },
    {
      question: 'Is there accommodation on-site?',
      answer: 'Yes, we offer luxury accommodation options including suites and villas for guests who want to stay overnight. Perfect for destination events.'
    },
    {
      question: 'What happens if it rains during my outdoor event?',
      answer: 'We have covered pavilion areas and can provide additional tenting options. We also monitor weather forecasts and work with you on contingency plans.'
    }
  ];

  return (
    <>
      <Header />
      
      {/* Hero Section */}
      <section 
        className="relative h-96 bg-cover bg-center"
        style={{
          backgroundImage: `linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url('https://readdy.ai/api/search-image?query=elegant%20contact%20us%20banner%20for%20luxury%20venue%2C%20professional%20customer%20service%2C%20Ghana%20premium%20venue%20contact%2C%20sophisticated%20business%20communication%2C%20luxury%20hospitality%20contact&width=1920&height=600&seq=contact-hero&orientation=landscape')`
        }}
      >
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center text-white">
            <h1 className="text-5xl font-bold mb-4">Contact Us</h1>
            <p className="text-xl max-w-3xl">Ready to plan your perfect event? Get in touch with our team today</p>
          </div>
        </div>
      </section>

      {/* Contact Information */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Get In Touch</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              We're here to help you create the perfect event. Contact us through any of the following channels.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {contactInfo.map((info, index) => (
              <div key={index} className="text-center p-6 bg-gray-50 rounded-lg hover:shadow-lg transition-shadow">
                <div className="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className={`${info.icon} text-white text-2xl w-8 h-8 flex items-center justify-center`}></i>
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">{info.title}</h3>
                {info.details.map((detail, idx) => (
                  <p key={idx} className="text-gray-600 mb-1">{detail}</p>
                ))}
                <a
                  href={info.action}
                  className="inline-block mt-3 text-red-500 hover:text-red-600 font-medium cursor-pointer"
                  {...(info.action.startsWith('http') ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
                >
                  Contact Now
                </a>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Form & Operating Hours */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            {/* Contact Form */}
            <div className="lg:col-span-2">
              <div className="bg-white p-8 rounded-lg shadow-lg">
                <h3 className="text-3xl font-bold text-gray-900 mb-6">Send Us a Message</h3>
                
                {formStatus && (
                  <div className="mb-6 p-4 bg-green-100 border border-green-400 text-green-700 rounded-lg">
                    {formStatus}
                  </div>
                )}

                <form id="contact-form" onSubmit={handleSubmit}>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <div>
                      <label className="block text-gray-700 font-semibold mb-2">Full Name *</label>
                      <input
                        type="text"
                        name="fullName"
                        required
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                        placeholder="Your full name"
                      />
                    </div>
                    <div>
                      <label className="block text-gray-700 font-semibold mb-2">Phone Number *</label>
                      <input
                        type="tel"
                        name="phone"
                        required
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                        placeholder="Your phone number"
                      />
                    </div>
                  </div>

                  <div className="mb-6">
                    <label className="block text-gray-700 font-semibold mb-2">Email Address *</label>
                    <input
                      type="email"
                      name="email"
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                      placeholder="your.email@example.com"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <div>
                      <label className="block text-gray-700 font-semibold mb-2">Event Type</label>
                      <select
                        name="eventType"
                        className="w-full px-4 py-3 pr-8 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                      >
                        <option value="">Select event type</option>
                        <option value="wedding">Wedding</option>
                        <option value="corporate">Corporate Event</option>
                        <option value="birthday">Birthday Party</option>
                        <option value="anniversary">Anniversary</option>
                        <option value="graduation">Graduation</option>
                        <option value="other">Other</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-gray-700 font-semibold mb-2">Preferred Date</label>
                      <input
                        type="date"
                        name="preferredDate"
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <div>
                      <label className="block text-gray-700 font-semibold mb-2">Number of Guests</label>
                      <select
                        name="guestCount"
                        className="w-full px-4 py-3 pr-8 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                      >
                        <option value="">Select guest count</option>
                        <option value="1-50">1-50 guests</option>
                        <option value="51-100">51-100 guests</option>
                        <option value="101-200">101-200 guests</option>
                        <option value="201-300">201-300 guests</option>
                        <option value="300+">300+ guests</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-gray-700 font-semibold mb-2">Budget Range</label>
                      <select
                        name="budget"
                        className="w-full px-4 py-3 pr-8 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                      >
                        <option value="">Select budget range</option>
                        <option value="under-5000">Under GHS 5,000</option>
                        <option value="5000-10000">GHS 5,000 - 10,000</option>
                        <option value="10000-20000">GHS 10,000 - 20,000</option>
                        <option value="20000+">GHS 20,000+</option>
                      </select>
                    </div>
                  </div>

                  <div className="mb-6">
                    <label className="block text-gray-700 font-semibold mb-2">Services Needed</label>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                      <label className="flex items-center">
                        <input type="checkbox" name="services" value="venue-rental" className="mr-2" />
                        Venue Rental
                      </label>
                      <label className="flex items-center">
                        <input type="checkbox" name="services" value="catering" className="mr-2" />
                        Catering
                      </label>
                      <label className="flex items-center">
                        <input type="checkbox" name="services" value="accommodation" className="mr-2" />
                        Accommodation
                      </label>
                      <label className="flex items-center">
                        <input type="checkbox" name="services" value="decoration" className="mr-2" />
                        Decoration
                      </label>
                      <label className="flex items-center">
                        <input type="checkbox" name="services" value="photography" className="mr-2" />
                        Photography
                      </label>
                      <label className="flex items-center">
                        <input type="checkbox" name="services" value="other" className="mr-2" />
                        Other Services
                      </label>
                    </div>
                  </div>

                  <div className="mb-6">
                    <label className="block text-gray-700 font-semibold mb-2">Message *</label>
                    <textarea
                      name="message"
                      rows={5}
                      maxLength={500}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent resize-none"
                      placeholder="Tell us about your event vision and any specific requirements... (max 500 characters)"
                    ></textarea>
                  </div>

                  <div className="text-center">
                    <Button type="submit" size="lg" className="transform hover:scale-105">
                      <i className="ri-send-plane-line mr-2 w-5 h-5 flex items-center justify-center"></i>
                      Send Message
                    </Button>
                  </div>
                </form>
              </div>
            </div>

            {/* Operating Hours & Quick Info */}
            <div className="space-y-8">
              {/* Operating Hours */}
              <div className="bg-white p-8 rounded-lg shadow-lg">
                <h3 className="text-2xl font-bold text-gray-900 mb-6">Operating Hours</h3>
                <div className="space-y-4">
                  {operatingHours.map((schedule, index) => (
                    <div key={index} className="flex justify-between items-center py-2 border-b border-gray-200 last:border-b-0">
                      <span className="font-medium text-gray-700">{schedule.day}</span>
                      <span className="text-gray-600">{schedule.hours}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Quick Response Promise */}
              <div className="bg-red-500 text-white p-8 rounded-lg">
                <h3 className="text-2xl font-bold mb-4">Quick Response Promise</h3>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <i className="ri-check-line text-xl mt-1 mr-3 w-5 h-5 flex items-center justify-center"></i>
                    <span>Email responses within 4 hours</span>
                  </li>
                  <li className="flex items-start">
                    <i className="ri-check-line text-xl mt-1 mr-3 w-5 h-5 flex items-center justify-center"></i>
                    <span>Phone calls answered immediately</span>
                  </li>
                  <li className="flex items-start">
                    <i className="ri-check-line text-xl mt-1 mr-3 w-5 h-5 flex items-center justify-center"></i>
                    <span>WhatsApp messages replied instantly</span>
                  </li>
                  <li className="flex items-start">
                    <i className="ri-check-line text-xl mt-1 mr-3 w-5 h-5 flex items-center justify-center"></i>
                    <span>Site visits scheduled within 24 hours</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Frequently Asked Questions</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Find quick answers to common questions about our venue and services.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {faqs.map((faq, index) => (
              <div key={index} className="bg-gray-50 p-6 rounded-lg">
                <h3 className="text-lg font-bold text-gray-900 mb-3">{faq.question}</h3>
                <p className="text-gray-600 leading-relaxed">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Location Map */}
      <section id="location" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Find Us</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Located in the serene area of Adenta Commandos, easily accessible from all parts of Ghana.
            </p>
          </div>

          <div className="bg-white rounded-lg shadow-lg overflow-hidden">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3970.7267966289534!2d-0.1654298862828944!3d5.676869495657843!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xfdf9068ed3d1b4b%3A0x1ed49e01a7b4b7f7!2sAdenta%20Commandos%2C%20Ghana!5e0!3m2!1sen!2sus!4v1634567890123!5m2!1sen!2sus"
              width="100%"
              height="400"
              style={{ border: 0 }}
              allowFullScreen=""
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="The Vibe Gardens Location"
            ></iframe>
            
            <div className="p-8">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="text-center">
                  <div className="w-12 h-12 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-3">
                    <i className="ri-map-pin-line text-white text-xl w-6 h-6 flex items-center justify-center"></i>
                  </div>
                  <h4 className="font-bold text-gray-900 mb-2">Address</h4>
                  <p className="text-gray-600">Adenta Commandos<br />Accra, Ghana</p>
                </div>
                <div className="text-center">
                  <div className="w-12 h-12 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-3">
                    <i className="ri-car-line text-white text-xl w-6 h-6 flex items-center justify-center"></i>
                  </div>
                  <h4 className="font-bold text-gray-900 mb-2">Parking</h4>
                  <p className="text-gray-600">Free parking for<br />100+ vehicles</p>
                </div>
                <div className="text-center">
                  <div className="w-12 h-12 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-3">
                    <i className="ri-time-line text-white text-xl w-6 h-6 flex items-center justify-center"></i>
                  </div>
                  <h4 className="font-bold text-gray-900 mb-2">Distance</h4>
                  <p className="text-gray-600">15 minutes from<br />Accra city center</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </>
  );
}