'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Button from '@/components/ui/Button';
import Link from 'next/link';

export default function Home() {
  return (
    <>
      <Header />
      
      {/* Hero Section */}
      <section 
        className="relative h-screen bg-cover bg-center bg-fixed"
        style={{
          backgroundImage: `linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url('https://readdy.ai/api/search-image?query=luxurious%20outdoor%20garden%20event%20venue%20with%20elegant%20landscaping%2C%20premium%20outdoor%20furniture%2C%20beautiful%20lighting%2C%20sophisticated%20ambiance%2C%20evening%20atmosphere%2C%20high-end%20event%20space%2C%20tropical%20plants%2C%20Ghana%20setting%2C%20luxury%20outdoor%20dining%20area%2C%20elegant%20pavilion%20structure&width=1920&height=1080&seq=hero-main&orientation=landscape')`
        }}
      >
        <div className="absolute inset-0 bg-black bg-opacity-40"></div>
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center">
          <div className="w-full text-center text-white">
            <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
              Experience Luxury at
              <span className="block text-red-500 font-pacifico">The Vibe Gardens</span>
            </h1>
            <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto leading-relaxed">
              Ghana's most prestigious outdoor event center, where elegance meets nature 
              in the heart of Adenta Commandos. Create unforgettable memories in our 
              luxurious garden spaces.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/event-space">
                <Button size="lg" className="transform hover:scale-105">
                  <i className="ri-calendar-event-line mr-2 w-5 h-5 flex items-center justify-center"></i>
                  Book Your Event
                </Button>
              </Link>
              <Link href="/accommodation">
                <Button variant="outline" size="lg" className="transform hover:scale-105">
                  <i className="ri-hotel-bed-line mr-2 w-5 h-5 flex items-center justify-center"></i>
                  View Accommodation
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Brief Highlights */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Why Choose The Vibe Gardens?</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              We combine luxury, comfort, and natural beauty to create the perfect setting for your most important occasions.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-8 bg-gray-50 rounded-lg hover:shadow-lg transition-shadow">
              <div className="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="ri-plant-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Premium Outdoor Spaces</h3>
              <p className="text-gray-600 leading-relaxed">
                Beautifully landscaped gardens with state-of-the-art facilities, perfect for weddings, 
                corporate events, and private celebrations.
              </p>
            </div>

            <div className="text-center p-8 bg-gray-50 rounded-lg hover:shadow-lg transition-shadow">
              <div className="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="ri-hotel-bed-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Luxury Accommodation</h3>
              <p className="text-gray-600 leading-relaxed">
                Elegant short-let accommodation and Airbnb options with premium amenities 
                for guests who want to extend their stay.
              </p>
            </div>

            <div className="text-center p-8 bg-gray-50 rounded-lg hover:shadow-lg transition-shadow">
              <div className="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="ri-customer-service-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Exceptional Service</h3>
              <p className="text-gray-600 leading-relaxed">
                Our dedicated team ensures every detail is perfect, from planning to execution, 
                making your event truly unforgettable.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">
                Where Dreams Come to Life
              </h2>
              <p className="text-lg text-gray-600 mb-8 leading-relaxed">
                The Vibe Gardens is more than just a venue – it's where your vision becomes reality. 
                Our meticulously maintained gardens provide the perfect backdrop for any occasion, 
                while our luxury accommodations ensure your guests have a complete experience.
              </p>
              
              <div className="space-y-4">
                <div className="flex items-start">
                  <i className="ri-check-line text-red-500 text-xl mt-1 mr-3 w-5 h-5 flex items-center justify-center"></i>
                  <div>
                    <h4 className="font-semibold text-gray-900">Elegant Outdoor Spaces</h4>
                    <p className="text-gray-600">Beautifully landscaped gardens with premium facilities</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <i className="ri-check-line text-red-500 text-xl mt-1 mr-3 w-5 h-5 flex items-center justify-center"></i>
                  <div>
                    <h4 className="font-semibold text-gray-900">Full-Service Planning</h4>
                    <p className="text-gray-600">Professional event coordination and management</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <i className="ri-check-line text-red-500 text-xl mt-1 mr-3 w-5 h-5 flex items-center justify-center"></i>
                  <div>
                    <h4 className="font-semibold text-gray-900">Luxury Accommodations</h4>
                    <p className="text-gray-600">Premium short-let options for extended stays</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <i className="ri-check-line text-red-500 text-xl mt-1 mr-3 w-5 h-5 flex items-center justify-center"></i>
                  <div>
                    <h4 className="font-semibold text-gray-900">Prime Location</h4>
                    <p className="text-gray-600">Conveniently located in Adenta Commandos</p>
                  </div>
                </div>
              </div>

              <div className="mt-8">
                <Link href="/about">
                  <Button size="lg">
                    Learn More About Us
                  </Button>
                </Link>
              </div>
            </div>

            <div className="relative">
              <img
                src="https://readdy.ai/api/search-image?query=elegant%20outdoor%20event%20setup%20with%20luxury%20furniture%2C%20beautiful%20garden%20landscaping%2C%20premium%20lighting%2C%20sophisticated%20dining%20area%2C%20Ghana%20outdoor%20venue%2C%20high-end%20event%20decoration%2C%20tropical%20plants%2C%20evening%20ambiance%2C%20luxury%20outdoor%20reception&width=600&height=400&seq=features-img&orientation=landscape"
                alt="The Vibe Gardens Event Space"
                className="rounded-lg shadow-xl object-cover object-top w-full h-96"
              />
              <div className="absolute -bottom-6 -right-6 bg-red-500 text-white p-6 rounded-lg shadow-lg">
                <p className="text-sm font-medium">Available for</p>
                <p className="text-2xl font-bold">Events & Stays</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-black text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-6">Ready to Create Your Perfect Event?</h2>
          <p className="text-xl mb-8 max-w-3xl mx-auto">
            Contact us today to discuss your vision and let us help you create an unforgettable experience 
            at The Vibe Gardens. Our team is ready to bring your dreams to life.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/contact">
              <Button size="lg" className="transform hover:scale-105">
                <i className="ri-phone-line mr-2 w-5 h-5 flex items-center justify-center"></i>
                Get Quote Now
              </Button>
            </Link>
            <Link href="/gallery">
              <Button variant="outline" size="lg" className="transform hover:scale-105">
                <i className="ri-gallery-line mr-2 w-5 h-5 flex items-center justify-center"></i>
                View Gallery
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </>
  );
}