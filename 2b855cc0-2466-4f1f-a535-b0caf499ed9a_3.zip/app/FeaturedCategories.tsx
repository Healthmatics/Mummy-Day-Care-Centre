
'use client';

import Link from 'next/link';

export default function FeaturedCategories() {
  const categories = [
    {
      name: 'Clothing',
      description: 'Premium fashion for every occasion',
      image: 'https://readdy.ai/api/search-image?query=Luxury%20designer%20clothing%20collection%20hanging%20in%20premium%20boutique%2C%20elegant%20dresses%20shirts%20and%20formal%20wear%2C%20sophisticated%20fashion%20display%20with%20black%20and%20red%20accents%2C%20high-end%20retail%20presentation%2C%20modern%20clothing%20rack%20with%20beautiful%20lighting&width=400&height=500&seq=clothing-cat&orientation=portrait',
      link: '/shop?category=clothing'
    },
    {
      name: 'Shoes',
      description: 'Step forward in style',
      image: 'https://readdy.ai/api/search-image?query=Premium%20designer%20shoes%20collection%20display%2C%20luxury%20high%20heels%20sneakers%20and%20formal%20footwear%2C%20elegant%20shoe%20boutique%20presentation%2C%20sophisticated%20retail%20display%20with%20black%20background%20and%20red%20lighting%20accents%2C%20modern%20shoe%20store%20layout&width=400&height=500&seq=shoes-cat&orientation=portrait',
      link: '/shop?category=shoes'
    },
    {
      name: 'Jewellery',
      description: 'Sparkle with elegance',
      image: 'https://readdy.ai/api/search-image?query=Luxury%20jewelry%20display%20case%20with%20premium%20necklaces%20earrings%20rings%20and%20bracelets%2C%20elegant%20jewelry%20boutique%20presentation%2C%20sophisticated%20gold%20and%20diamond%20accessories%2C%20high-end%20jewelry%20store%20with%20black%20velvet%20display%20and%20red%20accent%20lighting&width=400&height=500&seq=jewelry-cat&orientation=portrait',
      link: '/shop?category=jewellery'
    },
    {
      name: 'Mom & Kids',
      description: 'Fashion for the whole family',
      image: 'https://readdy.ai/api/search-image?query=Premium%20mother%20and%20children%20fashion%20collection%2C%20elegant%20family%20clothing%20display%20in%20boutique%20setting%2C%20sophisticated%20kids%20and%20womens%20wear%20presentation%2C%20high-end%20family%20fashion%20store%20with%20modern%20display%20and%20beautiful%20lighting&width=400&height=500&seq=family-cat&orientation=portrait',
      link: '/shop?category=mom-kids'
    }
  ];

  return (
    <section className="py-20 bg-black">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-red-600 mb-4">
            Shop by Category
          </h2>
          <p className="text-xl text-white max-w-2xl mx-auto">
            Explore our curated collections designed to help you express your unique style
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {categories.map((category, index) => (
            <Link key={index} href={category.link} className="group">
              <div className="bg-red-900/20 rounded-lg overflow-hidden border border-red-600/30 hover:border-lime-500/50 transition-all duration-300">
                <div className="relative h-64 overflow-hidden">
                  <img 
                    src={category.image}
                    alt={category.name}
                    className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-black/40 group-hover:bg-black/30 transition-colors"></div>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold text-red-600 mb-2 group-hover:text-lime-500 transition-colors">
                    {category.name}
                  </h3>
                  <p className="text-white group-hover:text-white transition-colors">
                    {category.description}
                  </p>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
