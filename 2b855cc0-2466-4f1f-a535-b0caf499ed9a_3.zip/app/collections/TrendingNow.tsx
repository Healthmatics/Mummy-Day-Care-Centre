
'use client';

import Link from 'next/link';

export default function TrendingNow() {
  const trendingItems = [
    {
      id: 1,
      name: "Power Suit Collection",
      price: 560,
      image: "https://readdy.ai/api/search-image?query=Premium%20womens%20power%20suit%20in%20black%20with%20red%20accents%2C%20elegant%20professional%20business%20attire%2C%20sophisticated%20blazer%20and%20trousers%20set%20for%20boutique%2C%20luxury%20fashion%20photography%20with%20modern%20styling&width=350&height=450&seq=trend-1&orientation=portrait",
      badge: "Trending"
    },
    {
      id: 2,
      name: "Statement Jewelry Set",
      price: 420,
      image: "https://readdy.ai/api/search-image?query=Luxury%20statement%20jewelry%20set%20with%20gold%20and%20red%20gemstones%2C%20premium%20designer%20necklace%20earrings%20and%20bracelet%20collection%2C%20elegant%20jewelry%20display%20for%20boutique%20with%20black%20background&width=350&height=450&seq=trend-2&orientation=portrait",
      badge: "Hot"
    },
    {
      id: 3,
      name: "Designer Ankle Boots",
      price: 380,
      image: "https://readdy.ai/api/search-image?query=Premium%20designer%20ankle%20boots%20in%20black%20leather%20with%20red%20details%2C%20luxury%20womens%20footwear%20for%20boutique%2C%20elegant%20heel%20boots%20with%20sophisticated%20styling%20and%20beautiful%20photography&width=350&height=450&seq=trend-3&orientation=portrait",
      badge: "Popular"
    }
  ];

  return (
    <section className="py-16 bg-red-900/10">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-red-600 mb-4">Trending Now</h2>
          <p className="text-xl text-white">What everyone is talking about</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {trendingItems.map((item) => (
            <div key={item.id} className="group relative">
              <div className="bg-black rounded-lg overflow-hidden border border-red-600/30 hover:border-lime-500/50 transition-all">
                <div className="relative">
                  <img 
                    src={item.image}
                    alt={item.name}
                    className="w-full h-96 object-cover object-top group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-4 left-4">
                    <span className="bg-lime-500 text-black px-3 py-1 rounded-full text-sm font-semibold">
                      {item.badge}
                    </span>
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold text-red-600 mb-2">{item.name}</h3>
                  <p className="text-2xl font-bold text-lime-500 mb-4">GH₵{item.price}</p>
                  <Link href="/shop" className="btn-primary w-full text-center block">
                    Shop Now
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
