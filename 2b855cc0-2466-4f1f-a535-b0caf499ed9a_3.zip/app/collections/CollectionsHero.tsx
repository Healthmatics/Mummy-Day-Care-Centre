
'use client';

export default function CollectionsHero() {
  return (
    <section className="py-20 bg-black">
      <div className="container mx-auto px-4 text-center">
        <h1 className="text-5xl md:text-6xl font-bold text-red-600 mb-6">
          Our <span className="text-lime-500">Collections</span>
        </h1>
        <p className="text-xl text-white max-w-3xl mx-auto">
          Curated fashion collections that define elegance, style, and confidence. Discover pieces that speak to your unique personality.
        </p>
      </div>
    </section>
  );
}
