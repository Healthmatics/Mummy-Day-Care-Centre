
'use client';

import Link from 'next/link';

export default function NewArrivals() {
  const newItems = [
    {
      id: 1,
      name: "Silk Evening Gown",
      price: 720,
      image: "https://readdy.ai/api/search-image?query=Luxury%20silk%20evening%20gown%20in%20deep%20red%20color%2C%20premium%20designer%20formal%20dress%20for%20special%20occasions%2C%20elegant%20long%20dress%20with%20sophisticated%20draping%20and%20beautiful%20fabric%20flow%2C%20boutique%20fashion%20photography&width=300&height=400&seq=new-1&orientation=portrait"
    },
    {
      id: 2,
      name: "Gold Chain Necklace",
      price: 340,
      image: "https://readdy.ai/api/search-image?query=Premium%20gold%20chain%20necklace%20with%20modern%20design%2C%20luxury%20jewelry%20piece%20for%20everyday%20elegance%2C%20sophisticated%20gold%20necklace%20for%20boutique%20display%20with%20black%20velvet%20background&width=300&height=400&seq=new-2&orientation=portrait"
    },
    {
      id: 3,
      name: "Designer Handbag",
      price: 450,
      image: "https://readdy.ai/api/search-image?query=Luxury%20designer%20handbag%20in%20black%20leather%20with%20red%20accents%2C%20premium%20womens%20accessories%20for%20boutique%2C%20elegant%20structured%20bag%20with%20sophisticated%20hardware%20and%20beautiful%20craftsmanship&width=300&height=400&seq=new-3&orientation=portrait"
    },
    {
      id: 4,
      name: "Kids Formal Suit",
      price: 280,
      image: "https://readdy.ai/api/search-image?query=Premium%20kids%20formal%20suit%20in%20navy%20blue%20with%20red%20tie%2C%20elegant%20children%20formal%20wear%20for%20special%20occasions%2C%20sophisticated%20boys%20outfit%20for%20boutique%20family%20collection&width=300&height=400&seq=new-4&orientation=portrait"
    }
  ];

  return (
    <section className="py-16 bg-black">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-red-600 mb-4">New Arrivals</h2>
          <p className="text-xl text-white">Fresh styles just in</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {newItems.map((item) => (
            <div key={item.id} className="group">
              <div className="bg-red-900/20 rounded-lg overflow-hidden border border-red-600/30 hover:border-lime-500/50 transition-all">
                <div className="relative">
                  <img 
                    src={item.image}
                    alt={item.name}
                    className="w-full h-80 object-cover object-top group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-4 right-4">
                    <span className="bg-red-600 text-white px-2 py-1 rounded-full text-xs font-semibold">
                      NEW
                    </span>
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-lg font-bold text-red-600 mb-2">{item.name}</h3>
                  <p className="text-xl font-bold text-lime-500 mb-4">GH₵{item.price}</p>
                  <Link href="/shop" className="btn-primary w-full text-center block">
                    View Details
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="text-center mt-12">
          <Link href="/shop" className="btn-secondary">
            View All New Arrivals
          </Link>
        </div>
      </div>
    </section>
  );
}
