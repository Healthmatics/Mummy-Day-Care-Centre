
'use client';

import Link from 'next/link';

export default function PremiumPicks() {
  return (
    <section className="py-16 bg-black">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-red-600 mb-4">Premium Picks</h2>
          <p className="text-xl text-white">Exclusive luxury pieces for the discerning fashionista</p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <img 
              src="https://readdy.ai/api/search-image?query=Luxury%20fashion%20collection%20display%20with%20premium%20designer%20clothing%20jewelry%20and%20accessories%2C%20elegant%20boutique%20showcase%20with%20sophisticated%20black%20and%20red%20styling%2C%20high-end%20fashion%20photography%20with%20beautiful%20lighting&width=600&height=700&seq=premium-collection&orientation=portrait"
              alt="Premium Collection"
              className="w-full h-full object-cover object-top rounded-lg"
            />
          </div>
          
          <div className="space-y-8">
            <div>
              <h3 className="text-3xl font-bold text-red-600 mb-4">
                Exclusive Designer Collection
              </h3>
              <p className="text-lg text-white mb-6 leading-relaxed">
                Handpicked luxury pieces from renowned designers. Each item in our premium collection represents the pinnacle of fashion craftsmanship and elegance.
              </p>
              
              <div className="space-y-4 mb-8">
                <div className="flex items-center">
                  <i className="ri-check-line text-lime-500 text-xl mr-3"></i>
                  <span className="text-white">Limited edition designer pieces</span>
                </div>
                <div className="flex items-center">
                  <i className="ri-check-line text-lime-500 text-xl mr-3"></i>
                  <span className="text-white">Premium materials and craftsmanship</span>
                </div>
                <div className="flex items-center">
                  <i className="ri-check-line text-lime-500 text-xl mr-3"></i>
                  <span className="text-white">Exclusive boutique availability</span>
                </div>
                <div className="flex items-center">
                  <i className="ri-check-line text-lime-500 text-xl mr-3"></i>
                  <span className="text-white">Personal styling consultation included</span>
                </div>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/shop" className="btn-primary text-center">
                  Explore Premium Collection
                </Link>
                <Link href="/contact" className="btn-secondary text-center">
                  Book Consultation
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
