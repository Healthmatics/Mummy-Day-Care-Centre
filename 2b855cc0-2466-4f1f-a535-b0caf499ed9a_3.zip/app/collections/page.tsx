
'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import CollectionsHero from './CollectionsHero';
import TrendingNow from './TrendingNow';
import NewArrivals from './NewArrivals';
import BestSellers from './BestSellers';
import PremiumPicks from './PremiumPicks';

export default function CollectionsPage() {
  return (
    <div className="min-h-screen bg-black">
      <Header />
      <main>
        <CollectionsHero />
        <TrendingNow />
        <NewArrivals />
        <BestSellers />
        <PremiumPicks />
      </main>
      <Footer />
    </div>
  );
}
