
'use client';

import Link from 'next/link';

export default function BestSellers() {
  const bestSellers = [
    {
      id: 1,
      name: "Classic Black Dress",
      price: 420,
      originalPrice: 480,
      image: "https://readdy.ai/api/search-image?query=Classic%20little%20black%20dress%20on%20elegant%20model%2C%20timeless%20designer%20dress%20for%20boutique%2C%20sophisticated%20formal%20wear%20with%20perfect%20fit%20and%20beautiful%20styling%2C%20premium%20fashion%20photography&width=300&height=400&seq=best-1&orientation=portrait",
      sales: 150
    },
    {
      id: 2,
      name: "Red Stiletto Heels",
      price: 280,
      originalPrice: 320,
      image: "https://readdy.ai/api/search-image?query=Elegant%20red%20stiletto%20high%20heels%2C%20premium%20designer%20womens%20shoes%20in%20vibrant%20red%20color%2C%20luxury%20footwear%20for%20boutique%20display%20with%20sophisticated%20styling%20and%20beautiful%20lighting&width=300&height=400&seq=best-2&orientation=portrait",
      sales: 120
    },
    {
      id: 3,
      name: "Diamond Earrings",
      price: 350,
      originalPrice: 400,
      image: "https://readdy.ai/api/search-image?query=Luxury%20diamond%20stud%20earrings%20in%20gold%20setting%2C%20premium%20jewelry%20for%20everyday%20elegance%2C%20sophisticated%20diamond%20earrings%20for%20boutique%20jewelry%20collection%20with%20black%20background&width=300&height=400&seq=best-3&orientation=portrait",
      sales: 95
    }
  ];

  return (
    <section className="py-16 bg-red-900/10">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-red-600 mb-4">Best Sellers</h2>
          <p className="text-xl text-red-400">Customer favorites that never go out of style</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {bestSellers.map((item) => (
            <div key={item.id} className="group">
              <div className="bg-black rounded-lg overflow-hidden border border-red-600/30 hover:border-lime-500/50 transition-all">
                <div className="relative">
                  <img 
                    src={item.image}
                    alt={item.name}
                    className="w-full h-96 object-cover object-top group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-4 left-4">
                    <span className="bg-lime-500 text-black px-3 py-1 rounded-full text-sm font-semibold">
                      #{item.sales} sold
                    </span>
                  </div>
                  <div className="absolute top-4 right-4">
                    <span className="bg-red-600 text-white px-2 py-1 rounded-full text-xs font-semibold">
                      BESTSELLER
                    </span>
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold text-red-600 mb-2">{item.name}</h3>
                  <div className="flex items-center gap-2 mb-4">
                    <p className="text-2xl font-bold text-lime-500">GH₵{item.price}</p>
                    <p className="text-lg text-red-400 line-through">GH₵{item.originalPrice}</p>
                  </div>
                  <Link href="/shop" className="btn-primary w-full text-center block">
                    Add to Cart
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
