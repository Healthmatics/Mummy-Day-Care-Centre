
'use client';

import { useState } from 'react';

export default function OrderForm() {
  const [formData, setFormData] = useState({
    fullName: '',
    phoneNumber: '',
    email: '',
    selectedProduct: '',
    size: '',
    color: '',
    quantity: 1,
    deliveryAddress: '',
    city: '',
    region: '',
    additionalNotes: ''
  });
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState('');

  const products = [
    'Elegant Evening Dress - GH₵450',
    'Designer High Heels - GH₵320',
    'Diamond Statement Necklace - GH₢680',
    'Professional Blazer - GH₵380',
    'Luxury Sneakers - GH₵240',
    'Gold Earring Collection - GH₵220',
    'Matching Mother-Daughter Set - GH₵280',
    'Kids Designer Outfit - GH₵180'
  ];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      const formDataToSubmit = new FormData();
      Object.entries(formData).forEach(([key, value]) => {
        formDataToSubmit.append(key, value.toString());
      });

      const response = await fetch('https://formspree.io/f/your-form-id', {
        method: 'POST',
        body: formDataToSubmit,
        headers: {
          'Accept': 'application/json'
        },
      });

      if (response.ok) {
        setSubmitStatus('success');
        setFormData({
          fullName: '',
          phoneNumber: '',
          email: '',
          selectedProduct: '',
          size: '',
          color: '',
          quantity: 1,
          deliveryAddress: '',
          city: '',
          region: '',
          additionalNotes: ''
        });
      } else {
        setSubmitStatus('error');
      }
    } catch (error) {
      setSubmitStatus('error');
    }
    
    setIsSubmitting(false);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <form id="order-form" onSubmit={handleSubmit} className="bg-red-900/20 rounded-lg p-8 border border-red-600/30">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h3 className="text-2xl font-bold text-red-600 mb-6">Personal Information</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-white mb-2 font-semibold">Full Name *</label>
                <input
                  type="text"
                  name="fullName"
                  value={formData.fullName}
                  onChange={handleInputChange}
                  required
                  className="w-full px-4 py-3 bg-black border border-red-600/30 rounded-lg text-white focus:border-lime-500 focus:outline-none"
                  placeholder="Enter your full name"
                />
              </div>
              
              <div>
                <label className="block text-white mb-2 font-semibold">Phone Number *</label>
                <input
                  type="tel"
                  name="phoneNumber"
                  value={formData.phoneNumber}
                  onChange={handleInputChange}
                  required
                  className="w-full px-4 py-3 bg-black border border-red-600/30 rounded-lg text-white focus:border-lime-500 focus:outline-none"
                  placeholder="e.g., 0246146218"
                />
              </div>
              
              <div>
                <label className="block text-white mb-2 font-semibold">Email Address</label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 bg-black border border-red-600/30 rounded-lg text-white focus:border-lime-500 focus:outline-none"
                  placeholder="your.email@example.com"
                />
              </div>
            </div>
          </div>
          
          <div>
            <h3 className="text-2xl font-bold text-red-600 mb-6">Product Details</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-white mb-2 font-semibold">Selected Product *</label>
                <div className="relative">
                  <select
                    name="selectedProduct"
                    value={formData.selectedProduct}
                    onChange={handleInputChange}
                    required
                    className="w-full px-4 py-3 pr-8 bg-black border border-red-600/30 rounded-lg text-white focus:border-lime-500 focus:outline-none appearance-none"
                  >
                    <option value="">Choose a product</option>
                    {products.map((product, index) => (
                      <option key={index} value={product}>{product}</option>
                    ))}
                  </select>
                  <i className="ri-arrow-down-s-line absolute right-3 top-1/2 transform -translate-y-1/2 text-white pointer-events-none"></i>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-white mb-2 font-semibold">Size *</label>
                  <input
                    type="text"
                    name="size"
                    value={formData.size}
                    onChange={handleInputChange}
                    required
                    className="w-full px-4 py-3 bg-black border border-red-600/30 rounded-lg text-white focus:border-lime-500 focus:outline-none"
                    placeholder="e.g., M, L, 38"
                  />
                </div>
                
                <div>
                  <label className="block text-white mb-2 font-semibold">Color</label>
                  <input
                    type="text"
                    name="color"
                    value={formData.color}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 bg-black border border-red-600/30 rounded-lg text-white focus:border-lime-500 focus:outline-none"
                    placeholder="Preferred color"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-white mb-2 font-semibold">Quantity</label>
                <input
                  type="number"
                  name="quantity"
                  value={formData.quantity}
                  onChange={handleInputChange}
                  min="1"
                  className="w-full px-4 py-3 bg-black border border-red-600/30 rounded-lg text-white focus:border-lime-500 focus:outline-none"
                />
              </div>
            </div>
          </div>
        </div>
        
        <div className="mt-8">
          <h3 className="text-2xl font-bold text-red-600 mb-6">Delivery Information</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <div>
              <label className="block text-white mb-2 font-semibold">City *</label>
              <input
                type="text"
                name="city"
                value={formData.city}
                onChange={handleInputChange}
                required
                className="w-full px-4 py-3 bg-black border border-red-600/30 rounded-lg text-white focus:border-lime-500 focus:outline-none"
                placeholder="Your city"
              />
            </div>
            
            <div>
              <label className="block text-white mb-2 font-semibold">Region *</label>
              <input
                type="text"
                name="region"
                value={formData.region}
                onChange={handleInputChange}
                required
                className="w-full px-4 py-3 bg-black border border-red-600/30 rounded-lg text-white focus:border-lime-500 focus:outline-none"
                placeholder="Your region"
              />
            </div>
          </div>
          
          <div className="mb-4">
            <label className="block text-white mb-2 font-semibold">Delivery Address *</label>
            <textarea
              name="deliveryAddress"
              value={formData.deliveryAddress}
              onChange={handleInputChange}
              required
              maxLength={500}
              rows={3}
              className="w-full px-4 py-3 bg-black border border-red-600/30 rounded-lg text-white focus:border-lime-500 focus:outline-none resize-vertical"
              placeholder="Complete delivery address with landmarks"
            />
            <p className="text-sm text-red-500 mt-1">{formData.deliveryAddress.length}/500 characters</p>
          </div>
          
          <div>
            <label className="block text-white mb-2 font-semibold">Additional Notes</label>
            <textarea
              name="additionalNotes"
              value={formData.additionalNotes}
              onChange={handleInputChange}
              maxLength={500}
              rows={3}
              className="w-full px-4 py-3 bg-black border border-red-600/30 rounded-lg text-white focus:border-lime-500 focus:outline-none resize-vertical"
              placeholder="Any special instructions or requests"
            />
            <p className="text-sm text-red-500 mt-1">{formData.additionalNotes.length}/500 characters</p>
          </div>
        </div>
        
        <div className="mt-8 p-6 bg-red-900/30 rounded-lg border border-red-600/30">
          <h4 className="text-xl font-bold text-red-600 mb-4">Payment & Delivery Information</h4>
          <div className="space-y-2 text-white">
            <p><strong>Payment Methods:</strong> Mobile Money, Bank Transfer, Cash on Delivery</p>
            <p><strong>Delivery Time:</strong> 2-5 business days within Ghana</p>
            <p><strong>Return Policy:</strong> 7 days return policy for unused items in original condition</p>
            <p><strong>Contact:</strong> 0246146218 for any inquiries</p>
          </div>
        </div>
        
        <div className="mt-8 text-center">
          <button 
            type="submit" 
            disabled={isSubmitting}
            className="btn-primary px-12 py-4 text-lg"
          >
            {isSubmitting ? 'Placing Order...' : 'Place Order'}
          </button>
        </div>
        
        {submitStatus === 'success' && (
          <div className="mt-6 p-4 bg-lime-500/20 border border-lime-500/30 rounded-lg text-center">
            <p className="text-lime-500 font-semibold">Order placed successfully! We'll contact you shortly to confirm details.</p>
          </div>
        )}
        
        {submitStatus === 'error' && (
          <div className="mt-6 p-4 bg-red-600/20 border border-red-600/30 rounded-lg text-center">
            <p className="text-red-400 font-semibold">There was an error placing your order. Please try again or call 0246146218.</p>
          </div>
        )}
      </form>
    </div>
  );
}
