
'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import OrderForm from './OrderForm';

export default function OrdersPage() {
  return (
    <div className="min-h-screen bg-black">
      <Header />
      <main>
        <section className="py-16 bg-black">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h1 className="text-4xl md:text-5xl font-bold text-red-600 mb-4">
                Place Your Order
              </h1>
              <p className="text-xl text-red-400 max-w-2xl mx-auto">
                Complete your order details below and step out with confidence in your new style
              </p>
            </div>
            <OrderForm />
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
