
'use client';

import Link from 'next/link';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import HeroSection from './HeroSection';
import FeaturedCategories from './FeaturedCategories';
import InstagramFeed from './InstagramFeed';

export default function Home() {
  return (
    <div className="min-h-screen bg-black">
      <Header />
      <main>
        <HeroSection />
        <FeaturedCategories />
        <InstagramFeed />
      </main>
      <Footer />
    </div>
  );
}
