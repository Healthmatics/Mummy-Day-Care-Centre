
'use client';

import Link from 'next/link';

export default function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center">
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `url('https://readdy.ai/api/search-image?query=Elegant%20fashion%20boutique%20interior%20with%20premium%20clothing%20displays%2C%20sophisticated%20black%20and%20red%20color%20scheme%2C%20luxury%20retail%20environment%20with%20beautiful%20lighting%2C%20modern%20minimalist%20design%2C%20high-end%20fashion%20store%20atmosphere%2C%20clean%20and%20stylish%20layout%20with%20designer%20clothes%20and%20accessories&width=1920&height=1080&seq=hero-bg&orientation=landscape')`
        }}
      >
        <div className="absolute inset-0 bg-black/70"></div>
      </div>
      
      <div className="relative container mx-auto px-4 w-full">
        <div className="max-w-3xl">
          <h1 className="text-5xl md:text-7xl font-bold text-red-600 mb-6 leading-tight">
            Step Out With<br />
            <span className="text-lime-500">Confidence</span>
          </h1>
          
          <p className="text-xl md:text-2xl text-white mb-8 max-w-2xl">
            Discover premium fashion that speaks to your style. From elegant clothing to stunning accessories, we help you express your unique confidence.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4">
            <Link href="/shop" className="btn-primary text-center">
              Shop Now
            </Link>
            <Link href="/contact" className="btn-secondary text-center">
              Make an Enquiry
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
