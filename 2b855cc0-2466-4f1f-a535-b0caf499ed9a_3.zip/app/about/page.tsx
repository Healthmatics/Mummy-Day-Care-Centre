
'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import AboutHero from './AboutHero';
import BrandStory from './BrandStory';
import Testimonials from './Testimonials';

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-black">
      <Header />
      <main>
        <AboutHero />
        <BrandStory />
        <Testimonials />
      </main>
      <Footer />
    </div>
  );
}
