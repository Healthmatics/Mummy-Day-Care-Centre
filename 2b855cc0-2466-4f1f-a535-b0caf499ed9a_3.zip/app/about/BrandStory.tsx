
'use client';

export default function BrandStory() {
  return (
    <section className="py-20 bg-black">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="text-4xl font-bold text-red-600 mb-6">Our Story</h2>
            <div className="space-y-6 text-white text-lg leading-relaxed">
              <p>
                Boutique Eusab was born from a passion for empowering individuals to express their unique style with confidence. We believe that fashion is more than just clothing – it's a form of self-expression that tells your personal story.
              </p>
              <p>
                Our carefully curated collections feature premium quality pieces that blend contemporary trends with timeless elegance. From sophisticated clothing and statement accessories to stunning jewelry and family-friendly options, every item in our boutique is selected with the modern, fashion-conscious individual in mind.
              </p>
              <p>
                What makes us unique is our commitment to helping you step out with confidence. We don't just sell fashion; we create experiences that make you feel empowered, elegant, and authentically you.
              </p>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <img 
              src="https://readdy.ai/api/search-image?query=Premium%20fashion%20boutique%20interior%20with%20elegant%20clothing%20displays%2C%20sophisticated%20retail%20environment%20with%20black%20and%20red%20accents%2C%20luxury%20fashion%20store%20atmosphere%20with%20beautiful%20lighting%20and%20modern%20design&width=300&height=400&seq=story-1&orientation=portrait"
              alt="Boutique Interior"
              className="w-full h-full object-cover object-top rounded-lg"
            />
            <img 
              src="https://readdy.ai/api/search-image?query=Confident%20fashion%20model%20wearing%20elegant%20boutique%20clothing%2C%20premium%20designer%20outfit%20photography%2C%20sophisticated%20style%20with%20black%20and%20red%20color%20theme%2C%20luxury%20fashion%20brand%20lifestyle%20image&width=300&height=400&seq=story-2&orientation=portrait"
              alt="Fashion Model"
              className="w-full h-full object-cover object-top rounded-lg mt-8"
            />
          </div>
        </div>
        
        <div className="mt-20">
          <h3 className="text-3xl font-bold text-red-600 mb-8 text-center">Our Values</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center bg-red-900/20 p-8 rounded-lg border border-red-600/30">
              <div className="w-16 h-16 bg-lime-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-star-line text-2xl text-black"></i>
              </div>
              <h4 className="text-xl font-bold text-red-600 mb-4">Quality</h4>
              <p className="text-white">Premium materials and exceptional craftsmanship in every piece we offer.</p>
            </div>
            
            <div className="text-center bg-red-900/20 p-8 rounded-lg border border-red-600/30">
              <div className="w-16 h-16 bg-lime-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-heart-line text-2xl text-black"></i>
              </div>
              <h4 className="text-xl font-bold text-red-600 mb-4">Confidence</h4>
              <p className="text-white">Empowering you to express your unique style with complete confidence.</p>
            </div>
            
            <div className="text-center bg-red-900/20 p-8 rounded-lg border border-red-600/30">
              <div className="w-16 h-16 bg-lime-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-diamond-line text-2xl text-black"></i>
              </div>
              <h4 className="text-xl font-bold text-red-600 mb-4">Elegance</h4>
              <p className="text-white">Timeless sophistication that transcends trends and seasons.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
