
'use client';

export default function AboutHero() {
  return (
    <section className="relative py-20 bg-black">
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url('https://readdy.ai/api/search-image?query=Elegant%20fashion%20designer%20workspace%20with%20sketches%20and%20premium%20clothing%20samples%2C%20sophisticated%20atelier%20environment%20with%20black%20and%20red%20color%20scheme%2C%20luxury%20fashion%20brand%20behind%20the%20scenes%2C%20creative%20design%20studio%20with%20beautiful%20lighting%20and%20modern%20aesthetic&width=1920&height=800&seq=about-hero&orientation=landscape')`
        }}
      >
        <div className="absolute inset-0 bg-black/75"></div>
      </div>
      
      <div className="relative container mx-auto px-4 py-20">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-5xl md:text-6xl font-bold text-red-600 mb-6">
            About <span className="text-lime-500">Boutique Eusab</span>
          </h1>
          <p className="text-xl md:text-2xl text-white mb-8 leading-relaxed">
            Where confidence meets style, and every piece tells a story of elegance and sophistication.
          </p>
        </div>
      </div>
    </section>
  );
}
