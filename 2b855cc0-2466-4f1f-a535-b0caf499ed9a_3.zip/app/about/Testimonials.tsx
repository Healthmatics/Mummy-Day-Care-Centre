
'use client';

export default function Testimonials() {
  const testimonials = [
    {
      name: "Sarah Mitchell",
      role: "Fashion Enthusiast",
      content: "Boutique Eusab has completely transformed my wardrobe. Every piece I've purchased makes me feel confident and elegant. The quality is exceptional!",
      rating: 5
    },
    {
      name: "Ama Osei",
      role: "Working Professional",
      content: "I love how their collections blend professional sophistication with modern style. Perfect for my lifestyle and always receive compliments.",
      rating: 5
    },
    {
      name: "Jennifer Kwame",
      role: "Mother of Two",
      content: "The Mom & Kids collection is amazing! Finally found a place where both my children and I can find stylish, quality pieces. Highly recommend!",
      rating: 5
    },
    {
      name: "Grace Asante",
      role: "Event Planner",
      content: "Their jewelry collection is stunning! I've found the perfect pieces for both everyday wear and special occasions. Customer service is outstanding.",
      rating: 5
    }
  ];

  return (
    <section className="py-20 bg-red-900/10">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-red-600 mb-4">
            What Our Customers Say
          </h2>
          <p className="text-xl text-white">
            Real stories from people who stepped out with confidence
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-black border border-red-600/30 rounded-lg p-6">
              <div className="flex mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <i key={i} className="ri-star-fill text-lime-500"></i>
                ))}
              </div>
              <p className="text-white mb-6 italic">"{testimonial.content}"</p>
              <div>
                <h4 className="text-red-600 font-semibold">{testimonial.name}</h4>
                <p className="text-red-500 text-sm">{testimonial.role}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
