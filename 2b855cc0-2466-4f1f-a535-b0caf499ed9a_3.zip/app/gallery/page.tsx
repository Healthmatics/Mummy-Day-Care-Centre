
'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import GalleryHero from './GalleryHero';
import PhotoGallery from './PhotoGallery';

export default function GalleryPage() {
  return (
    <div className="min-h-screen bg-black">
      <Header />
      <main>
        <GalleryHero />
        <PhotoGallery />
      </main>
      <Footer />
    </div>
  );
}
