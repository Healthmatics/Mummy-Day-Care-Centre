
'use client';

export default function GalleryHero() {
  return (
    <section className="py-20 bg-black">
      <div className="container mx-auto px-4 text-center">
        <h1 className="text-5xl md:text-6xl font-bold text-red-600 mb-6">
          Our <span className="text-lime-500">Gallery</span>
        </h1>
        <p className="text-xl text-white max-w-3xl mx-auto">
          Step into our world of fashion and elegance. See our latest collections, happy customers, and behind-the-scenes moments that capture the essence of Boutique Eusab.
        </p>
      </div>
    </section>
  );
}
