
'use client';

import { useState } from 'react';

export default function PhotoGallery() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [lightboxImage, setLightboxImage] = useState<string | null>(null);

  const categories = [
    { id: 'all', name: 'All Photos' },
    { id: 'fashion-shoots', name: 'Fashion Shoots' },
    { id: 'customers', name: 'Happy Customers' },
    { id: 'new-arrivals', name: 'New Arrivals' },
    { id: 'boutique', name: 'Boutique Displays' }
  ];

  const galleryImages = [
    {
      id: 1,
      category: 'fashion-shoots',
      title: 'Elegant Evening Collection',
      image: 'https://readdy.ai/api/search-image?query=Professional%20fashion%20photoshoot%20with%20model%20wearing%20elegant%20evening%20dress%2C%20luxury%20boutique%20fashion%20photography%20with%20dramatic%20lighting%2C%20sophisticated%20black%20and%20red%20styling%2C%20high-end%20fashion%20editorial%20style&width=400&height=500&seq=gallery-1&orientation=portrait'
    },
    {
      id: 2,
      category: 'customers',
      title: 'Confident Customer Style',
      image: 'https://readdy.ai/api/search-image?query=Happy%20customer%20wearing%20boutique%20clothing%2C%20confident%20woman%20in%20designer%20outfit%20from%20fashion%20store%2C%20lifestyle%20photography%20showing%20customer%20satisfaction%20with%20premium%20fashion%20purchase&width=400&height=500&seq=gallery-2&orientation=portrait'
    },
    {
      id: 3,
      category: 'boutique',
      title: 'Premium Store Display',
      image: 'https://readdy.ai/api/search-image?query=Luxury%20boutique%20interior%20with%20elegant%20clothing%20displays%2C%20premium%20fashion%20store%20with%20sophisticated%20black%20and%20red%20decor%2C%20beautiful%20retail%20environment%20with%20designer%20clothes%20and%20accessories&width=400&height=500&seq=gallery-3&orientation=portrait'
    },
    {
      id: 4,
      category: 'new-arrivals',
      title: 'Latest Jewelry Collection',
      image: 'https://readdy.ai/api/search-image?query=New%20jewelry%20collection%20display%20with%20premium%20necklaces%20rings%20and%20earrings%2C%20luxury%20accessories%20arrangement%20for%20boutique%20showcase%2C%20elegant%20jewelry%20photography%20with%20black%20velvet%20background&width=400&height=500&seq=gallery-4&orientation=portrait'
    },
    {
      id: 5,
      category: 'fashion-shoots',
      title: 'Professional Attire Shoot',
      image: 'https://readdy.ai/api/search-image?query=Business%20fashion%20photoshoot%20with%20model%20in%20professional%20blazer%20and%20suit%2C%20corporate%20fashion%20photography%20for%20boutique%2C%20sophisticated%20office%20wear%20with%20elegant%20styling%20and%20modern%20background&width=400&height=500&seq=gallery-5&orientation=portrait'
    },
    {
      id: 6,
      category: 'customers',
      title: 'Mother and Daughter Style',
      image: 'https://readdy.ai/api/search-image?query=Happy%20mother%20and%20daughter%20wearing%20matching%20boutique%20outfits%2C%20family%20fashion%20photography%20showing%20coordinated%20styles%2C%20lifestyle%20image%20of%20satisfied%20customers%20with%20premium%20family%20clothing&width=400&height=500&seq=gallery-6&orientation=portrait'
    },
    {
      id: 7,
      category: 'boutique',
      title: 'Shoe Collection Display',
      image: 'https://readdy.ai/api/search-image?query=Premium%20shoe%20collection%20display%20in%20boutique%2C%20luxury%20footwear%20arrangement%20with%20high%20heels%20and%20designer%20shoes%2C%20elegant%20shoe%20store%20interior%20with%20sophisticated%20lighting%20and%20modern%20shelving&width=400&height=500&seq=gallery-7&orientation=portrait'
    },
    {
      id: 8,
      category: 'new-arrivals',
      title: 'Designer Handbag Collection',
      image: 'https://readdy.ai/api/search-image?query=New%20designer%20handbag%20collection%20showcase%2C%20luxury%20bags%20and%20accessories%20display%20for%20boutique%2C%20premium%20leather%20goods%20photography%20with%20elegant%20styling%20and%20black%20background&width=400&height=500&seq=gallery-8&orientation=portrait'
    },
    {
      id: 9,
      category: 'fashion-shoots',
      title: 'Confident Style Portrait',
      image: 'https://readdy.ai/api/search-image?query=Fashion%20portrait%20of%20confident%20model%20wearing%20boutique%20designer%20clothing%2C%20professional%20fashion%20photography%20with%20dramatic%20lighting%2C%20elegant%20style%20shoot%20with%20black%20and%20red%20color%20theme&width=400&height=500&seq=gallery-9&orientation=portrait'
    },
    {
      id: 10,
      category: 'customers',
      title: 'Special Occasion Style',
      image: 'https://readdy.ai/api/search-image?query=Customer%20wearing%20boutique%20formal%20dress%20for%20special%20occasion%2C%20happy%20client%20in%20elegant%20evening%20gown%2C%20lifestyle%20photography%20showing%20satisfied%20customer%20at%20special%20event&width=400&height=500&seq=gallery-10&orientation=portrait'
    },
    {
      id: 11,
      category: 'boutique',
      title: 'Elegant Store Atmosphere',
      image: 'https://readdy.ai/api/search-image?query=Boutique%20store%20atmosphere%20with%20customers%20shopping%2C%20luxury%20retail%20environment%20with%20elegant%20displays%2C%20premium%20fashion%20store%20interior%20with%20beautiful%20lighting%20and%20sophisticated%20decor&width=400&height=500&seq=gallery-11&orientation=portrait'
    },
    {
      id: 12,
      category: 'new-arrivals',
      title: 'Kids Fashion Collection',
      image: 'https://readdy.ai/api/search-image?query=New%20kids%20fashion%20collection%20display%2C%20premium%20children%20clothing%20showcase%20for%20boutique%2C%20elegant%20kids%20wear%20photography%20with%20colorful%20and%20stylish%20outfits%20arranged%20beautifully&width=400&height=500&seq=gallery-12&orientation=portrait'
    }
  ];

  const filteredImages = selectedCategory === 'all' 
    ? galleryImages 
    : galleryImages.filter(image => image.category === selectedCategory);

  const openLightbox = (imageUrl: string) => {
    setLightboxImage(imageUrl);
  };

  const closeLightbox = () => {
    setLightboxImage(null);
  };

  return (
    <section className="py-16 bg-black">
      <div className="container mx-auto px-4">
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              className={`px-6 py-3 rounded-lg font-semibold transition-all whitespace-nowrap cursor-pointer ${
                selectedCategory === category.id
                  ? 'bg-lime-500 text-black'
                  : 'bg-red-900/20 text-red-600 hover:bg-red-900/40 border border-red-600/30'
              }`}
            >
              {category.name}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredImages.map((image) => (
            <div 
              key={image.id} 
              className="group cursor-pointer"
              onClick={() => openLightbox(image.image)}
            >
              <div className="bg-red-900/20 rounded-lg overflow-hidden border border-red-600/30 hover:border-lime-500/50 transition-all">
                <div className="relative overflow-hidden">
                  <img 
                    src={image.image}
                    alt={image.title}
                    className="w-full h-80 object-cover object-top group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                    <i className="ri-zoom-in-line text-3xl text-lime-500"></i>
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="text-lg font-semibold text-red-600 group-hover:text-lime-500 transition-colors">
                    {image.title}
                  </h3>
                </div>
              </div>
            </div>
          ))}
        </div>

        {lightboxImage && (
          <div 
            className="fixed inset-0 bg-black/90 flex items-center justify-center z-50 p-4"
            onClick={closeLightbox}
          >
            <div className="relative max-w-4xl max-h-full">
              <img 
                src={lightboxImage}
                alt="Gallery Image"
                className="max-w-full max-h-full object-contain"
              />
              <button 
                onClick={closeLightbox}
                className="absolute top-4 right-4 w-10 h-10 bg-red-600 text-white rounded-full flex items-center justify-center hover:bg-lime-500 hover:text-black transition-colors"
              >
                <i className="ri-close-line text-xl"></i>
              </button>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
