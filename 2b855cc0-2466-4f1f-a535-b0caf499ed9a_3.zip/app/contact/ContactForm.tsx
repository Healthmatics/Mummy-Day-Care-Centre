
'use client';

import { useState } from 'react';

export default function ContactForm() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: ''
  });
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState('');

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      const formDataToSubmit = new FormData();
      Object.entries(formData).forEach(([key, value]) => {
        formDataToSubmit.append(key, value);
      });

      const response = await fetch('https://formspree.io/f/contact-form', {
        method: 'POST',
        body: formDataToSubmit,
        headers: {
          'Accept': 'application/json'
        },
      });

      if (response.ok) {
        setSubmitStatus('success');
        setFormData({
          name: '',
          email: '',
          phone: '',
          subject: '',
          message: ''
        });
      } else {
        setSubmitStatus('error');
      }
    } catch (error) {
      setSubmitStatus('error');
    }
    
    setIsSubmitting(false);
  };

  return (
    <div className="container mx-auto px-4">
      <div className="bg-red-900/20 rounded-lg p-8 border border-red-600/30">
        <h2 className="text-3xl font-bold text-red-600 mb-8">Send us a Message</h2>
        
        <form id="contact-form" onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-white mb-2 font-semibold">Name *</label>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
                required
                className="w-full px-4 py-3 bg-black border border-red-600/30 rounded-lg text-white focus:border-lime-500 focus:outline-none"
                placeholder="Your full name"
              />
            </div>
            
            <div>
              <label className="block text-white mb-2 font-semibold">Email *</label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                required
                className="w-full px-4 py-3 bg-black border border-red-600/30 rounded-lg text-white focus:border-lime-500 focus:outline-none"
                placeholder="your.email@example.com"
              />
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-white mb-2 font-semibold">Phone</label>
              <input
                type="tel"
                name="phone"
                value={formData.phone}
                onChange={handleInputChange}
                className="w-full px-4 py-3 bg-black border border-red-600/30 rounded-lg text-white focus:border-lime-500 focus:outline-none"
                placeholder="Your phone number"
              />
            </div>
            
            <div>
              <label className="block text-white mb-2 font-semibold">Subject *</label>
              <div className="relative">
                <select
                  name="subject"
                  value={formData.subject}
                  onChange={handleInputChange}
                  required
                  className="w-full px-4 py-3 pr-8 bg-black border border-red-600/30 rounded-lg text-white focus:border-lime-500 focus:outline-none appearance-none"
                >
                  <option value="">Select a subject</option>
                  <option value="General Inquiry">General Inquiry</option>
                  <option value="Product Information">Product Information</option>
                  <option value="Styling Consultation">Styling Consultation</option>
                  <option value="Order Support">Order Support</option>
                  <option value="Partnership">Partnership</option>
                  <option value="Other">Other</option>
                </select>
                <i className="ri-arrow-down-s-line absolute right-3 top-1/2 transform -translate-y-1/2 text-white pointer-events-none"></i>
              </div>
            </div>
          </div>
          
          <div>
            <label className="block text-white mb-2 font-semibold">Message *</label>
            <textarea
              name="message"
              value={formData.message}
              onChange={handleInputChange}
              required
              maxLength={500}
              rows={5}
              className="w-full px-4 py-3 bg-black border border-red-600/30 rounded-lg text-white focus:border-lime-500 focus:outline-none resize-vertical"
              placeholder="Tell us how we can help you..."
            />
            <p className="text-sm text-red-500 mt-1">{formData.message.length}/500 characters</p>
          </div>
          
          <div className="text-center">
            <button 
              type="submit" 
              disabled={isSubmitting}
              className="btn-primary px-12 py-4 text-lg"
            >
              {isSubmitting ? 'Sending...' : 'Send Message'}
            </button>
          </div>
          
          {submitStatus === 'success' && (
            <div className="mt-6 p-4 bg-lime-500/20 border border-lime-500/30 rounded-lg text-center">
              <p className="text-lime-500 font-semibold">Message sent successfully! We'll get back to you soon.</p>
            </div>
          )}
          
          {submitStatus === 'error' && (
            <div className="mt-6 p-4 bg-red-600/20 border border-red-600/30 rounded-lg text-center">
              <p className="text-red-400 font-semibold">There was an error sending your message. Please try again or call us directly.</p>
            </div>
          )}
        </form>
      </div>
    </div>
  );
}
