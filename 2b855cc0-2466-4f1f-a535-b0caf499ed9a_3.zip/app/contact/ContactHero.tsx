
'use client';

export default function ContactHero() {
  return (
    <section className="py-20 bg-black border-b border-red-600/20">
      <div className="container mx-auto px-4 text-center">
        <h1 className="text-5xl md:text-6xl font-bold text-red-600 mb-6">
          Get In <span className="text-lime-500">Touch</span>
        </h1>
        <p className="text-xl text-white max-w-3xl mx-auto">
          Have questions about our collections or need styling advice? We're here to help you step out with confidence.
        </p>
      </div>
    </section>
  );
}
