
'use client';

export default function ContactInfo() {
  return (
    <div className="container mx-auto px-4">
      <div className="space-y-8">
        <div>
          <h2 className="text-3xl font-bold text-red-600 mb-6">Contact Information</h2>
          <p className="text-lg text-white mb-8">
            We're here to help you step out with confidence. Reach out to us through any of these channels.
          </p>
        </div>
        
        <div className="space-y-6">
          <div className="flex items-start space-x-4">
            <div className="w-12 h-12 bg-lime-500 rounded-full flex items-center justify-center flex-shrink-0">
              <i className="ri-phone-line text-xl text-black"></i>
            </div>
            <div>
              <h3 className="text-xl font-semibold text-red-600 mb-2">Phone</h3>
              <p className="text-white">0246146218</p>
              <p className="text-sm text-red-500">Call us for immediate assistance</p>
            </div>
          </div>
          
          <div className="flex items-start space-x-4">
            <div className="w-12 h-12 bg-lime-500 rounded-full flex items-center justify-center flex-shrink-0">
              <i className="ri-mail-line text-xl text-black"></i>
            </div>
            <div>
              <h3 className="text-xl font-semibold text-red-600 mb-2">Email</h3>
              <p className="text-white">info@boutiqueeusab.com</p>
              <p className="text-sm text-red-500">We'll respond within 24 hours</p>
            </div>
          </div>
          
          <div className="flex items-start space-x-4">
            <div className="w-12 h-12 bg-lime-500 rounded-full flex items-center justify-center flex-shrink-0">
              <i className="ri-time-line text-xl text-black"></i>
            </div>
            <div>
              <h3 className="text-xl font-semibold text-red-600 mb-2">Business Hours</h3>
              <div className="space-y-1 text-white">
                <p>Monday - Friday: 9:00 AM - 8:00 PM</p>
                <p>Saturday: 10:00 AM - 6:00 PM</p>
                <p>Sunday: 12:00 PM - 5:00 PM</p>
              </div>
            </div>
          </div>
        </div>
        
        <div className="mt-12">
          <h3 className="text-2xl font-bold text-red-600 mb-6">Follow Us</h3>
          <div className="flex space-x-4">
            <a 
              href="https://facebook.com/EusabBoutique" 
              target="_blank" 
              rel="noopener noreferrer"
              className="w-12 h-12 bg-red-900/20 border border-red-600/30 rounded-full flex items-center justify-center text-white hover:bg-lime-500 hover:text-black hover:border-lime-500 transition-all"
            >
              <i className="ri-facebook-fill text-xl"></i>
            </a>
            <a 
              href="https://instagram.com/EusabBoutique" 
              target="_blank" 
              rel="noopener noreferrer"
              className="w-12 h-12 bg-red-900/20 border border-red-600/30 rounded-full flex items-center justify-center text-white hover:bg-lime-500 hover:text-black hover:border-lime-500 transition-all"
            >
              <i className="ri-instagram-line text-xl"></i>
            </a>
            <a 
              href="https://x.com/EusabBoutique" 
              target="_blank" 
              rel="noopener noreferrer"
              className="w-12 h-12 bg-red-900/20 border border-red-600/30 rounded-full flex items-center justify-center text-white hover:bg-lime-500 hover:text-black hover:border-lime-500 transition-all"
            >
              <i className="ri-twitter-x-line text-xl"></i>
            </a>
          </div>
        </div>
        
        <div className="mt-12">
          <h3 className="text-2xl font-bold text-red-600 mb-6">Visit Our Store</h3>
          <div className="bg-red-900/20 rounded-lg p-6 border border-red-600/30">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3970.8267853065895!2d-0.1969684!3d5.6037168!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNcKwMzYnMTMuNCJOIDDCsDExJzQ5LjEiVw!5e0!3m2!1sen!2sgh!4v1635789456789!5m2!1sen!2sgh"
              width="100%"
              height="300"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              className="rounded-lg"
            />
            <p className="text-white mt-4 text-center">
              Accra, Ghana - Visit us for personalized styling consultations
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
