
'use client';

export default function InstagramFeed() {
  const instagramPosts = [
    'https://readdy.ai/api/search-image?query=Fashion%20influencer%20wearing%20elegant%20boutique%20clothing%2C%20stylish%20outfit%20photography%20for%20social%20media%2C%20premium%20fashion%20brand%20lifestyle%20image%2C%20confident%20model%20in%20designer%20clothes%20with%20black%20and%20red%20color%20scheme&width=300&height=300&seq=insta-1&orientation=squarish',
    'https://readdy.ai/api/search-image?query=Beautiful%20jewelry%20flatlay%20photography%20for%20Instagram%2C%20luxury%20accessories%20arrangement%2C%20premium%20necklaces%20and%20earrings%20display%2C%20elegant%20jewelry%20brand%20social%20media%20content%20with%20sophisticated%20styling&width=300&height=300&seq=insta-2&orientation=squarish',
    'https://readdy.ai/api/search-image?query=Designer%20shoes%20collection%20photography%2C%20premium%20footwear%20lifestyle%20image%2C%20elegant%20high%20heels%20and%20fashion%20shoes%2C%20boutique%20brand%20social%20media%20content%20with%20modern%20styling%20and%20beautiful%20lighting&width=300&height=300&seq=insta-3&orientation=squarish',
    'https://readdy.ai/api/search-image?query=Mother%20and%20child%20fashion%20photography%2C%20family%20boutique%20clothing%20lifestyle%20image%2C%20elegant%20mom%20and%20kids%20wear%2C%20premium%20family%20fashion%20brand%20social%20media%20content%20with%20warm%20and%20stylish%20presentation&width=300&height=300&seq=insta-4&orientation=squarish',
    'https://readdy.ai/api/search-image?query=Fashion%20boutique%20store%20interior%20photography%2C%20luxury%20retail%20space%20with%20elegant%20displays%2C%20premium%20clothing%20store%20atmosphere%2C%20boutique%20brand%20behind-the-scenes%20social%20media%20content%20with%20sophisticated%20design&width=300&height=300&seq=insta-5&orientation=squarish',
    'https://readdy.ai/api/search-image?query=Confident%20woman%20wearing%20boutique%20fashion%20outfit%2C%20stylish%20lifestyle%20photography%20for%20fashion%20brand%2C%20premium%20clothing%20brand%20ambassador%20image%2C%20elegant%20model%20showcasing%20designer%20wear%20with%20confident%20attitude&width=300&height=300&seq=insta-6&orientation=squarish'
  ];

  return (
    <section className="py-20 bg-black">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-red-600 mb-4">
            Follow Us on Instagram
          </h2>
          <p className="text-xl text-white mb-6">
            @EusabBoutique - Get inspired by our latest styles and customer looks
          </p>
          <a 
            href="https://instagram.com/EusabBoutique" 
            target="_blank" 
            rel="noopener noreferrer"
            className="btn-primary inline-block"
          >
            Follow @EusabBoutique
          </a>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {instagramPosts.map((post, index) => (
            <a 
              key={index}
              href="https://instagram.com/EusabBoutique"
              target="_blank"
              rel="noopener noreferrer"
              className="group relative overflow-hidden rounded-lg aspect-square"
            >
              <img 
                src={post}
                alt={`Instagram post ${index + 1}`}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                <i className="ri-instagram-line text-3xl text-lime-500"></i>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
