
'use client';

import { useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { useCartStore } from '@/lib/cartStore';

export default function ProductGrid() {
  const searchParams = useSearchParams();
  const categoryFilter = searchParams?.get('category') || 'all';
  const [selectedCategory, setSelectedCategory] = useState(categoryFilter);
  const [selectedProducts, setSelectedProducts] = useState<{[key: number]: {size: string, color: string}}>({});
  const { addItem } = useCartStore();

  const categories = [
    { id: 'all', name: 'All Products' },
    { id: 'clothing', name: 'Clothing' },
    { id: 'shoes', name: 'Shoes' },
    { id: 'jewellery', name: 'Jewellery' },
    { id: 'mom-kids', name: 'Mom & Kids' }
  ];

  const products = [
    {
      id: 1,
      name: "Elegant Evening Dress",
      price: 450,
      category: "clothing",
      image: "https://readdy.ai/api/search-image?query=Elegant%20black%20evening%20dress%20on%20model%2C%20premium%20designer%20formal%20wear%20for%20boutique%2C%20sophisticated%20party%20dress%20with%20red%20accents%2C%20luxury%20fashion%20photography%20with%20black%20background&width=400&height=500&seq=dress-1&orientation=portrait",
      sizes: ["S", "M", "L", "XL"],
      colors: ["Black", "Red", "Navy"]
    },
    {
      id: 2,
      name: "Designer High Heels",
      price: 320,
      category: "shoes",
      image: "https://readdy.ai/api/search-image?query=Luxury%20designer%20high%20heel%20shoes%2C%20premium%20red%20stiletto%20heels%20for%20boutique%2C%20elegant%20womens%20formal%20footwear%20with%20sophisticated%20styling%2C%20high-end%20shoe%20photography%20with%20black%20background&width=400&height=500&seq=shoes-1&orientation=portrait",
      sizes: ["36", "37", "38", "39", "40"],
      colors: ["Red", "Black", "Nude"]
    },
    {
      id: 3,
      name: "Diamond Statement Necklace",
      price: 680,
      category: "jewellery",
      image: "https://readdy.ai/api/search-image?query=Luxury%20diamond%20statement%20necklace%2C%20premium%20gold%20jewelry%20with%20red%20gemstones%2C%20elegant%20designer%20necklace%20for%20boutique%2C%20sophisticated%20jewelry%20photography%20with%20black%20velvet%20background&width=400&height=500&seq=jewelry-1&orientation=portrait",
      sizes: ["One Size"],
      colors: ["Gold", "Silver"]
    },
    {
      id: 4,
      name: "Matching Mother-Daughter Set",
      price: 280,
      category: "mom-kids",
      image: "https://readdy.ai/api/search-image?query=Elegant%20matching%20mother%20and%20daughter%20outfit%20set%2C%20premium%20family%20fashion%20coordination%2C%20sophisticated%20mom%20and%20kids%20clothing%20with%20red%20and%20black%20color%20scheme%2C%20boutique%20family%20wear%20photography&width=400&height=500&seq=family-1&orientation=portrait",
      sizes: ["Mom: S-XL, Kid: 2-12"],
      colors: ["Red & Black", "Navy & White"]
    },
    {
      id: 5,
      name: "Professional Blazer",
      price: 380,
      category: "clothing",
      image: "https://readdy.ai/api/search-image?query=Premium%20professional%20blazer%20for%20women%2C%20elegant%20business%20suit%20jacket%20in%20black%20with%20red%20lining%2C%20sophisticated%20office%20wear%20for%20boutique%2C%20luxury%20fashion%20photography%20with%20modern%20styling&width=400&height=500&seq=blazer-1&orientation=portrait",
      sizes: ["XS", "S", "M", "L", "XL"],
      colors: ["Black", "Charcoal", "Navy"]
    },
    {
      id: 6,
      name: "Luxury Sneakers",
      price: 240,
      category: "shoes",
      image: "https://readdy.ai/api/search-image?query=Premium%20designer%20sneakers%2C%20luxury%20casual%20footwear%20with%20red%20and%20black%20color%20scheme%2C%20elegant%20sports%20shoes%20for%20boutique%2C%20high-end%20sneaker%20photography%20with%20sophisticated%20styling&width=400&height=500&seq=sneakers-1&orientation=portrait",
      sizes: ["36", "37", "38", "39", "40", "41"],
      colors: ["Black/Red", "White/Gold", "All Black"]
    },
    {
      id: 7,
      name: "Gold Earring Collection",
      price: 220,
      category: "jewellery",
      image: "https://readdy.ai/api/search-image?query=Luxury%20gold%20earring%20collection%20set%2C%20premium%20designer%20jewelry%20with%20red%20gemstone%20accents%2C%20elegant%20earrings%20for%20boutique%20display%2C%20sophisticated%20jewelry%20photography%20with%20black%20background&width=400&height=500&seq=earrings-1&orientation=portrait",
      sizes: ["One Size"],
      colors: ["Gold", "Rose Gold"]
    },
    {
      id: 8,
      name: "Kids Designer Outfit",
      price: 180,
      category: "mom-kids",
      image: "https://readdy.ai/api/search-image?query=Premium%20kids%20designer%20outfit%2C%20elegant%20children%20clothing%20with%20sophisticated%20styling%2C%20luxury%20kids%20fashion%20for%20boutique%2C%20high-end%20children%20wear%20photography%20with%20red%20and%20black%20accents&width=400&height=500&seq=kids-1&orientation=portrait",
      sizes: ["2T", "3T", "4T", "5T", "6T"],
      colors: ["Red", "Black", "White"]
    }
  ];

  const filteredProducts = selectedCategory === 'all' 
    ? products 
    : products.filter(product => product.category === selectedCategory);

  const handleSizeSelect = (productId: number, size: string) => {
    setSelectedProducts(prev => ({
      ...prev,
      [productId]: { ...prev[productId], size }
    }));
  };

  const handleColorSelect = (productId: number, color: string) => {
    setSelectedProducts(prev => ({
      ...prev,
      [productId]: { ...prev[productId], color }
    }));
  };

  const handleAddToCart = (product: typeof products[0]) => {
    const selection = selectedProducts[product.id];
    const size = selection?.size || product.sizes[0];
    const color = selection?.color || product.colors[0];
    
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      size,
      color
    });
  };

  return (
    <section className="py-16 bg-black">
      <div className="container mx-auto px-4">
        <div className="mb-12">
          <div className="flex flex-wrap justify-center gap-4 mb-8">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`px-6 py-3 rounded-lg font-semibold transition-all whitespace-nowrap cursor-pointer ${
                  selectedCategory === category.id
                    ? 'bg-lime-500 text-black'
                    : 'bg-red-900/20 text-white hover:bg-red-900/40 border border-red-600/30'
                }`}
              >
                {category.name}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {filteredProducts.map((product) => (
            <div key={product.id} className="bg-red-900/20 rounded-lg overflow-hidden border border-red-600/30 hover:border-lime-500/50 transition-all group">
              <div className="relative overflow-hidden">
                <img 
                  src={product.image}
                  alt={product.name}
                  className="w-full h-80 object-cover object-top group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-4 right-4">
                  <button className="w-10 h-10 bg-red-600 text-white rounded-full flex items-center justify-center hover:bg-lime-500 hover:text-black transition-colors cursor-pointer">
                    <i className="ri-heart-line"></i>
                  </button>
                </div>
              </div>
              
              <div className="p-6">
                <h3 className="text-xl font-bold text-white mb-2">{product.name}</h3>
                <p className="text-2xl font-bold text-lime-500 mb-4">GH₵{product.price}</p>
                
                <div className="mb-4">
                  <p className="text-sm text-white mb-2">Sizes:</p>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {product.sizes.map((size) => (
                      <button
                        key={size}
                        onClick={() => handleSizeSelect(product.id, size)}
                        className={`px-3 py-1 rounded text-sm border transition-colors cursor-pointer whitespace-nowrap ${
                          selectedProducts[product.id]?.size === size
                            ? 'bg-lime-500 text-black border-lime-500'
                            : 'bg-transparent text-white border-red-600/30 hover:border-lime-500'
                        }`}
                      >
                        {size}
                      </button>
                    ))}
                  </div>
                  
                  <p className="text-sm text-white mb-2">Colors:</p>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {product.colors.map((color) => (
                      <button
                        key={color}
                        onClick={() => handleColorSelect(product.id, color)}
                        className={`px-3 py-1 rounded text-sm border transition-colors cursor-pointer whitespace-nowrap ${
                          selectedProducts[product.id]?.color === color
                            ? 'bg-lime-500 text-black border-lime-500'
                            : 'bg-transparent text-white border-red-600/30 hover:border-lime-500'
                        }`}
                      >
                        {color}
                      </button>
                    ))}
                  </div>
                </div>
                
                <button 
                  onClick={() => handleAddToCart(product)}
                  className="w-full btn-primary mb-2"
                >
                  Add to Cart
                </button>
                <button className="w-full btn-secondary">
                  Buy Now
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
