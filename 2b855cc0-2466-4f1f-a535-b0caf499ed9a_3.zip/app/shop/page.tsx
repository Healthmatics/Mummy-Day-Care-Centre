
'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ShopHero from './ShopHero';
import ProductGrid from './ProductGrid';
import { Suspense } from 'react';

function ShopContent() {
  return (
    <div className="min-h-screen bg-black">
      <Header />
      <main>
        <ShopHero />
        <Suspense fallback={<div className="py-20 text-center text-red-400">Loading products...</div>}>
          <ProductGrid />
        </Suspense>
      </main>
      <Footer />
    </div>
  );
}

export default function ShopPage() {
  return (
    <Suspense fallback={<div className="min-h-screen bg-black flex items-center justify-center text-red-400">Loading...</div>}>
      <ShopContent />
    </Suspense>
  );
}
