
'use client';

export default function ShopHero() {
  return (
    <section className="py-16 bg-black border-b border-red-600/20">
      <div className="container mx-auto px-4 text-center">
        <h1 className="text-4xl md:text-5xl font-bold text-red-600 mb-4">
          Shop Collection
        </h1>
        <p className="text-xl text-white max-w-2xl mx-auto">
          Discover premium fashion pieces that help you step out with confidence
        </p>
      </div>
    </section>
  );
}
