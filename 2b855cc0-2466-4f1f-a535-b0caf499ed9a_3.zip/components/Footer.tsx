
'use client';

import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="bg-black border-t border-red-600/20 mt-16">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-xl font-bold text-red-600 font-pacifico mb-4">Boutique Eusab</h3>
            <p className="text-white mb-4">Step Out With Confidence</p>
            <p className="text-white">Premium fashion for the modern individual</p>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold text-red-600 mb-4">Quick Links</h4>
            <div className="space-y-2">
              <Link href="/about" className="block text-white hover:text-lime-500 transition-colors">About Us</Link>
              <Link href="/shop" className="block text-white hover:text-lime-500 transition-colors">Shop</Link>
              <Link href="/collections" className="block text-white hover:text-lime-500 transition-colors">Collections</Link>
              <Link href="/contact" className="block text-white hover:text-lime-500 transition-colors">Contact</Link>
            </div>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold text-red-600 mb-4">Categories</h4>
            <div className="space-y-2">
              <Link href="/shop?category=clothing" className="block text-white hover:text-lime-500 transition-colors">Clothing</Link>
              <Link href="/shop?category=shoes" className="block text-white hover:text-lime-500 transition-colors">Shoes</Link>
              <Link href="/shop?category=jewellery" className="block text-white hover:text-lime-500 transition-colors">Jewellery</Link>
              <Link href="/shop?category=mom-kids" className="block text-white hover:text-lime-500 transition-colors">Mom & Kids</Link>
            </div>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold text-red-600 mb-4">Contact Info</h4>
            <div className="space-y-2 text-white">
              <p className="flex items-center">
                <i className="ri-phone-line mr-2"></i>
                0246146218
              </p>
              <div className="flex space-x-4 mt-4">
                <a href="https://facebook.com/EusabBoutique" target="_blank" rel="noopener noreferrer" 
                   className="w-8 h-8 flex items-center justify-center text-white hover:text-lime-500 transition-colors">
                  <i className="ri-facebook-fill text-xl"></i>
                </a>
                <a href="https://instagram.com/EusabBoutique" target="_blank" rel="noopener noreferrer"
                   className="w-8 h-8 flex items-center justify-center text-white hover:text-lime-500 transition-colors">
                  <i className="ri-instagram-line text-xl"></i>
                </a>
                <a href="https://x.com/EusabBoutique" target="_blank" rel="noopener noreferrer"
                   className="w-8 h-8 flex items-center justify-center text-white hover:text-lime-500 transition-colors">
                  <i className="ri-twitter-x-line text-xl"></i>
                </a>
              </div>
            </div>
          </div>
        </div>
        
        <div className="border-t border-red-600/20 mt-8 pt-8 text-center">
          <p className="text-white">
            Copyright © 2025 Eusab Boutique Powered by RashlynGraphics
          </p>
        </div>
      </div>
    </footer>
  );
}
