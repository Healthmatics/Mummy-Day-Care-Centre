
'use client';

import Link from 'next/link';
import { useState } from 'react';
import { useCartStore } from '@/lib/cartStore';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { getTotalItems, toggleCart } = useCartStore();

  return (
    <header className="bg-black border-b border-red-600/20 sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link href="/" className="text-2xl font-bold text-red-600 font-pacifico">
            Boutique Eusab
          </Link>
          
          <nav className="hidden md:flex items-center space-x-8">
            <Link href="/" className="text-white hover:text-lime-500 transition-colors">Home</Link>
            <Link href="/about" className="text-white hover:text-lime-500 transition-colors">About</Link>
            <Link href="/shop" className="text-white hover:text-lime-500 transition-colors">Shop</Link>
            <Link href="/collections" className="text-white hover:text-lime-500 transition-colors">Collections</Link>
            <Link href="/orders" className="text-white hover:text-lime-500 transition-colors">Orders</Link>
            <Link href="/gallery" className="text-white hover:text-lime-500 transition-colors">Gallery</Link>
            <Link href="/contact" className="text-white hover:text-lime-500 transition-colors">Contact</Link>
          </nav>

          <div className="flex items-center space-x-4">
            <button 
              onClick={toggleCart}
              className="relative p-2 text-white hover:text-lime-500 transition-colors cursor-pointer"
            >
              <i className="ri-shopping-cart-line text-xl"></i>
              {getTotalItems() > 0 && (
                <span className="absolute -top-1 -right-1 bg-lime-500 text-black text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  {getTotalItems()}
                </span>
              )}
            </button>
            
            <button 
              className="md:hidden p-2 text-white cursor-pointer"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              <i className={`ri-${isMenuOpen ? 'close' : 'menu'}-line text-xl`}></i>
            </button>
          </div>
        </div>

        {isMenuOpen && (
          <div className="md:hidden border-t border-red-600/20 py-4">
            <nav className="flex flex-col space-y-4">
              <Link href="/" className="text-white hover:text-lime-500 transition-colors">Home</Link>
              <Link href="/about" className="text-white hover:text-lime-500 transition-colors">About</Link>
              <Link href="/shop" className="text-white hover:text-lime-500 transition-colors">Shop</Link>
              <Link href="/collections" className="text-white hover:text-lime-500 transition-colors">Collections</Link>
              <Link href="/orders" className="text-white hover:text-lime-500 transition-colors">Orders</Link>
              <Link href="/gallery" className="text-white hover:text-lime-500 transition-colors">Gallery</Link>
              <Link href="/contact" className="text-white hover:text-lime-500 transition-colors">Contact</Link>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
