
'use client';

import { useCartStore } from '@/lib/cartStore';
import { useState } from 'react';
import Link from 'next/link';

export default function Cart() {
  const { items, isOpen, toggleCart, removeItem, updateQuantity, getTotalPrice, clearCart } = useCartStore();
  const [showCheckout, setShowCheckout] = useState(false);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 z-50">
      <div className="fixed right-0 top-0 h-full w-full max-w-md bg-black border-l border-red-600/30 overflow-y-auto">
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-white">Shopping Cart</h2>
            <button 
              onClick={toggleCart}
              className="w-8 h-8 flex items-center justify-center text-white hover:text-lime-500"
            >
              <i className="ri-close-line text-xl"></i>
            </button>
          </div>

          {items.length === 0 ? (
            <div className="text-center py-12">
              <i className="ri-shopping-cart-line text-6xl text-red-600/50 mb-4"></i>
              <p className="text-white mb-4">Your cart is empty</p>
              <Link href="/shop" onClick={toggleCart}>
                <button className="btn-primary">Start Shopping</button>
              </Link>
            </div>
          ) : (
            <>
              <div className="space-y-4 mb-6">
                {items.map((item) => (
                  <div key={`${item.id}-${item.size}-${item.color}`} className="bg-red-900/20 rounded-lg p-4 border border-red-600/30">
                    <div className="flex gap-4">
                      <img 
                        src={item.image} 
                        alt={item.name}
                        className="w-16 h-16 object-cover object-top rounded"
                      />
                      <div className="flex-1">
                        <h3 className="text-white font-semibold text-sm">{item.name}</h3>
                        <p className="text-red-400 text-sm">Size: {item.size} | Color: {item.color}</p>
                        <p className="text-lime-500 font-bold">GH₵{item.price}</p>
                      </div>
                      <button 
                        onClick={() => removeItem(item.id)}
                        className="w-6 h-6 flex items-center justify-center text-red-400 hover:text-red-600"
                      >
                        <i className="ri-delete-bin-line"></i>
                      </button>
                    </div>
                    <div className="flex items-center justify-between mt-3">
                      <div className="flex items-center gap-2">
                        <button 
                          onClick={() => updateQuantity(item.id, item.quantity - 1)}
                          className="w-8 h-8 flex items-center justify-center bg-red-600 text-white rounded hover:bg-red-700"
                        >
                          <i className="ri-subtract-line"></i>
                        </button>
                        <span className="text-white px-3">{item.quantity}</span>
                        <button 
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          className="w-8 h-8 flex items-center justify-center bg-red-600 text-white rounded hover:bg-red-700"
                        >
                          <i className="ri-add-line"></i>
                        </button>
                      </div>
                      <p className="text-lime-500 font-bold">GH₵{item.price * item.quantity}</p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="border-t border-red-600/30 pt-4 mb-6">
                <div className="flex justify-between items-center text-xl font-bold">
                  <span className="text-white">Total:</span>
                  <span className="text-lime-500">GH₵{getTotalPrice()}</span>
                </div>
              </div>

              <div className="space-y-3">
                <button 
                  onClick={() => setShowCheckout(true)}
                  className="w-full btn-primary"
                >
                  Proceed to Checkout
                </button>
                <button 
                  onClick={clearCart}
                  className="w-full btn-secondary"
                >
                  Clear Cart
                </button>
              </div>
            </>
          )}
        </div>
      </div>

      {showCheckout && (
        <CheckoutModal 
          total={getTotalPrice()} 
          onClose={() => setShowCheckout(false)} 
        />
      )}
    </div>
  );
}

function CheckoutModal({ total, onClose }: { total: number; onClose: () => void }) {
  const [selectedPayment, setSelectedPayment] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentStatus, setPaymentStatus] = useState('');
  const { clearCart } = useCartStore();

  const paymentMethods = [
    { id: 'mtn-momo', name: 'MTN Mobile Money', icon: 'ri-smartphone-line' },
    { id: 'telecel-cash', name: 'Telecel Cash', icon: 'ri-smartphone-line' },
    { id: 'airteltigo-cash', name: 'AirtelTigo Cash', icon: 'ri-smartphone-line' },
  ];

  const handlePayment = async () => {
    if (!selectedPayment || !phoneNumber) {
      setPaymentStatus('Please select payment method and enter phone number');
      return;
    }

    setIsProcessing(true);
    
    // Simulate payment processing
    setTimeout(() => {
      setPaymentStatus('Payment successful! Order confirmed.');
      clearCart();
      setIsProcessing(false);
      setTimeout(() => {
        onClose();
      }, 2000);
    }, 3000);
  };

  return (
    <div className="fixed inset-0 bg-black/80 z-60 flex items-center justify-center p-4">
      <div className="bg-black border border-red-600/30 rounded-lg p-6 w-full max-w-md">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-bold text-white">Checkout</h3>
          <button 
            onClick={onClose}
            className="w-6 h-6 flex items-center justify-center text-white hover:text-red-400"
          >
            <i className="ri-close-line"></i>
          </button>
        </div>

        <div className="mb-6">
          <div className="bg-red-900/20 rounded-lg p-4 border border-red-600/30 mb-4">
            <div className="flex justify-between items-center">
              <span className="text-white">Total Amount:</span>
              <span className="text-lime-500 font-bold text-xl">GH₵{total}</span>
            </div>
          </div>

          <div className="mb-4">
            <label className="block text-white mb-2 font-semibold">Select Payment Method</label>
            <div className="space-y-2">
              {paymentMethods.map((method) => (
                <button
                  key={method.id}
                  onClick={() => setSelectedPayment(method.id)}
                  className={`w-full p-3 rounded-lg border text-left flex items-center gap-3 transition-all ${
                    selectedPayment === method.id
                      ? 'border-lime-500 bg-lime-500/10 text-lime-500'
                      : 'border-red-600/30 bg-red-900/20 text-white hover:border-red-400'
                  }`}
                >
                  <i className={`${method.icon} text-lg`}></i>
                  {method.name}
                </button>
              ))}
            </div>
          </div>

          <div className="mb-6">
            <label className="block text-white mb-2 font-semibold">Phone Number</label>
            <input
              type="tel"
              value={phoneNumber}
              onChange={(e) => setPhoneNumber(e.target.value)}
              placeholder="e.g., 0246146218"
              className="w-full px-4 py-3 bg-red-900/20 border border-red-600/30 rounded-lg text-white focus:border-lime-500 focus:outline-none"
            />
          </div>

          <button 
            onClick={handlePayment}
            disabled={isProcessing}
            className="w-full btn-primary mb-4"
          >
            {isProcessing ? 'Processing Payment...' : `Pay GH₵${total}`}
          </button>

          {paymentStatus && (
            <div className={`p-3 rounded-lg text-center ${
              paymentStatus.includes('successful') 
                ? 'bg-lime-500/20 border border-lime-500/30 text-lime-500' 
                : 'bg-red-600/20 border border-red-600/30 text-red-400'
            }`}>
              {paymentStatus}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}